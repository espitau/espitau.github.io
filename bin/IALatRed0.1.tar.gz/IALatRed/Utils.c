#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "Utils.h"

void* malloc_check(size_t s) {
  void* p = malloc(s);
  if(p == NULL) {
    perror("malloc()");
    abort();
  }
  return p;
}

void* realloc_check(void* p, size_t s) {
  p = realloc(p, s);
  if(s > 0 && p == NULL) {
    perror("realloc()");
    abort();
  }
  return p;
}

/* 
 * Read a bigint or return NULL if stdin do not start with a digit or a minus
 */
LatEntry* read_LatEntry() {
  LatEntry *i = malloc_check(sizeof(LatEntry));
  mpz_init(*i);
  if(gmp_scanf(" %Zd", i) == 1)
    return i;
  free(i);
  return NULL;
}

/* 
 * Return next non-blank character
 */
char next() {
  char c; scanf(" %c", &c);
  return c;
}

/*
 * Check got==exp
 */
void check(char got, char exp) {
  if(got != exp) {
    fprintf(stderr, "Syntax error : %c expected, got %c\n", exp, got);
    abort(); 
  }
}

int AllocAndRead(LatEntry **LatticePtr, int *spacedimPtr, int *dimPtr, int dim_add_margin, int dim_mul_margin){
  int row, col, dim_margin;
  int row_max = 1;
  int col_max = 1;

  LatEntry *tmp   = NULL;
  LatEntry ***mat = NULL; 
  LatEntry *Lattice, *LatPtr;


  /* Init : 1x1 matrix */
  mat = malloc_check(sizeof(LatEntry**[row_max]));
  mat[0] = malloc_check(sizeof(LatEntry*[col_max]));
  
  /* Parse */
  check(next(), '[');
  check(next(), '[');
  for(row = 1; ; row++) {
    
    /* Increase number of row if necessary */
    if(row > row_max) {
      int i;
      row_max *= 2;
      mat = realloc_check(mat, sizeof(LatEntry**[row_max]));
      for(i = row-1; i < row_max; i++)
        mat[i] = malloc_check(sizeof(LatEntry*[col_max]));
    }
    
    /* Read numbers in this line */
    for(col = 1; ; col++) {
      tmp = read_LatEntry();
      if(tmp == NULL) { // failed to read a number
        col--; // col is now accurate
        break;
      }
      if(col > col_max) {
        if(row == 1) { // first row : increase number of col
          col_max *= 2;
          mat[0] = realloc_check(mat[0], sizeof(LatEntry*[col_max]));
        }
        else { // Error : not the same number of numbers in each lines
          fprintf(stderr, "Parse error : \
                            row 1 and %d do not have the same length\n", row);
          return 1;
        }
      }
      mat[row-1][col-1] = tmp;
    }
    
    /* End of row */
    check(next(), ']');
    
    if(row == 1) { 
      if(col < col_max) {
        col_max = col;
        mat[0] = realloc_check(mat[0], sizeof(LatEntry*[col_max]));
      }
    }
    else { 
      if(col < col_max) {
        fprintf(stderr, "Parse error : row 1 and %d do not have the same length\n", row);
        return 1; 
      }
    }
    
    /* Check end of matrix */
    char n = next();
    if(n == ']') break;
    check(n, '[');
  }
  
  /* Shrink row_max */
  if(row < row_max) {
    row_max = row;
    mat = realloc_check(mat, sizeof(LatEntry**[row_max]));
  }


  dim_margin=dim_add_margin+row_max*dim_mul_margin;
  
  Lattice = (LatEntry *)malloc((row_max+dim_margin)*col_max*sizeof(LatEntry));
  LatPtr = Lattice;
  for(int y = 0; y < row_max; y++) {
    for(int x = 0; x < col_max; x++){
      InitLatEntry(*LatPtr);
      mpz_set(*LatPtr, *mat[y][x]);
      LatPtr++;
      mpz_clear(*mat[y][x]);
    }
    free(mat[y]);
  }
  //Add dim_margin empty vectors
  for(int y = 0; y < dim_margin; y++) {
    for(int x = 0; x < col_max; x++){
      InitLatEntry(*LatPtr);
      LatPtr++;
    }
  }


  *LatticePtr = Lattice;
  *spacedimPtr = col_max;
  *dimPtr = row_max;

  free(mat);
  free(tmp);
  return 0;
}


void WriteLattice(LatEntry *Lattice, int spacedim, int dim)
{
  int i,j;
  LatEntry *LatPtr;

  LatPtr=Lattice;
  printf("%d\n%d\n",spacedim,dim);
  for(i=0;i<dim;i++) {
    for(j=0;j<spacedim;j++) {
      WriteLatEntry(LatPtr);
      printf("\n");
      LatPtr++;
    }
  }
}

void GPWriteLattice(LatEntry *Lattice, int spacedim, int dim)
{
  int i,j;
  LatEntry *LatPtr;

  LatPtr=Lattice;
  printf("[");
  for(i=0;i<dim;i++) {
    for(j=0;j<spacedim-1;j++) {
      WriteLatEntry(LatPtr);
      printf(",");
      LatPtr++;
    }
    WriteLatEntry(LatPtr);
    printf(";\n");
    LatPtr++;
  }
  printf("]\n");
}


void NTLWriteLattice(LatEntry *Lattice, int spacedim, int dim)
{
  int i,j;
  LatEntry *LatPtr;

  LatPtr=Lattice;
  printf("[");
  for(i=0;i<dim;i++) {
    printf("[");
    for(j=0;j<spacedim;j++) {
      WriteLatEntry(LatPtr);
      printf(" ");
      LatPtr++;
    }
    printf("]\n");
  }
  printf("]\n");
}


int AllocLat(LatEntry **LatPtr, int spacedim, int dim)
{
  LatEntry *Lat, *LPtr;
  int i,j;

  Lat=(LatEntry *)malloc(dim*spacedim*sizeof(LatEntry));
  if (Lat==NULL) return 1;
  LPtr=Lat;
  for(i=0;i<dim;i++) {
    for(j=0;j<spacedim;j++) {
      InitLatEntry(*LPtr);
      LPtr++;
    }
  }

  *LatPtr=Lat;
  return 0;
}


int AllocGram(GramEntry **GramPtr, int spacedim, int dim)
{
  char *FullAllocationBuff;
  GramEntry *Gram, *GrPtr;
  int i,j;

  FullAllocationBuff=(char*)malloc(dim*spacedim*(sizeof(GramEntry)+flti_glob_allocsize));
  Gram=(GramEntry *)FullAllocationBuff;
  if (Gram==NULL) return 1;
  FullAllocationBuff+=dim*spacedim*sizeof(GramEntry);
  GrPtr=Gram;
  for(i=0;i<dim;i++) {
    for(j=0;j<spacedim;j++) {
      *GrPtr=(GramEntry) FullAllocationBuff;
      GrPtr++;
      FullAllocationBuff+=flti_glob_allocsize;
    }
  }

  *GramPtr=Gram;

  return 0;
}

void UnAllocLat(LatEntry **LatPtr, int spacedim, int dim)
{
  LatEntry *Lat, *LPtr;
  int i,j;

  Lat=*LatPtr;
  LPtr=Lat;
  for(i=0;i<dim;i++) {
    for(j=0;j<spacedim;j++) {
      DelLatEntry(*LPtr);
      LPtr++;
    }
  }
  free(Lat);
  *LatPtr=NULL;
}



void UnAllocGram(GramEntry **GramPtr, int spacedim, int dim)
{
  GramEntry *Gram, *GrPtr;
  int i,j;

  Gram=*GramPtr;
  free(Gram);
  *GramPtr=NULL;
}


