#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "LLL.h"

int main(int argc, char **argv)
{
  /*  Lattice Entries */
  LatEntry *Lattice;
  LatEntry *ScalProd;
  int dim, spacedim, scaldim1, scaldim2;
  int i, enddim, loop;
  int errcode;
  double lll_cste=0.99;
  int mupolicy=MU_LAZY_RECOMPUTE;
  int withscalarprod=0;


  if (argc>1) {
    for (i=1;i<argc;i++) {
      // read command line
      if (argv[i][0]!='-') {
        fprintf(stderr,"Unrecognized command line option %s\n",argv[i]);
        exit(1);
      }

      // -s...  = -silent => VERBOSE=0
      if (argv[i][1]=='s') {
        VERBOSE=0;
        fprintf(stderr,"Partially silent mode\n");
      }

      // -S...  = -Scalar prod => withscalarprod=1
      else if (argv[i][1]=='S') {
        withscalarprod=1;
      }

      // -p...  = -potential => DEEP_LOVASZ=1
      else if (argv[i][1]=='p') {
        DEEP_LOVASZ=1;
        fprintf(stderr,"Potential-LLL variant\n");
      }

      // -e...  = -early_prec_detect => EARLY_PREC_DETECT=1
      else if (argv[i][1]=='e') {
        EARLY_PREC_DETECT=1;
        fprintf(stderr,"Early precision defect detection activated\n");
      }


      //-d..  0.xx => set delta 
      else if (argv[i][1]=='d') {
        if ((i+1)<argc) {
          i++;
          lll_cste=0.0;
          sscanf(argv[i],"%lf",&lll_cste);
          if ((lll_cste<=0.25) || (lll_cste>=1.0)) {
            fprintf(stderr,"Invalid command line option %s %s => lll_cste=%f\n",argv[i-1],argv[i],lll_cste);
            exit(1);
          }
          else {
            fprintf(stderr,"Setting lll_cste=%f\n",lll_cste);
          }
        }
        else {
          fprintf(stderr,"Option %s expects an argument\n",argv[i]);
          exit(1);
        }
      }
      //-m... =-mupolicy   max/lazy => set mu_policy 
      else if (argv[i][1]=='m') {
        if ((i+1)<argc) {
          i++;
          if (argv[i][0]=='l') {
            mupolicy=MU_LAZY_RECOMPUTE;
          }
          else if (argv[i][0]=='m') {
            mupolicy=MU_MAX_RECOMPUTE;
          }
          else {
            fprintf(stderr,"Argument %s is not a valid mu-policy\n",argv[i]);
            exit(1);
          }
        }
        else {
          fprintf(stderr,"Option %s expects an argument\n",argv[i]);
          exit(1);
        }
      }
      //-B..  depth => call BKZ depth 
      else if (argv[i][1]=='B') {
        if ((i+1)<argc) {
          i++;
          BKZ_DEPTH=-1;
          sscanf(argv[i],"%d",&BKZ_DEPTH);
          if (BKZ_DEPTH<=2) {
            fprintf(stderr,"Invalid command line option %s %s => BKZ_DEPTH=%d\n",argv[i-1],argv[i],BKZ_DEPTH);
            exit(1);
          }
          else {
            fprintf(stderr,"Setting BKZ_DEPTH=%d\n",BKZ_DEPTH);
          }
        }
        else {
          fprintf(stderr,"Option %s expects an argument\n",argv[i]);
          exit(1);
        }
      }
      //-R..  rounds => set BKZ_ROUNDS 
      else if (argv[i][1]=='R') {
        if ((i+1)<argc) {
          i++;
          BKZ_ROUNDS=-1;
          sscanf(argv[i],"%d",&BKZ_ROUNDS);
          if (BKZ_ROUNDS<=0) {
            fprintf(stderr,"Invalid command line option %s %s => BKZ_ROUNDS=%d\n",argv[i-1],argv[i],BKZ_ROUNDS);
            exit(1);
          }
          else {
            fprintf(stderr,"Setting BKZ_ROUNDS=%d\n",BKZ_ROUNDS);
          }
        }
        else {
          fprintf(stderr,"Option %s expects an argument\n",argv[i]);
          exit(1);
        }
      }
      //-I  => ignore LLL-cste in enumeration
      else if (argv[i][1]=='I') {
	BKZ_POLY_CONSTRAINT=0;
	fprintf(stderr,"Setting BKZ_POLY_CONSTRAINT=0\n");
      }
      else {
        fprintf(stderr,"Unrecognized command line option %s\n",argv[i]);
        exit(1);
      }
    }
  }

  errcode=AllocAndRead(&Lattice, &spacedim, &dim, 1, 1);
  if (errcode) {
    fprintf(stderr,"Error during lattice input\n");
    return 1;
  }

  if (withscalarprod) {
    fprintf(stderr,"Reading Scalar product matrix now\n");
    errcode=AllocAndRead(&ScalProd, &scaldim1, &scaldim2, 1, 1);
    if (errcode) {
      fprintf(stderr,"Error during scalar product input\n");
      return 1;
    }
    if ((scaldim1!=spacedim) || (scaldim2!=spacedim)) {
      fprintf(stderr,"Scalar product should be a square mat of dim %d\n",spacedim);
      return 1;
    }
  }
  else {
    ScalProd=NULL;
  }

  if ((BKZ_DEPTH>2)&&(BKZ_ROUNDS==0)) {
    BKZ_ROUNDS=-1;
  }

  errcode=LL_Adaptative(Lattice, ScalProd, spacedim, dim, &enddim, lll_cste, mupolicy);
  if (errcode) {
    fprintf(stderr,"LLL reports error\n");
    // return 1;
  }

  NTLWriteLattice(Lattice, spacedim, enddim);
  return 0;
}
