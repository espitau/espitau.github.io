#include <stdio.h>
#include <stdlib.h>
#include <gmp.h>

// Do not increase beyond 31 --> If changed update DoCompareNoisyHalf !
// Global hypothesis maxerror^2 fits in unsigned long 
#define MAX_ERROR_PREC 31

// Currently the representation should be interpreted as:
// x belongs to [M-eps, M+eps]
// with M=sign*mantissa*2^exponent
//      eps=errormant*2^exponent
// mantissa is at most 2^flti_glob_prec-1
// errormant is at most 2^MAX_ERROR_PREC-1

// eps=0 means exact value
// when mantissa=0, sign should also be zero (and conversely)
// Whenever possible, numbers should be normalized
//    i.e. the high order bit of either mantissa or errormant should be
//         as far left as possible. Equivalently, the representation with the smallest
//         possible exponent should be preferred.
// Noisy zeroes are normalized on errormant
// Exact values are normalized on mantissa
// Exact zero is normalized with exponent=0 by convention

// Bound for local stack allocation purposes of temporary variables
#define MAX_LIMBS_PREC 50


typedef struct _flti {
  long sign;
  unsigned long errormant;
  long exponent;
  mp_limb_t mantissa[];
} *flti;

// Value coded is sign*(mantissa+/-errormant)*2^exponent

// return values are zero except when notifying bad events
// WARNING : ALL operands should be distincts :(

extern long flti_glob_prec;
extern mp_size_t flti_glob_nblimbs;
extern long flti_glob_allocsize;
extern void flti_setprec(long prec);
extern flti flti_allocate(long count);
extern int flti_zero(flti res);
extern int flti_cpy(flti res, flti op);
extern int flti_abs(flti res, flti op);
extern int flti_rshift_mant(flti res, flti op, long offset);
extern int flti_normalize(flti res);
// Would be nice to add increment/decrement 
extern int flti_add(flti res, flti op1, flti op2);
extern int flti_sub(flti res, flti op1, flti op2);
extern int flti_mul(flti res, flti op1, flti op2);
// Would be nice to inversion
extern int flti_div(flti res, flti op1, flti op2);
extern int flti_round(mpz_t res, flti op);
extern int mpz_to_flti(flti res, mpz_t op);
extern int DoCompareNoisyHalf(flti val);
extern int flti_from_double(flti res, double val);
extern int ClearSign(flti val);

extern int my_mpn_zero_p(mp_limb_t *op,  mp_size_t len);
extern long my_mpn_bitnum(mp_limb_t *op,  mp_size_t len);

extern int flti_mul_ui(flti res, flti op1, unsigned long op2);

