#include <gmp.h>
#include <stdlib.h>
#include "Utils.h"

#define MU_MAX_RECOMPUTE 1
#define MU_LAZY_RECOMPUTE 2

extern int VERBOSE;
extern int EARLY_PREC_DETECT;
extern int DEEP_LOVASZ;
extern int BKZ_ROUNDS;
extern int BKZ_DEPTH;
extern int BKZ_POLY_CONSTRAINT;

extern int LL_Adaptative(LatEntry *Lattice,  LatEntry *ScalProd,
			 int spacedim, int dim, int *finaldim, double csteLLL, int mupolicy);

