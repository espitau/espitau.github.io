#include "InterArith.h"
#include "math.h"

long flti_glob_prec=0;
mp_size_t flti_glob_nblimbs=0;
long flti_glob_allocsize=0;

#define mini(x,y) ((x)<(y)?(x):(y))

void flti_setprec(long prec)
{
  if ((prec<=0)||(prec>(GMP_LIMB_BITS*MAX_LIMBS_PREC))) {
    fprintf(stderr,"Bad flti precision required : %ld\n",prec);
  }
  else {
    flti_glob_prec=prec;
    flti_glob_nblimbs=(prec+GMP_LIMB_BITS-1)/GMP_LIMB_BITS;
    flti_glob_allocsize=sizeof(struct _flti)+flti_glob_nblimbs*sizeof(mp_limb_t);
  }
}

flti flti_allocate(long count)
{
  return (flti) malloc(count*flti_glob_allocsize);
}



int my_mpn_zero_p(mp_limb_t *op,  mp_size_t len)
{
  int i, iszero;
  iszero=1;
  for(i=0;i<len;i++) {
    if (op[i]) {
      iszero=0;
      break;
    }
  }
  return iszero;
}


// return number of bits necessary to encode mpn number
long my_mpn_bitnum(mp_limb_t *op,  mp_size_t len)
{
  // assume GMP_LIMB_BITS == 64
  mp_size_t i;
  long count;
  mp_limb_t tmp;
  for(i=len-1;i>=0;i--) {
    if (op[i]) break;
  }
  if (i==-1) return 0L;
  tmp=op[i];
  return (i+1)*64-__builtin_clzl(tmp);
    /*
  count=i*64;
  if (tmp>>32) {
    tmp>>=32;
    count+=32;
  }
  if (tmp>>16) {
    tmp>>=16;
    count+=16;
  }
  if (tmp>>8) {
    tmp>>=8;
    count+=8;
  }
  if (tmp>>4) {
    tmp>>=4;
    count+=4;
  }
  if (tmp>>2) {
    tmp>>=2;
    count+=2;
  }
  if (tmp>>1) {
    tmp>>=1;
    count+=1;
  }
  if (tmp) count++;
  return count;
    */
}

// return number of bits necessary to encode unsigned long
long ulong_bitnum(unsigned long op)
{
  if (op==0) return 0;
  return 64-__builtin_clzl(op);
  /*
  long count;
  unsigned long tmp;
  tmp=op;
  for(count=0;tmp;tmp>>=1,count++);
  return count;*/
}


int flti_zero(flti res)
{
  res->sign=0;
  res->errormant=0;
  res->exponent=0;
  mpn_zero (res->mantissa, flti_glob_nblimbs);
  return 0;
}

int flti_cpy(flti res, flti op)
{
  res->sign=op->sign;
  res->errormant=op->errormant;
  res->exponent=op->exponent;
  mpn_copyi(res->mantissa, op->mantissa, flti_glob_nblimbs);
  return 0;
}

int flti_abs(flti res, flti op)
{
  res->sign=op->sign;
  res->errormant=op->errormant;
  res->exponent=op->exponent;
  mpn_copyi(res->mantissa, op->mantissa, flti_glob_nblimbs);
  if ((res->sign)<0) res->sign=1;
  return 0;
}


int flti_rshift_mant(flti res, flti op, long offset)
// denormalize by shifting offset bits to the right
// result usually less precise than initial value
// offset must be at least 1
{
  long limb_offset, errordrop;
  long active_bits_count;
  mp_limb_t drop;

  if (offset<=0) return 1; // notify calling error
  
  res->sign=op->sign;
  res->exponent=(op->exponent)+offset;
  res->errormant=op->errormant;
  mpn_copyi(res->mantissa, op->mantissa, flti_glob_nblimbs);

  if (offset>=MAX_ERROR_PREC) {
    errordrop=((res->errormant)!=0);
    res->errormant=0;
  }
  else {
    errordrop=(res->errormant)&(((1UL)<<offset)-1);
    res->errormant=((op->errormant)>>offset);
  }

  //  active_bits_count=my_mpn_bitnum(op->mantissa, flti_glob_nblimbs);
  // Counting bits takes too long
  if (1/*offset<active_bits_count*/) {
    limb_offset=offset/GMP_LIMB_BITS;
    offset=offset%GMP_LIMB_BITS;
    if (limb_offset<flti_glob_nblimbs) {
      if (offset) {
	drop=mpn_rshift (res->mantissa, (op->mantissa)+limb_offset,
			 flti_glob_nblimbs-limb_offset, offset);
      }
      else {
	drop=0;
	mpn_copyi(res->mantissa, (op->mantissa)+limb_offset,
		  flti_glob_nblimbs-limb_offset);
      }
      if (my_mpn_zero_p(res->mantissa, flti_glob_nblimbs-limb_offset)) res->sign=0;

      mpn_zero ((res->mantissa)+flti_glob_nblimbs-limb_offset, limb_offset);
      if (!my_mpn_zero_p(op->mantissa,  limb_offset)) drop=1;
    }
    else {
      if (!my_mpn_zero_p(op->mantissa, flti_glob_nblimbs)) drop=1;
      mpn_zero (res->mantissa,flti_glob_nblimbs);
      res->sign=0;
    }
  }
  else {
    mpn_zero (res->mantissa,flti_glob_nblimbs);
    drop=active_bits_count?0:1;
    res->sign=0;
  }
  if (drop||errordrop) {
    (res->errormant)++;
  }
  
  return 0;
}

int flti_normalize(flti res)
// left shift mantissa and error as far as possible
// change exponent accordingly
{
  long nbmantbits, nberrorbits;
  long shiftcount;
  mp_limb_t carry; mp_size_t limb_offset;


  nbmantbits=my_mpn_bitnum(res->mantissa,  flti_glob_nblimbs);
  nberrorbits=ulong_bitnum(res->errormant);

  // Assert some correctness
  if ((nbmantbits==0)&&(res->sign)) {
    fprintf(stderr,"Zero mantissa / Non zero sign ??? \n");
    exit(1);
  }
  if ((nbmantbits!=0)&&((res->sign)==0)) {
    fprintf(stderr,"Non zero mantissa / Zero sign ??? \n");
    exit(1);
  }
  if ((nbmantbits>flti_glob_prec) || (nberrorbits>MAX_ERROR_PREC)){
    fprintf(stderr,"OUPS: Mantissa or error overflow ??? \n");
    exit(1);
  }

  // If everything is zero just normalize exponent to zero
  if ((nbmantbits==0)&&(nberrorbits==0)) return (res->exponent=0);


  // Mant or error has full prec, do nothing
  if ((nbmantbits==flti_glob_prec) || (nberrorbits==MAX_ERROR_PREC)) return 0;

  if (nberrorbits) {
    shiftcount=mini(MAX_ERROR_PREC-nberrorbits,flti_glob_prec-nbmantbits);
    res->errormant<<=shiftcount;
    carry=mpn_lshift (res->mantissa, res->mantissa, flti_glob_nblimbs, shiftcount);
    res->exponent-=shiftcount;
  }
  else {  // special case -- Error is zero -- do full normalization of mantissa
    shiftcount=flti_glob_prec-nbmantbits;
    limb_offset=shiftcount/GMP_LIMB_BITS;
    res->exponent-=shiftcount;
    shiftcount=shiftcount%GMP_LIMB_BITS;
    if (shiftcount) {
      carry=mpn_lshift (res->mantissa+limb_offset, res->mantissa,
			flti_glob_nblimbs-limb_offset, shiftcount);
    }
    else {
      mpn_copyi(res->mantissa+limb_offset, res->mantissa,
		flti_glob_nblimbs-limb_offset);
      carry=0;
    }
    mpn_zero (res->mantissa, limb_offset);
  }
  if (carry) {
    fprintf(stderr,"OUPS: Carry not possible during normalization ??? \n");
    exit(1);
  }
  return 0;
}

int flti_abs_addtores_commonexponent(flti res, flti op)
{
  mp_limb_t carry, drop;
  int errorstuff;

  res->errormant+=op->errormant;
  carry=mpn_add_n(res->mantissa, res->mantissa, op->mantissa, flti_glob_nblimbs);

  if (carry||((res->errormant)>=(1UL<<MAX_ERROR_PREC))) {
    drop=mpn_rshift (res->mantissa, res->mantissa, flti_glob_nblimbs, 1);
    if (carry) (res->mantissa)[flti_glob_nblimbs-1]+=((mp_limb_t)1)<<(GMP_LIMB_BITS-1);
    errorstuff=(res->errormant)&1;
    (res->errormant)>>=1;
    if (errorstuff||drop) (res->errormant)++;    
    (res->exponent)++;
  }
  // Rarely error may become too big again due to increment
  if ((res->errormant)>=(1UL<<MAX_ERROR_PREC)) {
    drop=mpn_rshift (res->mantissa, res->mantissa, flti_glob_nblimbs, 1);
    errorstuff=(res->errormant)&1;
    (res->errormant)>>=1;
    if (errorstuff||drop) (res->errormant)++;    
    (res->exponent)++;
  }
  // This is a rare event -- might be possible to not test every time -- if perfs require
  if (my_mpn_zero_p(res->mantissa, flti_glob_nblimbs)) {
    res->sign=0;
  }
  else {
    if (res->sign==0) {
      fprintf(stderr,"OUPS: Zero sign predicted, yet non zero mantissa after addition !\n");
      exit(1);
    }
  }
  return 0;
}

int flti_abs_subtores_commonexponent(flti res, flti op)
{
  mp_limb_t carry, drop;
  int errorstuff,signflag;

  res->errormant+=op->errormant;

  if (mpn_cmp (res->mantissa, op->mantissa, flti_glob_nblimbs)>0) {
    signflag=1;
    carry=mpn_sub_n (res->mantissa, res->mantissa, op->mantissa, flti_glob_nblimbs);
  }
  else {
    signflag=-1;
    carry=mpn_sub_n (res->mantissa, op->mantissa, res->mantissa, flti_glob_nblimbs);
  }

  // Rarely error may become too big again due to increment
  // Do it with a loop (at most 2 executions)
  while ((res->errormant)>=(1UL<<MAX_ERROR_PREC)) {
    drop=mpn_rshift (res->mantissa, res->mantissa, flti_glob_nblimbs, 1);
    errorstuff=(res->errormant)&1;
    (res->errormant)>>=1;
    if (errorstuff||drop) (res->errormant)++;    
    (res->exponent)++;
  }
  // Not so rare with subtract -- maybe the test can be sometimes avoided
  if (my_mpn_zero_p(res->mantissa, flti_glob_nblimbs)) {
    res->sign=0;
  }
  else {
    res->sign*=signflag;
    if (res->sign==0) {
      fprintf(stderr,"OUPS: Zero sign predicted, yet non zero mantissa after addition !\n");
      exit(1);
    }
  }
  // Need to renormalize after subtraction
  return flti_normalize(res);
}


int flti_add(flti res, flti op1, flti op2)
// Assume that numbers are normalized
// Otherwise unnecessary precision loss occurs
{
  long diff, offset;
  flti l_op1, l_op2;

  // Addition of exact zeroes does nothing
  if ((op1->sign==0)&&(op1->errormant==0)) return flti_cpy(res, op2);
  if ((op2->sign==0)&&(op2->errormant==0)) return flti_cpy(res, op1);

  // Align to largest normalized exponent
  if ((op1->exponent)>=(op2->exponent)) {
    l_op1=op1; l_op2=op2;}
  else {
    l_op1=op2; l_op2=op1;}
  
  diff=(l_op1->exponent)-(l_op2->exponent);
  if (diff==0) {
    flti_cpy(res, l_op2);
  }
  else {
    flti_rshift_mant(res, l_op2, diff);
  }
  
  if ((l_op1->sign)==-(res->sign)) {
    // Attention au signe surtout si inversion
    return flti_abs_subtores_commonexponent(res, l_op1);
  }
  else if (res->sign==0)
    res->sign=l_op1->sign;
  return flti_abs_addtores_commonexponent(res, l_op1);
}

int flti_sub(flti res, flti op1, flti op2)
{
  int retcode;

  op2->sign=-(op2->sign);
  retcode=flti_add(res, op1, op2);
  op2->sign=-(op2->sign);

  return retcode;
}

int flti_mul(flti res, flti op1, flti op2)
{
  mp_limb_t mantiss[2*MAX_LIMBS_PREC];
  mp_limb_t errormanti[MAX_LIMBS_PREC+2];
  mp_limb_t drop, errordrop;
  long mantissashift, errorshift;
  long nbbitsmul, offset, limb_offset;

  drop=0;
  if (((op1->sign)==0)||((op2->sign)==0)) {
    flti_zero(res);
    mantissashift=0;
  }
  else {
    res->sign=(op1->sign)*(op2->sign);
    mpn_mul_n (mantiss, op1->mantissa, op2->mantissa, flti_glob_nblimbs);
    nbbitsmul=my_mpn_bitnum(mantiss,  2*flti_glob_nblimbs);
    if (nbbitsmul <=flti_glob_prec) {
      mpn_copyi(res->mantissa, mantiss, flti_glob_nblimbs);
      mantissashift=0;
    }
    else {
      mantissashift=nbbitsmul-flti_glob_prec;
      limb_offset=mantissashift/GMP_LIMB_BITS;
      offset=mantissashift%GMP_LIMB_BITS;
      if (offset) {
	mpn_lshift (mantiss, mantiss,
		    limb_offset+flti_glob_nblimbs+1, GMP_LIMB_BITS-offset);
	limb_offset++;
      }
      mpn_copyi(res->mantissa, mantiss+limb_offset,flti_glob_nblimbs);
      if (!my_mpn_zero_p(mantiss,limb_offset)) drop=1; else drop=0;
    }
  }

  mpn_zero(errormanti,flti_glob_nblimbs+2);
  errormanti[0]=(op1->errormant)*(op2->errormant);
  if ((op1->errormant)&&(op2->sign)) {
    errormanti[flti_glob_nblimbs]+=mpn_addmul_1 (errormanti, op2->mantissa, flti_glob_nblimbs,
						 (mp_limb_t) (op1->errormant));
  }
  if ((op2->errormant)&&(op1->sign)) {
    errormanti[flti_glob_nblimbs]+=mpn_addmul_1 (errormanti, op1->mantissa, flti_glob_nblimbs,
						 (mp_limb_t) (op2->errormant));
  }

  nbbitsmul=my_mpn_bitnum(errormanti,  flti_glob_nblimbs+1);
  if (nbbitsmul<=MAX_ERROR_PREC) {
    res->errormant=errormanti[0];
    errorshift=0;
    errordrop=0;
  }
  else {
    errorshift=nbbitsmul-MAX_ERROR_PREC;
    limb_offset=nbbitsmul/GMP_LIMB_BITS;
    offset=nbbitsmul%GMP_LIMB_BITS;
    if (offset>=MAX_ERROR_PREC) {
      res->errormant=errormanti[limb_offset]>>(offset-MAX_ERROR_PREC);
      errordrop=1;
    }
    else {
      res->errormant=(errormanti[limb_offset]<<(MAX_ERROR_PREC-offset)) |
	(errormanti[limb_offset-1]>>(GMP_LIMB_BITS+offset-MAX_ERROR_PREC));
      errordrop=1;
    }
  }

  if (mantissashift>errorshift) {
    res->exponent=(op1->exponent)+(op2->exponent)+mantissashift;
    if ((mantissashift-errorshift)>=MAX_ERROR_PREC) {
      if (res->errormant) errordrop=1;
      res->errormant=0;
    }
    else {
      offset=mantissashift-errorshift;
      if ((res->errormant)&((1UL<<offset)-1)) errordrop=1;
      res->errormant>>=offset;
    }
  }
  else if (errorshift>mantissashift) {
    long nbbitsmul, offset, limb_offset;
    res->exponent=(op1->exponent)+(op2->exponent)+errorshift;
    offset=errorshift-mantissashift;
    if (offset>=flti_glob_prec) {
      if (!my_mpn_zero_p(res->mantissa, flti_glob_nblimbs)) drop=1;
      mpn_zero(res->mantissa, flti_glob_nblimbs);
    }
    else {
      limb_offset=offset/GMP_LIMB_BITS;
      offset=offset%GMP_LIMB_BITS;
      
      if (!my_mpn_zero_p(res->mantissa,  limb_offset)) drop=1;
      if (offset) {
	if (mpn_rshift(res->mantissa, (res->mantissa)+limb_offset,
		       flti_glob_nblimbs-limb_offset, offset)) drop=1;
      }
      else {
	mpn_copyi(res->mantissa,(res->mantissa)+limb_offset, flti_glob_nblimbs-limb_offset);
      }
      mpn_zero((res->mantissa)+flti_glob_nblimbs-limb_offset,limb_offset);
    }
  }
  else { // errorshift == mantissashift
    res->exponent=(op1->exponent)+(op2->exponent)+mantissashift;
  }

  if (drop||errordrop) {
    res->errormant++;
  }
  
  while ((res->errormant)>=(1UL<<MAX_ERROR_PREC)) {
    drop=mpn_rshift (res->mantissa, res->mantissa, flti_glob_nblimbs, 1);
    errordrop=(res->errormant)&1;
    (res->errormant)>>=1;
    if (errordrop||drop) (res->errormant)++;    
    (res->exponent)++;
  }

  if (my_mpn_zero_p(res->mantissa, flti_glob_nblimbs)) res->sign=0;

  return 0;   
}

int flti_div(flti res, flti op1, flti op2)
{
  mp_limb_t mantiss[2*MAX_LIMBS_PREC];
  mp_limb_t divisor[MAX_LIMBS_PREC+1];
  mp_limb_t quotient_hi[MAX_LIMBS_PREC+2];
  mp_limb_t quotient_low[MAX_LIMBS_PREC+2];
  mp_limb_t quotient_sum[MAX_LIMBS_PREC+2];
  mp_limb_t quotient_diff[MAX_LIMBS_PREC+2];
  mp_limb_t drop, errordrop;
  long mantissashift, errorshift, divisor_words;
  long nbbitsmul, offset, limb_offset;
  int opposite_signs;

  // Do it with two long divisions for simplicity Minop1/Maxop2 and Maxop1/Minop2 

  if (((op2->sign)==0)||
      (mpn_sub_1(divisor, op2->mantissa, flti_glob_nblimbs, (mp_limb_t) op2->errormant))){
    return 1;
  }

  if (((op1->sign)==0)&&((op1->errormant)==0)) {
    flti_zero(res);
    return 0;
  }

  for(divisor_words=flti_glob_nblimbs-1;divisor_words>=0;divisor_words--) {
    if (divisor[divisor_words]) break;
  }
  divisor_words++;
  mpn_copyi(mantiss, divisor, divisor_words);
  mantiss[flti_glob_nblimbs+divisor_words]=
    mpn_add_1(mantiss+divisor_words, op1->mantissa, flti_glob_nblimbs, (mp_limb_t) op1->errormant);
  
  mpn_tdiv_qr (quotient_hi, quotient_diff /*discard remainder*/, 0,
	       mantiss, flti_glob_nblimbs+divisor_words+1,
	       divisor, divisor_words);

  offset=divisor_words;
  mpn_zero(mantiss, divisor_words);
  if (mpn_sub_1(mantiss+divisor_words, op1->mantissa, flti_glob_nblimbs, (mp_limb_t) op1->errormant)){
    opposite_signs=1;
    mpn_neg (mantiss+divisor_words, mantiss+divisor_words, flti_glob_nblimbs);
    mpn_copyi(mantiss, divisor, divisor_words);
  }
   else {
    opposite_signs=0;
    divisor[flti_glob_nblimbs]=mpn_add_1(divisor, op2->mantissa, flti_glob_nblimbs, (mp_limb_t) op2->errormant);
    for(divisor_words=flti_glob_nblimbs-1;divisor_words>=0;divisor_words--) {
      if (divisor[divisor_words]) break;
    }
    divisor_words++;
    if (divisor_words!=offset) {
      mpn_zero(mantiss, divisor_words);
      if (mpn_sub_1(mantiss+divisor_words, op1->mantissa, flti_glob_nblimbs, (mp_limb_t) op1->errormant)){
	fprintf(stderr,"OUPS: Unexpected in division\n");
	exit(1);
      }
    }
  }
 
  mpn_tdiv_qr (quotient_low, quotient_diff /*discard remainder*/, 0,
	       mantiss, flti_glob_nblimbs+divisor_words,
	       divisor, divisor_words);

  quotient_low[flti_glob_nblimbs+1]=0;

  if (!opposite_signs) {
    if (mpn_add_n(quotient_sum,quotient_hi,quotient_low,flti_glob_nblimbs+2)) {
      fprintf(stderr,"Unexpected carry, please change code to deal with it :( !\n");
      exit(1);
    }
    if (mpn_sub_n(quotient_diff,quotient_hi,quotient_low,flti_glob_nblimbs+2)) {
      fprintf(stderr,"Unexpected borrow, please change code to deal with it :( !\n");
      exit(1);
    }
  }
  else {
    if (mpn_add_n(quotient_diff,quotient_hi,quotient_low,flti_glob_nblimbs+2)) {
      fprintf(stderr,"Unexpected carry, please change code to deal with it -- opposite :( !\n");
      exit(1);
    }
    if (mpn_sub_n(quotient_sum,quotient_hi,quotient_low,flti_glob_nblimbs+2)) {
      fprintf(stderr,"Unexpected borrow, please change code to deal with it -- opposite :( !\n");
      exit(1);
    }
  }

  // quotient_sum  holds 2*res_mantissa
  // quotient_diff holds 2*res_errormant

  nbbitsmul=my_mpn_bitnum(quotient_sum,  flti_glob_nblimbs+2);
  if (nbbitsmul<=flti_glob_prec) {
    // gare a l'exposant
    mpn_copyi(res->mantissa, quotient_sum,flti_glob_nblimbs);
    mantissashift=0;
    drop=0;
  }
  else {
    mantissashift=nbbitsmul-flti_glob_prec;
    limb_offset=mantissashift/GMP_LIMB_BITS;
    offset=mantissashift%GMP_LIMB_BITS;
    if (offset) {
      mpn_lshift (quotient_sum, quotient_sum,
		  limb_offset+flti_glob_nblimbs+1, GMP_LIMB_BITS-offset);
      limb_offset++;
    }
    mpn_copyi(res->mantissa, quotient_sum+limb_offset,flti_glob_nblimbs);
    if (!my_mpn_zero_p(quotient_sum,limb_offset)) drop=1; else drop=0;
  }
  
  nbbitsmul=my_mpn_bitnum(quotient_diff,  flti_glob_nblimbs+2);
  if (nbbitsmul<=MAX_ERROR_PREC) {
    res->errormant=quotient_diff[0];
    errorshift=0;
    errordrop=0;
  }
  else {
    errorshift=nbbitsmul-MAX_ERROR_PREC;
    limb_offset=nbbitsmul/GMP_LIMB_BITS;
    offset=nbbitsmul%GMP_LIMB_BITS;
    if (offset>=MAX_ERROR_PREC) {
      res->errormant=quotient_diff[limb_offset]>>(offset-MAX_ERROR_PREC);
      errordrop=1;
    }
    else {
      res->errormant=(quotient_diff[limb_offset]<<(MAX_ERROR_PREC-offset)) |
	(quotient_diff[limb_offset-1]>>(GMP_LIMB_BITS+offset-MAX_ERROR_PREC));
      errordrop=1;
    }
  }

  if (mantissashift>errorshift) {
    res->exponent=(op1->exponent)-(op2->exponent)+mantissashift-1-divisor_words*GMP_LIMB_BITS; // -1 to adjust for 2* above
    if ((mantissashift-errorshift)>=MAX_ERROR_PREC) {
      if (res->errormant) errordrop=1;
      res->errormant=0;
    }
    else {
      offset=mantissashift-errorshift;
      if ((res->errormant)&((1UL<<offset)-1)) errordrop=1;
      res->errormant>>=offset;
    }
  }
  else if (errorshift>mantissashift) {
    res->exponent=(op1->exponent)-(op2->exponent)+errorshift-1-divisor_words*GMP_LIMB_BITS;
    offset=errorshift-mantissashift;
    if (offset>=flti_glob_prec) {
      if (!my_mpn_zero_p(res->mantissa, flti_glob_nblimbs)) drop=1;
      mpn_zero(res->mantissa, flti_glob_nblimbs);
    }
    else {
      limb_offset=offset/GMP_LIMB_BITS;
      offset=offset%GMP_LIMB_BITS;
      
      if (!my_mpn_zero_p(res->mantissa,  limb_offset)) drop=1;
      if (offset) {
	if (mpn_rshift(res->mantissa, (res->mantissa)+limb_offset,
		       flti_glob_nblimbs-limb_offset, offset)) drop=1;
      }
      else {
	mpn_copyi(res->mantissa,(res->mantissa)+limb_offset, flti_glob_nblimbs-limb_offset);
      }
      mpn_zero((res->mantissa)+flti_glob_nblimbs-limb_offset,limb_offset);
    }
  }
  else { // errorshift == mantissashift
    res->exponent=(op1->exponent)-(op2->exponent)+mantissashift-1-divisor_words*GMP_LIMB_BITS;
  }

  if (drop||errordrop) {
    res->errormant++;
  }
  
  while ((res->errormant)>=(1UL<<MAX_ERROR_PREC)) {
    drop=mpn_rshift (res->mantissa, res->mantissa, flti_glob_nblimbs, 1);
    errordrop=(res->errormant)&1;
    (res->errormant)>>=1;
    if (errordrop||drop) (res->errormant)++;    
    (res->exponent)++;
  }

  res->sign=(op1->sign)*(op2->sign);
  if (my_mpn_zero_p(res->mantissa, flti_glob_nblimbs)) res->sign=0;

  return 0;   
}



int flti_round(mpz_t res, flti op)
{
  int i;
  // No nice way to convert from mpn to mpz :(

  mpz_set_ui(res,0UL);
  for(i=flti_glob_nblimbs-1;i>=0;i--) {
    mpz_mul_2exp(res,res,GMP_LIMB_BITS);
    mpz_add_ui(res,res,(op->mantissa)[i]);
  }
  if ((op->sign)==-1) mpz_neg(res,res);
  if ((op->exponent)>0) mpz_mul_2exp(res,res,op->exponent);
  if ((op->exponent)<0) {
    if ((op->exponent)<-1) mpz_fdiv_q_2exp(res,res,-(op->exponent)-1);
     mpz_add_ui(res,res,1UL);
     mpz_fdiv_q_2exp(res,res,1);
  }
  return 0;
}


int mpz_to_flti(flti res, mpz_t op)
{
  // Beware: conversion can be exact or not
  long mpzsize, totbits, offset, limb_offset;
  mp_limb_t drop;

  drop=0;
  mpzsize=op->_mp_size;
  if (mpzsize==0) return flti_zero(res);
  if (mpzsize<0) {
    res->sign=-1;
    mpzsize=-mpzsize;
  }
  else res->sign=1;
  totbits=my_mpn_bitnum(op->_mp_d,  mpzsize);
  if (totbits==0) return flti_zero(res);
  if (totbits<=flti_glob_prec) { // Exact value can be stored
    mpn_zero (res->mantissa, flti_glob_nblimbs);
    mpn_copyi(res->mantissa, op->_mp_d, (totbits+GMP_LIMB_BITS-1)/GMP_LIMB_BITS);
    res->exponent=0;
    res->errormant=0;
    return flti_normalize(res);
  }
  else {
    offset=totbits-flti_glob_prec;
    res->exponent=offset;
    limb_offset=offset/GMP_LIMB_BITS;
    offset%=GMP_LIMB_BITS;
    if (offset) {
      drop=mpn_rshift(res->mantissa, (op->_mp_d)+limb_offset,
		      flti_glob_nblimbs, offset);
      (res->mantissa)[flti_glob_nblimbs-1]+=(op->_mp_d)[limb_offset+flti_glob_nblimbs]<<(GMP_LIMB_BITS-offset);
    }
    else {
      mpn_copyi(res->mantissa, (op->_mp_d)+limb_offset,flti_glob_nblimbs);
    }
    if (!my_mpn_zero_p(op->_mp_d,  limb_offset)) drop=1;
    if (drop) res->errormant=1;
    // no need to normalize here
    return 0;
  }
}



int DoCompareNoisyHalf(flti val)
{
  long nbmantbits,nberrorbits;
  long maxval,minval,midval;

  if ((val->sign)==1) {
    nbmantbits=my_mpn_bitnum(val->mantissa,  flti_glob_nblimbs);
    nberrorbits=ulong_bitnum(val->errormant);
    if ((nbmantbits>nberrorbits)||
	((nbmantbits==nberrorbits)&&((val->mantissa)[0]>val->errormant))){
      if ((nbmantbits+(val->exponent))<=-2) return -1;
      if ((nbmantbits+(val->exponent))>0) return 1;
      if (((nbmantbits-1)%GMP_LIMB_BITS)>=(MAX_ERROR_PREC-1)) {
	maxval=(val->mantissa)[(nbmantbits-1)/GMP_LIMB_BITS]>>(((nbmantbits-1)%GMP_LIMB_BITS)-(MAX_ERROR_PREC-1));
      }
      else {
	maxval=(val->mantissa)[(nbmantbits-1)/GMP_LIMB_BITS]<<((MAX_ERROR_PREC-1)-((nbmantbits-1)%GMP_LIMB_BITS));
	maxval+=(val->mantissa)[(nbmantbits-1)/GMP_LIMB_BITS-1]>>
	  (GMP_LIMB_BITS+((nbmantbits-1)%GMP_LIMB_BITS)-(MAX_ERROR_PREC-1));
      }
      minval=maxval;
      midval=maxval;
      if ((nbmantbits-nberrorbits)<=MAX_ERROR_PREC) {
	maxval+=(val->errormant)>>(nbmantbits-nberrorbits);
	minval-=(val->errormant)>>(nbmantbits-nberrorbits);
      }
      if ((nbmantbits+(val->exponent))==-1) {
	maxval>>=1;
	minval>>=1;
      }

      if ((maxval<1095216659L)&&(minval>1052266989L)) {
	if (midval>=1073741824L) return -1;
	else return 1;
      }
      if (maxval<1095216659L) return -1;
      if (minval>1052266989L) return 1;
      return 0;
    }
    else {
      if ((nberrorbits+(val->exponent))<=-2) return -1;
      if ((nberrorbits+(val->exponent))>0) return 0; // both large pos and neg !
      maxval=(val->errormant)+((val->mantissa[0])>>(nberrorbits-nbmantbits));
      if ((nberrorbits+(val->exponent))==-1) maxval>>=1;
      if (maxval<1095216659L) return -1;
      return 0;
    }
  }
  else if ((val->sign)==0) {
    if ((val->errormant)==0) return -1;
    nberrorbits=ulong_bitnum(val->errormant);
    if ((nberrorbits+(val->exponent))<=-1) return -1;
    if ((nberrorbits+(val->exponent))>0) return 0;
    if (nberrorbits!=MAX_ERROR_PREC) {
      fprintf(stderr,"Unexpected case, abort !\n");
      exit(1);
    }
    if ((val->errormant)<1095216660UL) return -1;
    return 0;
  }
  else {
    fprintf(stderr,"Unexpected case, abort !\n");
    exit(1);
  }
}


int ClearSign(flti val)
{
  long nbmantbits,nberrorbits;

  if ((val->sign)==0) return 0;

  nbmantbits=my_mpn_bitnum(val->mantissa,  flti_glob_nblimbs);
  nberrorbits=ulong_bitnum(val->errormant);
  if (nbmantbits>nberrorbits) return val->sign;
  if ((val->mantissa[0])>(val->errormant)) return val->sign;
  return 0;
}

int flti_from_double(flti res, double val)
{
  double nval;
  int expo;
  long basemant;

  flti_zero(res);
  if (val==0.0) return 0;
  if (val>0.0) res->sign=1; else {val=-val; res->sign=-1;}
  
  nval=frexp(val, &expo);
  nval=scalbn(nval, 54);
  basemant=nval;
  expo-=54;

  res->exponent=expo;
  res->errormant=1; 
  res->mantissa[0]=basemant;
  
  return flti_normalize(res);
}


int flti_mul_ui(flti res, flti op1, unsigned long op2)
{

  mp_limb_t mantiss[MAX_LIMBS_PREC+1];
  unsigned long errormanti;
  mp_limb_t drop, errordrop;
  long mantissashift, errorshift;
  long nbbitsmul, offset, limb_offset;

  if (op2>0xffffffffU){
    fprintf(stderr,"Overflow assumption for multiplication by small\n");
    exit(1);
  }
  if (op2==0) {
    return flti_zero(res);
  }
  drop=0;
  if ((op1->sign)==0) {
    flti_zero(res);
    mantissashift=0;
  }
  else {
    res->sign=(op1->sign);
    mantiss[flti_glob_nblimbs]=mpn_mul_1(mantiss, op1->mantissa, flti_glob_nblimbs, (mp_limb_t) op2);
    nbbitsmul=my_mpn_bitnum(mantiss,  flti_glob_nblimbs+1);
    if (nbbitsmul<=flti_glob_prec) {
      mpn_copyi(res->mantissa, mantiss, flti_glob_nblimbs);
      mantissashift=0;
    }
    else {
      mantissashift=nbbitsmul-flti_glob_prec;
      drop=mpn_rshift (mantiss, mantiss, flti_glob_nblimbs+1, mantissashift);
      mpn_copyi(res->mantissa, mantiss,flti_glob_nblimbs);
      if (drop) drop=1;
    }
  }

  
  errormanti=(op1->errormant)*op2;
  nbbitsmul=ulong_bitnum(errormanti);
  if (nbbitsmul<=MAX_ERROR_PREC) {
    res->errormant=errormanti;
    errorshift=0;
    errordrop=0;
  }
  else {
    res->errormant=errormanti>>(nbbitsmul-MAX_ERROR_PREC);
    errorshift=nbbitsmul-MAX_ERROR_PREC;
    if (errormanti&((1UL<<(nbbitsmul-MAX_ERROR_PREC))-1)) errordrop=1;
  }

  if (mantissashift>errorshift) {
    res->exponent=(op1->exponent)+mantissashift;
    if ((mantissashift-errorshift)>=MAX_ERROR_PREC) {
      if (res->errormant) errordrop=1;
      res->errormant=0;
    }
    else {
      offset=mantissashift-errorshift;
      if ((res->errormant)&((1UL<<offset)-1)) errordrop=1;
      res->errormant>>=offset;
    }
  }
  else if (errorshift>mantissashift) {
    long nbbitsmul, offset, limb_offset;
    res->exponent=(op1->exponent)+errorshift;
    offset=errorshift-mantissashift;
    if (offset>=flti_glob_prec) {
      if (!my_mpn_zero_p(res->mantissa, flti_glob_nblimbs)) drop=1;
      mpn_zero(res->mantissa, flti_glob_nblimbs);
    }
    else {
      limb_offset=offset/GMP_LIMB_BITS;
      offset=offset%GMP_LIMB_BITS;
      
      if (!my_mpn_zero_p(res->mantissa,  limb_offset)) drop=1;
      if (offset) {
	if (mpn_rshift(res->mantissa, (res->mantissa)+limb_offset,
		       flti_glob_nblimbs-limb_offset, offset)) drop=1;
      }
      else {
	mpn_copyi(res->mantissa,(res->mantissa)+limb_offset, flti_glob_nblimbs-limb_offset);
      }
      mpn_zero((res->mantissa)+flti_glob_nblimbs-limb_offset,limb_offset);
    }
  }
  else { // errorshift == mantissashift
    res->exponent=(op1->exponent)+mantissashift;
  }

  if (drop||errordrop) {
    res->errormant++;
  }
  
  while ((res->errormant)>=(1UL<<MAX_ERROR_PREC)) {
    drop=mpn_rshift (res->mantissa, res->mantissa, flti_glob_nblimbs, 1);
    errordrop=(res->errormant)&1;
    (res->errormant)>>=1;
    if (errordrop||drop) (res->errormant)++;    
    (res->exponent)++;
  }

  if (my_mpn_zero_p(res->mantissa, flti_glob_nblimbs)) res->sign=0;
  return 0;   
}


