#include "InterArith.h"

typedef mpz_t LatEntry;
typedef flti GramEntry;

#define InitLatEntry(val) mpz_init(val)

#define DelLatEntry(val) mpz_clear(val)

#define ZeroLatEntry(val) mpz_set_si(val,0)
#define ZeroGramEntry(val) flti_zero(val)

#define LatEntryFromString(val,str,base) mpz_set_str(val,str,base)
#define ReadLatEntry(val) gmp_scanf("%Zd",val)
#define WriteLatEntry(val) gmp_printf("%Zd",val)

#define LatEntryToGram(gram,lat) mpz_to_flti(gram, lat)
#define CtseEntryToLat(lat,cste) mpz_set_si(lat, cste)
#define LatCmpCste(op,cste) mpz_cmp_si(op, cste)

#define LatAdd(res,op1,op2) mpz_add(res,op1,op2)
#define LatSub(res,op1,op2) mpz_sub(res,op1,op2)
#define LatMul(res,op1,op2) mpz_mul(res,op1,op2)
#define LatDiv(res,op1,op2) mpz_div(res,op1,op2)
#define LatMulPow2(res,op1,exp) mpz_mul_2exp(res, op1, exp)
#define LatDivPow2(res,op1,exp) mpz_div_2exp(res, op1, exp)
#define LatSwap(op1,op2) mpz_swap(op1,op2)
#define LatCpy(res,op) mpz_set(res,op)
#define LatSign(op) mpz_sgn(op)
#define LatNonZero(op) ((op)->_mp_size)

#define GramSetPrec(nbbits) flti_setprec(nbbits)

#define GramSetFromCst(res,val) flti_from_double(res,val)

#define GramSign(op) ClearSign(op)
#define GramCpy(res,op) flti_cpy(res,op)
#define GramAdd(res,op1,op2) flti_add(res,op1,op2)
#define GramMulSmall(res,op1,op2) flti_mul_ui(res,op1,op2)
#define GramSub(res,op1,op2) flti_sub(res,op1,op2)
#define GramMul(res,op1,op2) flti_mul(res,op1,op2)
#define GramDivide(res,op1,op2) flti_div(res,op1,op2)
#define GramAbs(res,op) flti_abs(res, op)

#define RoundGramEntryToLat(rounded, val) flti_round(rounded, val)


int AllocAndRead(LatEntry **LatticePtr, int *spacedimPtr, int *dimPtr, int dim_add_margin, int dim_mul_margin);
int   AllocLat(LatEntry **LatPtr, int spacedim, int dim);
int   AllocGram(GramEntry **GramPtr, int spacedim, int dim);
void UnAllocLat(LatEntry **LatPtr, int spacedim, int dim);
void UnAllocGram(GramEntry **GramPtr, int spacedim, int dim);
void  WriteLattice(LatEntry *Lattice, int spacedim, int dim);
void  NTLWriteLattice(LatEntry *Lattice, int spacedim, int dim);
void  GPWriteLattice(LatEntry *Lattice, int spacedim, int dim);
