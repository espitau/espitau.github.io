#include "LLL.h"
#include <time.h>
#include <math.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/time.h>

int VERBOSE=1;
int EARLY_PREC_DETECT=0;
int DEEP_LOVASZ=0;
int BKZ_ROUNDS=0;
int BKZ_DEPTH=0;
int BKZ_POLY_CONSTRAINT=1;

volatile int userwantexit=0;

typedef struct _lllparam {
  LatEntry *Lattice;
  LatEntry *ScalProd;
  LatEntry *ExactScals;
  GramEntry *GramR;
  GramEntry *GramM;
  GramEntry *GramS;
  GramEntry LLLCste;
  int spacedim;
  int allocdim;
  int dim;
  int *muinvalidfrom;
  GramEntry mu;
  GramEntry Tmp;
  GramEntry Quo;
  GramEntry Scal;
  GramEntry mubis;
  GramEntry muter;
  GramEntry Scalneg;
  GramEntry Scalpos;
  GramEntry MinusOne;
  LatEntry *LatTmp_ptr;
  LatEntry *exScalar_ptr;
  LatEntry *RoundedQuo_ptr;

  //Parameters for BKZ
  LatEntry *EnumCoeffs;
  LatEntry *EnumCoeffsDump;
  GramEntry enumbound;
  GramEntry *MuOfEnum;
  GramEntry *LocalNorms;
  GramEntry *SavedScals;
} LLL_PARAMS;


int LowLevelExactMinusDotProduct(GramEntry Scal, LatEntry BaseVal,
				 GramEntry *Vec1, GramEntry *Vec2, int len)
{
  mp_limb_t mantiss[2*MAX_LIMBS_PREC];
  mp_limb_t errormanti[MAX_LIMBS_PREC+3];
  mp_limb_t mantiss_pos_accum[2*MAX_LIMBS_PREC+1];
  mp_limb_t mantiss_neg_accum[2*MAX_LIMBS_PREC+1];
  mp_limb_t erroraccum[MAX_LIMBS_PREC+2];
  mp_limb_t drop, errordrop, carry;

  long glob_exponent, offset, limb_offset, nbbitsmul;
  long mantissashift,errorshift;
  int i,sgn;
  
  long mpzsize, full_mul_size, full_error_size, maxexponent;

  full_mul_size=2*flti_glob_nblimbs+1;
  full_error_size=flti_glob_nblimbs+1;
  mpn_zero (erroraccum, full_error_size);

  maxexponent=-full_mul_size*GMP_LIMB_BITS;
  for(i=0;i<len;i++) {
    if (((Vec1[i]->sign)||(Vec1[i]->errormant)) &&
	((Vec2[i]->sign)||(Vec2[i]->errormant))) {
      if ((Vec1[i]->exponent)+(Vec2[i]->exponent)>maxexponent) {
	maxexponent=(Vec1[i]->exponent)+(Vec2[i]->exponent);
      }
    }
  }

  mpzsize=BaseVal->_mp_size;
  if (mpzsize==0) {
    glob_exponent=maxexponent;
    mpn_zero (mantiss_pos_accum, full_mul_size);
    mpn_zero (mantiss_neg_accum, full_mul_size);
  }
  else {
    if (mpzsize>0) {
      glob_exponent=(mpzsize-full_mul_size)*GMP_LIMB_BITS;
      if (mpzsize > full_mul_size) {
	mpn_copyi(mantiss_pos_accum, (BaseVal->_mp_d)+mpzsize-full_mul_size, full_mul_size);
	mpn_zero (mantiss_neg_accum, full_mul_size);
	erroraccum[0]=1;
      }
      else {
	mpn_zero (mantiss_pos_accum, full_mul_size-mpzsize);
	mpn_copyi(mantiss_pos_accum+full_mul_size-mpzsize, (BaseVal->_mp_d), mpzsize);
	mpn_zero (mantiss_neg_accum, full_mul_size);
      }
    }
    else {
      mpzsize=-mpzsize;
      glob_exponent=(mpzsize-full_mul_size)*GMP_LIMB_BITS;
      if (mpzsize > full_mul_size) {
	mpn_copyi(mantiss_neg_accum, (BaseVal->_mp_d)+mpzsize-full_mul_size, full_mul_size);
	mpn_zero (mantiss_pos_accum, full_mul_size);
	erroraccum[0]=1;
      }
      else {
	mpn_zero (mantiss_neg_accum, full_mul_size-mpzsize);
	mpn_copyi(mantiss_neg_accum+full_mul_size-mpzsize, (BaseVal->_mp_d), mpzsize);
	mpn_zero (mantiss_pos_accum, full_mul_size);
      }
    }

    if (maxexponent>glob_exponent) {
      // fprintf(stderr,"maxexponent=%d vs glob_exponent=%d\n", maxexponent,glob_exponent);
      offset=maxexponent-glob_exponent;
      limb_offset=offset/GMP_LIMB_BITS;
      offset=offset%GMP_LIMB_BITS;
      if (limb_offset<full_mul_size) {
	if (offset) {
	  mpn_rshift(mantiss_pos_accum, mantiss_pos_accum+limb_offset,
		     full_mul_size-limb_offset, offset);
	  mpn_rshift(mantiss_neg_accum, mantiss_neg_accum+limb_offset,
		     full_mul_size-limb_offset, offset);
	}
	else {
	  mpn_copyi(mantiss_pos_accum, mantiss_pos_accum+limb_offset,
		     full_mul_size-limb_offset);
	  mpn_copyi(mantiss_neg_accum, mantiss_neg_accum+limb_offset,
		     full_mul_size-limb_offset);
	}
	mpn_zero (mantiss_pos_accum+full_mul_size-limb_offset, limb_offset);
	mpn_zero (mantiss_neg_accum+full_mul_size-limb_offset, limb_offset);
      }
      else {
	mpn_zero (mantiss_pos_accum, full_mul_size);
	mpn_zero (mantiss_neg_accum, full_mul_size);
      }
      erroraccum[0]=1;
      glob_exponent=maxexponent;
    }
  }
  for(i=0;i<len;i++) {
    mpn_mul_n (mantiss, Vec1[i]->mantissa, Vec2[i]->mantissa, flti_glob_nblimbs);
    mpn_zero(errormanti,flti_glob_nblimbs+1);
    errormanti[0]=(Vec1[i]->errormant)*(Vec2[i]->errormant);
    if ((Vec1[i]->errormant)&&(Vec2[i]->sign)) {
      errormanti[flti_glob_nblimbs]+=mpn_addmul_1 (errormanti, Vec2[i]->mantissa, flti_glob_nblimbs,
						   (mp_limb_t) (Vec1[i]->errormant));
    }
    if ((Vec2[i]->errormant)&&(Vec1[i]->sign)) {
      errormanti[flti_glob_nblimbs]+=mpn_addmul_1 (errormanti, Vec1[i]->mantissa, flti_glob_nblimbs,
						   (mp_limb_t) (Vec2[i]->errormant));
    }

    offset=glob_exponent-(Vec1[i]->exponent)-(Vec2[i]->exponent);
    drop=0;
    errordrop=0;

    limb_offset=offset/GMP_LIMB_BITS;
    offset=offset%GMP_LIMB_BITS;
    if (limb_offset<2*flti_glob_nblimbs) {
      //if (!my_mpn_zero_p(mantiss,  limb_offset))
	drop=1;
      if (offset) {
	if (mpn_rshift(mantiss+limb_offset, mantiss+limb_offset,
		       2*flti_glob_nblimbs-limb_offset, offset)) drop=1;
      }
      if ((Vec1[i]->sign)!=(Vec2[i]->sign)) {
	carry=mpn_add (mantiss_pos_accum, mantiss_pos_accum, full_mul_size,
		       mantiss+limb_offset, 2*flti_glob_nblimbs-limb_offset);
	if (carry) {
	  mantiss_pos_accum[full_mul_size]=carry;
	  mantiss_neg_accum[full_mul_size]=0;
	  full_mul_size++;
	}
      }
      else {
	carry=mpn_add (mantiss_neg_accum, mantiss_neg_accum, full_mul_size,
		       mantiss+limb_offset, 2*flti_glob_nblimbs-limb_offset);
	if (carry) {
	  mantiss_pos_accum[full_mul_size]=0;
	  mantiss_neg_accum[full_mul_size]=carry;
	  full_mul_size++;
	}
      }
    }
    else {
      //if (!my_mpn_zero_p(mantiss,  2*flti_glob_nblimbs))
	drop=1;
    }



    if (limb_offset<flti_glob_nblimbs+1) {
      //if (!my_mpn_zero_p(errormanti,  limb_offset))
	errordrop=1;
      if (offset) {
	if (mpn_rshift(errormanti+limb_offset, errormanti+limb_offset,
		       flti_glob_nblimbs+1-limb_offset, offset)) drop=1;
      }
      carry=mpn_add (erroraccum, erroraccum, full_error_size,
		     errormanti+limb_offset, flti_glob_nblimbs+1-limb_offset);
      if (carry) {
	erroraccum[full_error_size]=carry;
	full_error_size++;
	if (full_error_size>MAX_LIMBS_PREC) {
	  fprintf(stderr,"Error too large ?? \n");
	  exit(1);
	}
      }
    }
    else {
      //if (!my_mpn_zero_p(errormanti,  flti_glob_nblimbs+1))
	errordrop=1;
    }

    if (drop||errordrop) {
      carry=mpn_add_1 (erroraccum, erroraccum, full_error_size, (mp_limb_t) 1UL);
      if (carry) {
	erroraccum[full_error_size]=carry;
	full_error_size++;
      }
    }
  }

  drop=0;
  errordrop=0;

  sgn=mpn_cmp(mantiss_pos_accum, mantiss_neg_accum, full_mul_size);
  if (sgn>0) {
    Scal->sign=1;
    mpn_sub_n (mantiss_pos_accum, mantiss_pos_accum,  mantiss_neg_accum, full_mul_size);
  }
  else if (sgn<0) {
    Scal->sign=-1;
    mpn_sub_n (mantiss_pos_accum, mantiss_neg_accum,  mantiss_pos_accum, full_mul_size);
  }
  else {
    Scal->sign=0;
    mpn_zero (mantiss_pos_accum, full_mul_size);
  }
  nbbitsmul=my_mpn_bitnum(mantiss_pos_accum, full_mul_size);
  if (nbbitsmul<=flti_glob_prec) {
    mpn_copyi(Scal->mantissa, mantiss_pos_accum, flti_glob_nblimbs);
    mantissashift=0;
  }
  else {
    mantissashift=nbbitsmul-flti_glob_prec;
    limb_offset=mantissashift/GMP_LIMB_BITS;
    offset=mantissashift%GMP_LIMB_BITS;
    if (offset) {
      mpn_lshift (mantiss_pos_accum, mantiss_pos_accum,
		  limb_offset+flti_glob_nblimbs+1, GMP_LIMB_BITS-offset);
      limb_offset++;
    }
    mpn_copyi(Scal->mantissa, mantiss_pos_accum+limb_offset,flti_glob_nblimbs);
    // if (!my_mpn_zero_p(mantiss_pos_accum,limb_offset)) drop=1; else drop=0;
    drop=1;
  }

  nbbitsmul=my_mpn_bitnum(erroraccum,  full_error_size);
  if (nbbitsmul<=MAX_ERROR_PREC) {
    Scal->errormant=erroraccum[0];
    errorshift=0;
    errordrop=0;
  }
  else {
    errorshift=nbbitsmul-MAX_ERROR_PREC;
    limb_offset=errorshift/GMP_LIMB_BITS;
    offset=errorshift%GMP_LIMB_BITS;
    erroraccum[(nbbitsmul/GMP_LIMB_BITS)+1]=0;
    if (offset) {
      limb_offset++;
      mpn_lshift (erroraccum, erroraccum,
		  limb_offset+1, GMP_LIMB_BITS-offset);
    }
    Scal->errormant=erroraccum[limb_offset];
    //    if (!my_mpn_zero_p(erroraccum,limb_offset)) errordrop=1; else errordrop=0;
    errordrop=1;
  }
  
  if (mantissashift>errorshift) {
    Scal->exponent=glob_exponent+mantissashift;
    if ((mantissashift-errorshift)>=MAX_ERROR_PREC) {
      if (Scal->errormant) errordrop=1;
      Scal->errormant=0;
    }
    else {
      offset=mantissashift-errorshift;
      if ((Scal->errormant)&((1UL<<offset)-1)) errordrop=1;
      Scal->errormant>>=offset;
    }
  }
  else if (errorshift>mantissashift) {
    Scal->exponent=glob_exponent+errorshift;
    offset=errorshift-mantissashift;
    if (offset>=flti_glob_prec) {
      //if (!my_mpn_zero_p(Scal->mantissa, flti_glob_nblimbs))
	drop=1;
      mpn_zero(Scal->mantissa, flti_glob_nblimbs);
    }
    else {
      limb_offset=offset/GMP_LIMB_BITS;
      offset=offset%GMP_LIMB_BITS;
      
      //if (!my_mpn_zero_p(Scal->mantissa,  limb_offset))
	drop=1;
      if (offset) {
	if (mpn_rshift(Scal->mantissa, (Scal->mantissa)+limb_offset,
		       flti_glob_nblimbs-limb_offset, offset)) drop=1;
      }
      else {
	mpn_copyi(Scal->mantissa,(Scal->mantissa)+limb_offset, flti_glob_nblimbs-limb_offset);
      }
      mpn_zero((Scal->mantissa)+flti_glob_nblimbs-limb_offset,limb_offset);
    }
  }
  else { // errorshift == mantissashift
    Scal->exponent=glob_exponent+mantissashift;
  }

  if (drop||errordrop) {
    Scal->errormant++;
  }
  
  while ((Scal->errormant)>=(1UL<<MAX_ERROR_PREC)) {
    drop=mpn_rshift (Scal->mantissa, Scal->mantissa, flti_glob_nblimbs, 1);
    errordrop=(Scal->errormant)&1;
    (Scal->errormant)>>=1;
    if (errordrop||drop) (Scal->errormant)++;    
    (Scal->exponent)++;
  }

  if (my_mpn_zero_p(Scal->mantissa, flti_glob_nblimbs)) Scal->sign=0;
  return 0;
}


void FullUpdate(int j,int k, int maxk, LLL_PARAMS Params)
{
  int i;
  LatEntry *Lptr, *Ljptr;
  unsigned long int smallquo;
  unsigned long int smallquosquare;

  LatEntry *Lattice, *ExactScals, *RoundedQuo, *LatTmp;
  GramEntry *GramM, *GramR, Tmp, Scalneg, Quo;
  int spacedim, allocdim;

  Lattice=Params.Lattice; ExactScals=Params.ExactScals; GramR=Params.GramR;
  GramM=Params.GramM; spacedim=Params.spacedim;  Tmp=Params.Tmp;
  allocdim=Params.allocdim; Scalneg=Params.Scalneg;
  LatTmp=Params.LatTmp_ptr; RoundedQuo=Params.RoundedQuo_ptr;
  Quo=Params.Quo;

  smallquo=((*RoundedQuo)->_mp_d)[0];
  if ((((*RoundedQuo)->_mp_size)==1)&&(smallquo<=0xffffffffUL)) {
    for(i=0;i<j;i++) {
      GramMulSmall(Tmp,*(GramM+j*allocdim+i),smallquo);
      GramCpy(Scalneg,*(GramM+k*allocdim+i)); // Use Scalneg as temporary
      GramSub(*(GramM+k*allocdim+i),Scalneg,Tmp);
      GramMulSmall(Tmp,*(GramR+j*allocdim+i),smallquo);
      GramCpy(Scalneg,*(GramR+k*allocdim+i)); // Use Scalneg as temporary
      GramSub(*(GramR+k*allocdim+i),Scalneg,Tmp);
    }
    GramCpy(Tmp,*(GramM+k*allocdim+i));
    GramSub(*(GramM+k*allocdim+i),Tmp,Quo);

    smallquosquare=smallquo*smallquo;
    Lptr=Lattice+k*spacedim;
    Ljptr=Lattice+j*spacedim;
    for(i=0;i<spacedim;i++) {
      if (LatNonZero(*Ljptr)) {
	mpz_mul_ui(*LatTmp,*Ljptr,smallquo);
	LatSub(*Lptr,*Lptr,*LatTmp);
      }
      Lptr++; Ljptr++;
    }
    
    //  Update exact scalar products
    Lptr=ExactScals+k*allocdim+k;
    Ljptr=ExactScals+k*allocdim+j;
    if (LatNonZero(*Ljptr)) {
      mpz_mul_ui(*LatTmp,*Ljptr,smallquo<<1);
      LatSub(*Lptr,*Lptr,*LatTmp);
    }
    Ljptr=ExactScals+j*allocdim+j;
    if (LatNonZero(*Ljptr)) {
      mpz_mul_ui(*LatTmp,*Ljptr,smallquosquare);
      LatAdd(*Lptr,*Lptr,*LatTmp);
    }
    
    for(i=0;i<=maxk;i++) {
      if (i==k) continue;
      if (i<k) 
	Lptr=ExactScals+k*allocdim+i;
      else
	Lptr=ExactScals+i*allocdim+k;
      if (i<j) 
	Ljptr=ExactScals+j*allocdim+i;
      else
	Ljptr=ExactScals+i*allocdim+j;
      if (LatNonZero(*Ljptr)) {
	mpz_mul_ui(*LatTmp,*Ljptr,smallquo);
	LatSub(*Lptr,*Lptr,*LatTmp);
      }
    }
  }
  else if ((((*RoundedQuo)->_mp_size)==-1)&&(smallquo<=0xffffffffUL)) {
    for(i=0;i<j;i++) {
      GramMulSmall(Tmp,*(GramM+j*allocdim+i),smallquo);
      GramCpy(Scalneg,*(GramM+k*allocdim+i)); // Use Scalneg as temporary
      GramAdd(*(GramM+k*allocdim+i),Scalneg,Tmp);
      GramMulSmall(Tmp,*(GramR+j*allocdim+i),smallquo);
      GramCpy(Scalneg,*(GramR+k*allocdim+i)); // Use Scalneg as temporary
      GramAdd(*(GramR+k*allocdim+i),Scalneg,Tmp);
    }
    GramCpy(Tmp,*(GramM+k*allocdim+i));
    GramSub(*(GramM+k*allocdim+i),Tmp,Quo);

    smallquosquare=smallquo*smallquo;
    Lptr=Lattice+k*spacedim;
    Ljptr=Lattice+j*spacedim;
    for(i=0;i<spacedim;i++) {
      if (LatNonZero(*Ljptr)) {
	mpz_mul_ui(*LatTmp,*Ljptr,smallquo);
	LatAdd(*Lptr,*Lptr,*LatTmp);
      }
      Lptr++; Ljptr++;
    }
    
    //  Update exact scalar products
    Lptr=ExactScals+k*allocdim+k;
    Ljptr=ExactScals+k*allocdim+j;
    if (LatNonZero(*Ljptr)) {
      mpz_mul_ui(*LatTmp,*Ljptr,smallquo<<1);
      LatAdd(*Lptr,*Lptr,*LatTmp);
    }
    Ljptr=ExactScals+j*allocdim+j;
    if (LatNonZero(*Ljptr)) {
      mpz_mul_ui(*LatTmp,*Ljptr,smallquosquare);
      LatAdd(*Lptr,*Lptr,*LatTmp);
    }
    
    for(i=0;i<=maxk;i++) {
      if (i==k) continue;
      if (i<k) 
	Lptr=ExactScals+k*allocdim+i;
      else
	Lptr=ExactScals+i*allocdim+k;
      if (i<j) 
	Ljptr=ExactScals+j*allocdim+i;
      else
	Ljptr=ExactScals+i*allocdim+j;
      if (LatNonZero(*Ljptr)) {
	mpz_mul_ui(*LatTmp,*Ljptr,smallquo);
	LatAdd(*Lptr,*Lptr,*LatTmp);
      }
    }
  }
  else {
    for(i=0;i<j;i++) {
      GramMul(Tmp,Quo,*(GramM+j*allocdim+i));
      GramCpy(Scalneg,*(GramM+k*allocdim+i)); // Use Scalneg as temporary
      GramSub(*(GramM+k*allocdim+i),Scalneg,Tmp);
      GramMul(Tmp,Quo,*(GramR+j*allocdim+i));
      GramCpy(Scalneg,*(GramR+k*allocdim+i)); // Use Scalneg as temporary
      GramSub(*(GramR+k*allocdim+i),Scalneg,Tmp);
    }
    GramCpy(Tmp,*(GramM+k*allocdim+i));
    GramSub(*(GramM+k*allocdim+i),Tmp,Quo);

    GramMul(Tmp,Quo,*(GramR+j*allocdim+j));
    GramCpy(Scalneg,*(GramR+k*allocdim+j)); // Use Scalneg as temporary
    GramSub(*(GramR+k*allocdim+j),Scalneg,Tmp);

  
    Lptr=Lattice+k*spacedim;
    Ljptr=Lattice+j*spacedim;
    for(i=0;i<spacedim;i++) {
      if (LatNonZero(*Ljptr)) {
	LatMul(*LatTmp,*RoundedQuo,*Ljptr);
	LatSub(*Lptr,*Lptr,*LatTmp);
      }
      Lptr++; Ljptr++;
    }
    
    //  Update exact scalar products
    Lptr=ExactScals+k*allocdim+k;
    Ljptr=ExactScals+k*allocdim+j;
    if (LatNonZero(*Ljptr)) {
      LatMul(*LatTmp,*RoundedQuo,*Ljptr);
      LatAdd(*LatTmp,*LatTmp,*LatTmp);
      LatSub(*Lptr,*Lptr,*LatTmp);
    }
    LatMul(*LatTmp,*RoundedQuo,*RoundedQuo);
    Ljptr=ExactScals+j*allocdim+j;
    if (LatNonZero(*Ljptr)) {
      LatMul(*LatTmp,*LatTmp,*Ljptr);
      LatAdd(*Lptr,*Lptr,*LatTmp);
    }
    
    for(i=0;i<=maxk;i++) {
      if (i==k) continue;
      if (i<k) 
	Lptr=ExactScals+k*allocdim+i;
      else
	Lptr=ExactScals+i*allocdim+k;
      if (i<j) 
	Ljptr=ExactScals+j*allocdim+i;
      else
	Ljptr=ExactScals+i*allocdim+j;
      if (LatNonZero(*Ljptr)) {
	LatMul(*LatTmp,*RoundedQuo,*Ljptr);
	LatSub(*Lptr,*Lptr,*LatTmp);
      }
    }
  }
}

void FullUpdateOne(int j, int k, int maxk, LLL_PARAMS Params)
{
  int i;
  LatEntry *Lptr, *Ljptr;
  
  LatEntry *Lattice, *ExactScals, *LatTmp;
  GramEntry *GramM, *GramR, MinusOne, Tmp;
  int spacedim, allocdim;

  Lattice=Params.Lattice; ExactScals=Params.ExactScals; GramR=Params.GramR;
  GramM=Params.GramM; spacedim=Params.spacedim;
  allocdim=Params.allocdim;
  LatTmp=Params.LatTmp_ptr; MinusOne=Params.MinusOne; Tmp=Params.Tmp;
  
  for(i=0;i<j;i++) {
    GramCpy(Tmp,*(GramM+k*allocdim+i));
    GramSub(*(GramM+k*allocdim+i),Tmp,*(GramM+j*allocdim+i));
    GramCpy(Tmp,*(GramR+k*allocdim+i));
    GramSub(*(GramR+k*allocdim+i),Tmp,*(GramR+j*allocdim+i));
  }
  GramCpy(Tmp,*(GramM+k*allocdim+i));
  GramAdd(*(GramM+k*allocdim+i),Tmp,MinusOne);
  GramCpy(Tmp,*(GramR+k*allocdim+i));
  GramSub(*(GramR+k*allocdim+i),Tmp,*(GramR+j*allocdim+i));

  Lptr=Lattice+k*spacedim;
  Ljptr=Lattice+j*spacedim;
  for(i=0;i<spacedim;i++) {
    if (LatNonZero(*Ljptr)) {
      LatSub(*Lptr,*Lptr,*Ljptr);
    }
    Lptr++; Ljptr++;
  }
  
  //  Update exact scalar products
  Lptr=ExactScals+k*allocdim+k;
  Ljptr=ExactScals+k*allocdim+j;
  if (LatNonZero(*Ljptr)) {
    LatAdd(*LatTmp,*Ljptr,*Ljptr);
    LatSub(*Lptr,*Lptr,*LatTmp);
  }
  Ljptr=ExactScals+j*allocdim+j;
  if (LatNonZero(*Ljptr)) {
    LatAdd(*Lptr,*Lptr,*Ljptr);
  }
  
  for(i=0;i<=maxk;i++) {
    if (i==k) continue;
    if (i<k) 
      Lptr=ExactScals+k*allocdim+i;
    else
      Lptr=ExactScals+i*allocdim+k;
    if (i<j) 
      Ljptr=ExactScals+j*allocdim+i;
    else
      Ljptr=ExactScals+i*allocdim+j;
    if (LatNonZero(*Ljptr)) {
      LatSub(*Lptr,*Lptr,*Ljptr);
    }
  }
}


void FullUpdateMinusOne(int j, int k, int maxk, LLL_PARAMS Params)
{ 
  int i;
  LatEntry *Lptr, *Ljptr;
  
  LatEntry *Lattice, *ExactScals, *LatTmp;
  GramEntry *GramM, *GramR, MinusOne, Tmp;
  int spacedim, allocdim;

  Lattice=Params.Lattice; ExactScals=Params.ExactScals; GramR=Params.GramR;
  GramM=Params.GramM; spacedim=Params.spacedim;
  allocdim=Params.allocdim;  
  LatTmp=Params.LatTmp_ptr; MinusOne=Params.MinusOne; Tmp=Params.Tmp;

  for(i=0;i<j;i++) {
    GramCpy(Tmp,*(GramM+k*allocdim+i));
    GramAdd(*(GramM+k*allocdim+i),Tmp,*(GramM+j*allocdim+i));
    GramCpy(Tmp,*(GramR+k*allocdim+i));
    GramAdd(*(GramR+k*allocdim+i),Tmp,*(GramR+j*allocdim+i));
  }
  GramCpy(Tmp,*(GramM+k*allocdim+i));
  GramSub(*(GramM+k*allocdim+i),Tmp,MinusOne);
  GramCpy(Tmp,*(GramR+k*allocdim+i));
  GramAdd(*(GramR+k*allocdim+i),Tmp,*(GramR+j*allocdim+i));
  
  Lptr=Lattice+k*spacedim;
  Ljptr=Lattice+j*spacedim;
  for(i=0;i<spacedim;i++) {
    if (LatNonZero(*Ljptr)) {
      LatAdd(*Lptr,*Lptr,*Ljptr);
    }
    Lptr++; Ljptr++;
  }
  
  //  Update exact scalar products
  Lptr=ExactScals+k*allocdim+k;
  Ljptr=ExactScals+k*allocdim+j;
  if (LatNonZero(*Ljptr)) {
    LatAdd(*LatTmp,*Ljptr,*Ljptr);
    LatAdd(*Lptr,*Lptr,*LatTmp);
  }
  Ljptr=ExactScals+j*allocdim+j;
  if (LatNonZero(*Ljptr)) {
    LatAdd(*Lptr,*Lptr,*Ljptr);
  }
  
  for(i=0;i<=maxk;i++) {
    if (i==k) continue;
    if (i<k) 
      Lptr=ExactScals+k*allocdim+i;
    else
      Lptr=ExactScals+i*allocdim+k;
    if (i<j) 
      Ljptr=ExactScals+j*allocdim+i;
    else
      Ljptr=ExactScals+i*allocdim+j;
    if (LatNonZero(*Ljptr)) {
      LatAdd(*Lptr,*Lptr,*Ljptr);
    }
  }
}

void InitExactScals(int k, int maxk, LLL_PARAMS Params)
{
  int i,j;
  LatEntry *Lattice, *ScalProd, *ExactScals;
  int spacedim, allocdim;
  LatEntry *LatTmp, *exScalar;
  LatEntry *Lptr, *Ljptr;

  ScalProd=Params.ScalProd;
  Lattice=Params.Lattice; ExactScals=Params.ExactScals; spacedim=Params.spacedim;
  LatTmp=Params.LatTmp_ptr; exScalar=Params.exScalar_ptr; allocdim=Params.allocdim;

  if (ScalProd==NULL) {
    for(j=0;j<=maxk;j++) {
      Lptr=Lattice+k*spacedim;
      Ljptr=Lattice+j*spacedim;
      ZeroLatEntry(*exScalar);
      for(i=0;i<spacedim;i++) {
	if ((LatNonZero(*Lptr)) && (LatNonZero(*Ljptr))) {
	  LatMul(*LatTmp,*Lptr,*Ljptr);
	  LatAdd(*exScalar,*exScalar,*LatTmp);
	}
	Lptr++; Ljptr++;
      }
      if (j<=k)
	LatSwap(*(ExactScals+k*allocdim+j),*exScalar);
      else
	LatSwap(*(ExactScals+j*allocdim+k),*exScalar);
    }
  }
  else {
    for(j=0;j<spacedim;j++) {
      Lptr=Lattice+k*spacedim;
      Ljptr=ScalProd+j*spacedim;
      ZeroLatEntry(*exScalar);
      for(i=0;i<spacedim;i++) {
	if ((LatNonZero(*Lptr)) && (LatNonZero(*Ljptr))) {
	  LatMul(*LatTmp,*Lptr,*Ljptr);
	  LatAdd(*exScalar,*exScalar,*LatTmp);
	}
	Lptr++; Ljptr++;
      }
      LatSwap(*(ScalProd+spacedim*spacedim+j),*exScalar);
    }
    
    for(j=0;j<=maxk;j++) {
      Lptr=ScalProd+spacedim*spacedim;
      Ljptr=Lattice+j*spacedim;
      ZeroLatEntry(*exScalar);
      for(i=0;i<spacedim;i++) {
	if ((LatNonZero(*Lptr)) && (LatNonZero(*Ljptr))) {
	  LatMul(*LatTmp,*Lptr,*Ljptr);
	  LatAdd(*exScalar,*exScalar,*LatTmp);
	}
	Lptr++; Ljptr++;
      }
      if (j<=k) {
	LatSwap(*(ExactScals+k*allocdim+j),*exScalar);
      }
      else {
	LatSwap(*(ExactScals+j*allocdim+k),*exScalar);
      }
    }
  }
}

int DoLovaszExchanges(int *k_ptr, int maxk, int freshmupoint, LLL_PARAMS Params, int mupolicy)
{
  int save_k;
  int  cl_sg;
  int i, j, k, spacedim, allocdim;
  LatEntry *Lptr, *Ljptr, *Lattice, *ExactScals;
  GramEntry *GramM, *GramR, *GramS, LLLCste, Tmp, Scalneg, mu, mubis;
  int *muinvalidfrom;
  GramEntry swap_tmp;


  Lattice=Params.Lattice; ExactScals=Params.ExactScals; GramR=Params.GramR;
  GramM=Params.GramM; GramS=Params.GramS; LLLCste=Params.LLLCste; spacedim=Params.spacedim;
  allocdim=Params.allocdim; muinvalidfrom=Params.muinvalidfrom; mu=Params.mu; mubis=Params.mubis;
  Tmp=Params.Tmp;  Scalneg=Params.Scalneg;

  k=*k_ptr;
  save_k=k;
  for (;;) {
    GramMul(Scalneg,LLLCste,*(GramR+(k-1)*allocdim+(k-1)));
    GramSub(Tmp,*(GramS+k-1),Scalneg);

    cl_sg=ClearSign(Tmp);
    if (cl_sg>0){
      k++;
      (*k_ptr)=k;
      return 0;
    }
    
    if (cl_sg<0) {
      cl_sg=-cl_sg;
    }
    else {
      GramMul(Scalneg,LLLCste,*(GramS+k-1));
      GramSub(Tmp,*(GramR+(k-1)*allocdim+(k-1)),Scalneg);
      cl_sg=ClearSign(Tmp);
    }
    if (cl_sg>0) {
      //  Do Exchange !

      // Lattice elements
      Lptr=Lattice+k*spacedim;
      Ljptr=Lattice+(k-1)*spacedim;
      for(i=0;i<spacedim;i++) {
	LatSwap(*Lptr,*Ljptr);
	Lptr++; Ljptr++;
      }
      
      // ExactScals elements
      Lptr=ExactScals+k*allocdim;
      Ljptr=ExactScals+(k-1)*allocdim;
      for(i=0;i<k-1;i++) {
	LatSwap(*Lptr,*Ljptr);
	Lptr++; Ljptr++;
      }
      LatSwap(*(Lptr+1),*Ljptr);
      Lptr=ExactScals+(k+1)*allocdim+k;
      for(i=k+1;i<=maxk;i++) {
	LatSwap(*Lptr,*(Lptr-1));
	Lptr+=allocdim;
      }

      for(i=0;i<k-1;i++) {
	swap_tmp=*(GramM+(k-1)*allocdim+i);*(GramM+(k-1)*allocdim+i)=*(GramM+k*allocdim+i);*(GramM+k*allocdim+i)=swap_tmp;
	swap_tmp=*(GramR+(k-1)*allocdim+i);*(GramR+(k-1)*allocdim+i)=*(GramR+k*allocdim+i);*(GramR+k*allocdim+i)=swap_tmp;
      }
      GramCpy(Tmp,*(GramS+k-1));
      GramCpy(*(GramS+k-1),*(GramR+(k-1)*allocdim+(k-1)));
      GramCpy(*(GramR+(k-1)*allocdim+(k-1)),Tmp);
      
      GramCpy(mu,*(GramM+k*allocdim+k-1));
      GramDivide(*(GramM+k*allocdim+k-1),*(GramR+k*allocdim+k-1),*(GramR+(k-1)*allocdim+(k-1)));
      GramCpy(mubis,*(GramM+k*allocdim+k-1));
      GramMul(Tmp,*(GramM+k*allocdim+k-1),*(GramR+k*allocdim+k-1));
      GramSub(*(GramR+k*allocdim+k),*(GramS+k-1),Tmp);
      
// Don't bother to update mus -- just invalidate them
      for (i=k+1;i<=maxk;i++) {
	if (muinvalidfrom[i]>=k)
	  muinvalidfrom[i]=k-1;
      }
      
      k--;
      if (k==0) {
	*(k_ptr)=1;
	return 0;
      }
    }
    else {
      if (k<save_k) {
	// Make sure we recompute Lovasz for lower values
	k--;
	if (k<=0) k=1;
	*(k_ptr)=k;
	return 0;
      }
      else {
	if ((freshmupoint>=k)) {
	  // We need to increase precision here
	  fprintf(stderr,"Lovasz condition not defined in LLL\n");
	  *(k_ptr)=k;
	  return 1;
	}

	// if mu are not freshly computed, retry with recomputed values
	if (mupolicy==MU_LAZY_RECOMPUTE){
	  k=freshmupoint+1;
	  for(j=k;j<=maxk;j++) 
	    muinvalidfrom[j]=0;
	}
	*(k_ptr)=k;
	return 0;
      }
    }
  }
}


int DoDeepLovasz(int *k_ptr, int maxk, int freshmupoint, LLL_PARAMS Params, int mupolicy)
{
  int save_k;
  int  cl_sg;
  int i, j, k, spacedim, allocdim, depth, save_depth;
  LatEntry *Lptr, *Ljptr, *Lattice, *ExactScals;
  GramEntry *GramM, *GramR, *GramS, LLLCste, Tmp, Scal, Scalpos, Scalneg, mu, mubis, muter, MinusOne;
  int *muinvalidfrom;
  GramEntry swap_tmp;


  Lattice=Params.Lattice; ExactScals=Params.ExactScals; GramR=Params.GramR;
  GramM=Params.GramM; GramS=Params.GramS; LLLCste=Params.LLLCste; spacedim=Params.spacedim;
  allocdim=Params.allocdim; muinvalidfrom=Params.muinvalidfrom; mu=Params.mu; mubis=Params.mubis;
  muter=Params.muter; Tmp=Params.Tmp;  Scal=Params.Scal; Scalpos=Params.Scalpos;
  Scalneg=Params.Scalneg; MinusOne=Params.MinusOne;
  
  k=*k_ptr;
  save_k=k;
  for (;;) {
    // Use mu and mubis to store products
    save_depth=k+1;
    for(depth=1;depth<=k;depth++) {
      if (depth==1) {
	GramCpy(mu,*(GramR+(k-1)*allocdim+(k-1)));
	GramCpy(mubis,*(GramS+k-1)); 
     }
      else {
	GramCpy(Tmp,mu);
	GramMul(mu,Tmp,*(GramR+(k-depth)*allocdim+(k-depth)));
	GramCpy(Tmp,mubis);
	GramMul(mubis,Tmp,*(GramS+k-depth));
      }
      GramMul(Scalneg,LLLCste,mu);
      GramSub(Tmp,mubis,Scalneg);
      cl_sg=ClearSign(Tmp);
      if (cl_sg<0) {
	save_depth=depth;
	break; // Experimentally, it seems better to break here !
      }
    }
    depth=save_depth;
    if (depth>k) {
      // Check normal Lovasz condition
      GramMul(Scalneg,LLLCste,*(GramR+(k-1)*allocdim+(k-1)));
      GramSub(Tmp,*(GramS+k-1),Scalneg);
      cl_sg=ClearSign(Tmp);
      if (cl_sg>0){
	k++;
	(*k_ptr)=k;
	return 0;
      }
      GramMul(Scalneg,LLLCste,*(GramS+k-1));
      GramSub(Tmp,*(GramR+(k-1)*allocdim+(k-1)),Scalneg);
      cl_sg=ClearSign(Tmp);
      if (cl_sg>0) depth=1;
      else {
	if (k<save_k) {
	  // Recompute Lovasz for lower values
	  k--;
	  if (k<=0) k=1;
	  *(k_ptr)=k;
	  return 0;
	}
	else {
	  if ((freshmupoint>=k)) {
	    fprintf(stderr,"Lovasz condition not defined in LLL\n");
	    *(k_ptr)=k;
	    return 1;
	  }

	  if (mupolicy==MU_LAZY_RECOMPUTE){
	    k=freshmupoint+1;
	    for(j=k;j<=maxk;j++) 
	      muinvalidfrom[j]=0;
	  }
	  *(k_ptr)=k;
	  return 0;
	}
      }
    }

    for(;depth>0;depth--) {
      // Do the exchange(s)
      // Lattice elements
      Lptr=Lattice+k*spacedim;
      Ljptr=Lattice+(k-1)*spacedim;
      for(i=0;i<spacedim;i++) {
	LatSwap(*Lptr,*Ljptr);
	Lptr++; Ljptr++;
      }
      
      // ExactScals elements
      Lptr=ExactScals+k*allocdim;
      Ljptr=ExactScals+(k-1)*allocdim;
      for(i=0;i<k-1;i++) {
	LatSwap(*Lptr,*Ljptr);
	Lptr++; Ljptr++;
      }
      LatSwap(*(Lptr+1),*Ljptr);
      Lptr=ExactScals+(k+1)*allocdim+k;
      for(i=k+1;i<=maxk;i++) {
	LatSwap(*Lptr,*(Lptr-1));
	Lptr+=allocdim;
      }
      
      for(i=0;i<k-1;i++) {
	swap_tmp=*(GramM+(k-1)*allocdim+i);*(GramM+(k-1)*allocdim+i)=*(GramM+k*allocdim+i);*(GramM+k*allocdim+i)=swap_tmp;
	swap_tmp=*(GramR+(k-1)*allocdim+i);*(GramR+(k-1)*allocdim+i)=*(GramR+k*allocdim+i);*(GramR+k*allocdim+i)=swap_tmp;
      }
      GramCpy(Tmp,*(GramS+k-1));
      GramCpy(*(GramS+k-1),*(GramR+(k-1)*allocdim+(k-1)));
      GramCpy(*(GramR+(k-1)*allocdim+(k-1)),Tmp);
      
      GramCpy(mu,*(GramM+k*allocdim+k-1));
      GramDivide(*(GramM+k*allocdim+k-1),*(GramR+k*allocdim+k-1),*(GramR+(k-1)*allocdim+(k-1)));
      GramCpy(mubis,*(GramM+k*allocdim+k-1));
      GramMul(Tmp,*(GramM+k*allocdim+k-1),*(GramR+k*allocdim+k-1));
      GramSub(*(GramR+k*allocdim+k),*(GramS+k-1),Tmp);
      
      // Don't bother to update mus
      for (i=k;i<=maxk;i++) {
	if (muinvalidfrom[i]>=k)
	  muinvalidfrom[i]=k-1;
      }
      k--;
      if (k==0) {
	*(k_ptr)=1;
	return 0;
      }
    }
  }
}


int ComputeMuValues(int k, LLL_PARAMS Params)
{
  int j;
  int allocdim;
  LatEntry *ExactScals;
  GramEntry *GramM, *GramR, Tmp, Scalneg, Scal, Scalpos;
  int *muinvalidfrom;


  ExactScals=Params.ExactScals; GramR=Params.GramR;
  GramM=Params.GramM; 
  allocdim=Params.allocdim; muinvalidfrom=Params.muinvalidfrom; Scal=Params.Scal;
  Tmp=Params.Tmp;  Scalneg=Params.Scalneg; Scalpos=Params.Scalpos;

  for(j=muinvalidfrom[k];j<k;j++) {
    LowLevelExactMinusDotProduct(Scal,*(ExactScals+k*allocdim+j),GramM+k*allocdim, GramR+j*allocdim, j);
  if (GramDivide(*(GramM+k*allocdim+j),Scal,*(GramR+j*allocdim+j))) {
    fprintf(stderr,"Division by zero\n");
    return 1;
  }
  GramCpy(*(GramR+k*allocdim+j),Scal);
  }
  muinvalidfrom[k]=k;

  return 0;
}


int DoSizeReduction(int k, int maxk, int discoverystep, int *freshmupoint, int mupolicy, LLL_PARAMS Params)
{ 
  int nonzero, j, status, glob_status;
  int allocdim;
  LatEntry *RoundedQuo;
  GramEntry *GramM, Tmp, Quo;
  int *muinvalidfrom;


  GramM=Params.GramM; RoundedQuo=Params.RoundedQuo_ptr; 
  allocdim=Params.allocdim; muinvalidfrom=Params.muinvalidfrom;
  Tmp=Params.Tmp; Quo=Params.Quo;

  glob_status=0;
  nonzero=0;
    
  // Size reduction (approx and iterate)
  for(j=k-1;j>=0;j--) {
    GramAbs(Tmp,*(GramM+k*allocdim+j));
    status=DoCompareNoisyHalf(Tmp);
    if (status==1) {
      if ((*freshmupoint)==k) {
	(*freshmupoint)--;
	muinvalidfrom[k]=0;
      }
      if (mupolicy==MU_LAZY_RECOMPUTE){
	if (discoverystep) muinvalidfrom[k]=0;
	else if (muinvalidfrom[k]>j) muinvalidfrom[k]=j;
      }
      
      RoundGramEntryToLat(*RoundedQuo, *(GramM+k*allocdim+j));
      LatEntryToGram(Quo, *RoundedQuo);
      nonzero=1;
	
      if (!LatNonZero(*RoundedQuo)) {
	fprintf(stderr,"Should not be possible -- Please report !\n");
	exit(1);
      }
      
      if (LatCmpCste(*RoundedQuo,1)==0) {
	FullUpdateOne(j, k, maxk, Params);
      }
      else if (LatCmpCste(*RoundedQuo,-1)==0) {
	FullUpdateMinusOne(j, k, maxk, Params);
      }
      else {
	FullUpdate(j,k, maxk, Params);
      }
    }
    else if (status==0) glob_status=1;
  }

  if (nonzero) return 1;
  if (glob_status) return 2;
  return 0;
}


int DoBKZ_Enumerate(int save_k, int maxk, int freshmupoint, int mupolicy, int bkzdepth, LLL_PARAMS Params)
{
  int i,j,k;
  LatEntry *Lattice, *ExactScals;
  GramEntry *GramR, *GramM;
  int spacedim, allocdim, dim;
  GramEntry Tmp, Quo, Scal, LLLCste, Scalneg,  MinusOne;
  LatEntry *LatTmp, *RoundedQuo;
  int *muinvalidfrom;
  GramEntry swap_tmp;
  LatEntry *Lptr, *Ljptr;


  int klow;
  int enumlvl, enteringlvl;
  int foundlvl;
  LatEntry *EnumCoeffs, *EnumCoeffsDump;
  GramEntry enumbound, *MuOfEnum, *SavedScals, *LocalNorms;
  int enumcounters[BKZ_DEPTH];

  Lattice=Params.Lattice; ExactScals=Params.ExactScals; GramR=Params.GramR;
  GramM=Params.GramM; LLLCste=Params.LLLCste;
  spacedim=Params.spacedim; dim=Params.dim;
  allocdim=Params.allocdim; muinvalidfrom=Params.muinvalidfrom;
  Tmp=Params.Tmp; Quo=Params.Quo; Scal=Params.Scal;
  Scalneg=Params.Scalneg;
  MinusOne=Params.MinusOne; LatTmp=Params.LatTmp_ptr;
  RoundedQuo=Params.RoundedQuo_ptr;  


  EnumCoeffs=Params.EnumCoeffs; EnumCoeffsDump=Params.EnumCoeffsDump; 
  enumbound=Params.enumbound; MuOfEnum=Params.MuOfEnum;
  LocalNorms=Params.LocalNorms; SavedScals=Params.SavedScals;
  
  // Do enumeration
  if ((save_k>=2) && (BKZ_DEPTH>2)) {
    ZeroGramEntry(enumbound);
	
    klow=save_k-(bkzdepth-1);
    if (klow<0) klow=0;
	
    for(j=klow;j<=save_k;j++) {
      GramSub(Tmp,*(GramR+j*allocdim+j),enumbound);
      if (ClearSign(Tmp)>0) {
	GramCpy(enumbound,*(GramR+j*allocdim+j));
      }
    }
    if (BKZ_POLY_CONSTRAINT) {
      // enumbound multiplied by LLLCste to keep polynomial
      // running time guarantee with small blocks
      GramMul(Tmp,LLLCste,enumbound);
      GramCpy(enumbound,Tmp);
    }
    
    enumlvl=0;
    enteringlvl=1;
    foundlvl=-1;
    for(;enumlvl>=0;) {
      // Abort enumeration if user wants to quit
      if (userwantexit) return save_k+1;

      if (enteringlvl) {
	if (enumlvl==0) {
	  // For lvl 0 init at 1 [ and only positive]
	  enumcounters[enumlvl]=0;
	  CtseEntryToLat(EnumCoeffs[0],1);
	  for(i=0;i<save_k;i++)
	    GramCpy(*(MuOfEnum+i),*(GramM+save_k*allocdim+i));
	  GramCpy(*(MuOfEnum+save_k),MinusOne);(*(MuOfEnum+save_k))->sign=1;
	}
	else {
	  RoundGramEntryToLat(EnumCoeffs[enumlvl],
			      *(MuOfEnum+(enumlvl-1)*spacedim+save_k-enumlvl));
	  LatEntryToGram(Quo, EnumCoeffs[enumlvl]);
	  
	  GramSub(Tmp,Quo,*(MuOfEnum+(enumlvl-1)*spacedim+save_k-enumlvl));
	  if ((Tmp->sign)>=0) {
	    enumcounters[enumlvl]=1;
	  }
	  else {
	    enumcounters[enumlvl]=-1;
	  }
	  EnumCoeffs[enumlvl]->_mp_size=-(EnumCoeffs[enumlvl]->_mp_size);
	  LatEntryToGram(Quo, EnumCoeffs[enumlvl]);

	  if (LatSign(EnumCoeffs[enumlvl])) {
	    if (LatCmpCste(EnumCoeffs[enumlvl],1)==0) {
	      for(i=0;i<save_k-enumlvl;i++) {
		GramAdd(*(MuOfEnum+enumlvl*spacedim+i),
			*(MuOfEnum+(enumlvl-1)*spacedim+i),
			*(GramM+(save_k-enumlvl)*allocdim+i));
	      }
	      GramSub(*(MuOfEnum+enumlvl*spacedim+i),
		      *(MuOfEnum+(enumlvl-1)*spacedim+i),MinusOne);
	      i++;
	    }
	    else if (LatCmpCste(EnumCoeffs[enumlvl],-1)==0) {
	      for(i=0;i<save_k-enumlvl;i++) {
		GramSub(*(MuOfEnum+enumlvl*spacedim+i),
			*(MuOfEnum+(enumlvl-1)*spacedim+i),
			*(GramM+(save_k-enumlvl)*allocdim+i));
	      }
	      GramAdd(*(MuOfEnum+enumlvl*spacedim+i),
		      *(MuOfEnum+(enumlvl-1)*spacedim+i),MinusOne);
	      i++;
	    }
	    else {
	      for(i=0;i<save_k-enumlvl;i++) {
		GramMul(Tmp,Quo,*(GramM+(save_k-enumlvl)*allocdim+i));
		GramAdd(*(MuOfEnum+enumlvl*spacedim+i),
			*(MuOfEnum+(enumlvl-1)*spacedim+i),Tmp);
	      }
	      GramAdd(*(MuOfEnum+enumlvl*spacedim+i),
		      *(MuOfEnum+(enumlvl-1)*spacedim+i),Quo);
	      i++;
	    }
	  }
	  else {
	    for(i=0;i<=save_k-enumlvl;i++) {
	      GramCpy(*(MuOfEnum+enumlvl*spacedim+i),*(MuOfEnum+(enumlvl-1)*spacedim+i));
	    }
	  }
 
	  for(;i<=save_k;i++) {
	    GramCpy(*(MuOfEnum+enumlvl*spacedim+i),*(MuOfEnum+(enumlvl-1)*spacedim+i));
	  }
	}
	for(i=0;i<=save_k;i++) {
	  GramCpy(*(MuOfEnum+(enumlvl+bkzdepth)*spacedim+i),*(MuOfEnum+enumlvl*spacedim+i));
	}
      }
      else {
	if (enumcounters[enumlvl]==0) {
	  // For lvl 0 [only positive]
	  CtseEntryToLat(*RoundedQuo,1);
	  LatAdd(EnumCoeffs[enumlvl],EnumCoeffs[enumlvl],*RoundedQuo);
	  for(i=0;i<save_k;i++) {
	    GramAdd(Tmp,*(MuOfEnum+i),*(GramM+(save_k)*allocdim+i));
	    GramCpy(*(MuOfEnum+i),Tmp);
	    }
	  GramSub(Tmp,*(MuOfEnum+save_k),MinusOne);
	  GramCpy(*(MuOfEnum+save_k),Tmp);
	}
	else {
	  CtseEntryToLat(*RoundedQuo,enumcounters[enumlvl]);
	  LatAdd(EnumCoeffs[enumlvl],EnumCoeffs[enumlvl],*RoundedQuo);

	  if (enumcounters[enumlvl]>0) {
	    enumcounters[enumlvl]=-(enumcounters[enumlvl]+1);
	    for(i=0;i<save_k-enumlvl;i++) {
	      GramAdd(Tmp,*(MuOfEnum+(enumlvl+bkzdepth)*spacedim+i),
		      *(GramM+(save_k-enumlvl)*allocdim+i));
	      GramCpy(*(MuOfEnum+(enumlvl+bkzdepth)*spacedim+i),*(MuOfEnum+enumlvl*spacedim+i));
	      GramCpy(*(MuOfEnum+enumlvl*spacedim+i),Tmp);
	    }
	    GramSub(Tmp,*(MuOfEnum+(enumlvl+bkzdepth)*spacedim+i),MinusOne);
	    GramCpy(*(MuOfEnum+(enumlvl+bkzdepth)*spacedim+i),*(MuOfEnum+enumlvl*spacedim+i));
	    GramCpy(*(MuOfEnum+enumlvl*spacedim+i),Tmp);
	  }
	  else {
	    enumcounters[enumlvl]=-enumcounters[enumlvl]+1;
	    for(i=0;i<save_k-enumlvl;i++) {
	      GramSub(Tmp,*(MuOfEnum+(enumlvl+bkzdepth)*spacedim+i),
		      *(GramM+(save_k-enumlvl)*allocdim+i));
	      GramCpy(*(MuOfEnum+(enumlvl+bkzdepth)*spacedim+i),*(MuOfEnum+enumlvl*spacedim+i));
	      GramCpy(*(MuOfEnum+enumlvl*spacedim+i),Tmp);
	    }
	    GramAdd(Tmp,*(MuOfEnum+(enumlvl+bkzdepth)*spacedim+i),MinusOne);
	    GramCpy(*(MuOfEnum+(enumlvl+bkzdepth)*spacedim+i),*(MuOfEnum+enumlvl*spacedim+i));
	    GramCpy(*(MuOfEnum+enumlvl*spacedim+i),Tmp);
	  }
	}
      }
      // Compute current projected norm
      ZeroGramEntry(Scal);
      for(i=save_k-enumlvl;i<=save_k;i++) {
	GramMul(Tmp,*(MuOfEnum+enumlvl*spacedim+i),
		*(MuOfEnum+enumlvl*spacedim+i));
	GramMul(Scalneg,Tmp,*(GramR+i*allocdim+i));
	GramAdd(Tmp,Scal,Scalneg);
	GramCpy(Scal,Tmp);
      }

      // Test new vector better than current at depth
      if (BKZ_POLY_CONSTRAINT) {
	GramMul(Tmp,LLLCste,*(GramR+(save_k-enumlvl)*allocdim+save_k-enumlvl));
      }
      else {
	GramCpy(Tmp,*(GramR+(save_k-enumlvl)*allocdim+save_k-enumlvl));
      }
      GramSub(Scalneg,Tmp,Scal);
      if (ClearSign(Scalneg)>0) {
	int oktostore;
	oktostore=0;
	if (foundlvl<enumlvl) {
	  oktostore=1;
	}
	else {
	  GramSub(Scalneg,SavedScals[enumlvl],Scal);
	  if (ClearSign(Scalneg)>0) {
	    oktostore=1;
	  }
	}
	if (oktostore) {
	  GramCpy(SavedScals[enumlvl],Scal);
	  foundlvl=enumlvl;
	  for(i=0;i<=foundlvl;i++) {
	    LatCpy(EnumCoeffsDump[i],EnumCoeffs[i]);
	  }
	}
      }
      else if ((ClearSign(Scalneg)==0) && (Scalneg->sign)) {
	fprintf(stderr,"Doubting comparison in BKZ\n");
      }
      GramSub(Scalneg,enumbound,Scal);
      
      if (ClearSign(Scalneg)>0) {
	// down one level (if possible)
	if ((enumlvl<bkzdepth-1)&&(enumlvl<save_k)) {
	  enteringlvl=1;
	  enumlvl++;
	}
	else
	  enteringlvl=0;
      }
      else {
	// up one level
	enteringlvl=0;
	enumlvl--;
      }
    }
    
    if (foundlvl==0) {
      fprintf(stderr,"Absurd result in enumeration\n");
      exit(1);
    }

    if (foundlvl!=-1/*==(bkzdepth-1)*/) {
      // Insert new vector
      // Change k, reinitialize muinvalidfrom
      
      if (LatCmpCste(EnumCoeffsDump[0],1)==0) {
	// Move vector at position save_k to position k
	
	k=save_k-foundlvl;
	// Shift Lattice elements
	for(j=save_k-1;j>=k;j--) {
	  Lptr=Lattice+j*spacedim;
	  Ljptr=Lattice+(j+1)*spacedim;
	  for(i=0;i<spacedim;i++) {
	    LatSwap(*Lptr,*Ljptr);
	    Lptr++; Ljptr++;
	  }
	}
	// Shift GramR GramM elements
	for(j=save_k-1;j>=k;j--) {
	  for(i=0;i<k;i++) {
	    swap_tmp=*(GramM+(j+1)*allocdim+i);*(GramM+(j+1)*allocdim+i)=*(GramM+j*allocdim+i);*(GramM+j*allocdim+i)=swap_tmp;
	    swap_tmp=*(GramR+(j+1)*allocdim+i);*(GramR+(j+1)*allocdim+i)=*(GramR+j*allocdim+i);*(GramR+j*allocdim+i)=swap_tmp;
	    
	  }
	}
	for(enumlvl=1;enumlvl<=foundlvl;enumlvl++) {
	  for(i=0;i<spacedim;i++) {
	    LatMul(*LatTmp,EnumCoeffsDump[enumlvl],*(Lattice+(k+1+foundlvl-enumlvl)*spacedim+i));
	    LatAdd(*(Lattice+k*spacedim+i),*(Lattice+k*spacedim+i),*LatTmp);
	  }
	}
	
	// Shift ExactScals elements
	for(j=maxk;j>save_k;j--) {
	  for(i=save_k-1;i>=k;i--) {
	    LatSwap(*(ExactScals+j*allocdim+i),*(ExactScals+j*allocdim+i+1));
	  }
	}
	for(j=k-1;j>=0;j--) {
	  for(i=save_k-1;i>=k;i--) {
	    LatSwap(*(ExactScals+(i+1)*allocdim+j),*(ExactScals+i*allocdim+j));
	  }
	}
	
	for(j=save_k-1;j>=k;j--) {
	  for(i=k;i<=j;i++) {
	    LatSwap(*(ExactScals+j*allocdim+i),*(ExactScals+(j+1)*allocdim+i+1));
	  }
	}
	
	// Fully recompute new scalar products
	InitExactScals(k, maxk, Params);
	if (mupolicy==MU_LAZY_RECOMPUTE){
	  for(j=k+1;j<=maxk;j++) if (muinvalidfrom[j]>k) muinvalidfrom[j]=k;
	  muinvalidfrom[k]=0;
	}

	return k;
      }
      else {
	// Bad case, need to temporarily increase dimension
	// Shift vectors to free position k and increment dim;
	fprintf(stderr,"Dim change CASE\n");
	k=save_k-foundlvl;
	// Shift Lattice elements
	for(j=dim-1;j>=k;j--) {
	  Lptr=Lattice+j*spacedim;
	  Ljptr=Lattice+(j+1)*spacedim;
	  for(i=0;i<spacedim;i++) {
	    LatSwap(*Lptr,*Ljptr);
	    Lptr++; Ljptr++;
	  }
	}
	// Shift GramR GramM elements
	for(j=dim-1;j>=k;j--) {
	  for(i=0;i<k;i++) {
	    swap_tmp=*(GramM+(j+1)*allocdim+i);*(GramM+(j+1)*allocdim+i)=*(GramM+j*allocdim+i);*(GramM+j*allocdim+i)=swap_tmp;
	    swap_tmp=*(GramR+(j+1)*allocdim+i);*(GramR+(j+1)*allocdim+i)=*(GramR+j*allocdim+i);*(GramR+j*allocdim+i)=swap_tmp;
	    
	  }
	}
	
	for(enumlvl=0;enumlvl<=foundlvl;enumlvl++) {
	  for(i=0;i<spacedim;i++) {
	    LatMul(*LatTmp,EnumCoeffsDump[enumlvl],*(Lattice+(k+1+foundlvl-enumlvl)*spacedim+i));
	    LatAdd(*(Lattice+k*spacedim+i),*(Lattice+k*spacedim+i),*LatTmp);
	  }
	}
	
	// Shift ExactScals elements
	for(j=k-1;j>=0;j--) {
	  for(i=maxk;i>=k;i--) {
	    LatSwap(*(ExactScals+(i+1)*allocdim+j),*(ExactScals+i*allocdim+j));
	  }
	}

	// Ideally should increment maxk (but it is a mess to do)
	for(j=maxk;j>=k;j--) {
	  for(i=k;i<=j;i++) {
	    LatSwap(*(ExactScals+j*allocdim+i),*(ExactScals+(j+1)*allocdim+i+1));
	  }
	}
	
	// Fully recompute new scalar products
	InitExactScals(k, maxk, Params);
	if (mupolicy==MU_LAZY_RECOMPUTE){
	  for(j=k+1;j<=maxk;j++) if (muinvalidfrom[j]>k) muinvalidfrom[j]=k;
	  muinvalidfrom[k]=0;
	}

	Params.dim++;
	return k;	
      }
    }
  }
  return save_k+1;
}


int LL_allocDone(LLL_PARAMS Params, int *finaldim,
		 int *discoverymax,  int mupolicy)		 
{
  LatEntry *Lattice, *ExactScals;
  GramEntry *GramR, *GramM, *GramS;
  int spacedim, allocdim, dim;
  GramEntry Tmp;
  int *muinvalidfrom;
  GramEntry  MinusOne, Scal, Scalneg;
  
  int k, save_k, freshmupoint, bkzpos;
  int i, j, maxk, mink, prevk, glob_status;
  int discoverystep;
  int totiters;
  LatEntry *Lptr, *Ljptr;

  int bkzrounds, bkz_round_number;
  int bkzdepth;
  int bkzactive;

  Lattice=Params.Lattice; ExactScals=Params.ExactScals; GramR=Params.GramR;
  GramM=Params.GramM; GramS=Params.GramS;
  spacedim=Params.spacedim;
  allocdim=Params.allocdim; dim=Params.dim; muinvalidfrom=Params.muinvalidfrom;
  Tmp=Params.Tmp; MinusOne=Params.MinusOne;
  Scal=Params.Scal; Scalneg=Params.Scalneg;
  
  k             = 0;   maxk          = -1;    mink          = 0;
  prevk         = -1;  totiters      = 0;
  *finaldim     = dim; freshmupoint  = 0;     discoverystep = 0;

  // BKZ as an external loop around LLL
  bkzrounds=BKZ_ROUNDS;
  bkzdepth=BKZ_DEPTH;
  if (bkzdepth<=2) {
    bkzactive=0;
    bkzdepth=0;
    bkzrounds=0;
  }
  else {
    bkzactive=1;
  }
  for(bkz_round_number=0, bkzpos=0;
      (bkzrounds<0) || (bkz_round_number<=bkzrounds);bkzpos++) {
  /* 
   * Outer loop for LLL, on size of the block treated 
   */
    while (k <= dim) {
      if (userwantexit>=2) break;
      if (prevk != k) {
	prevk = k;
	discoverystep = 0;
      }
      totiters++;
      
      if (k<mink) mink=k;
      if (k<=1) freshmupoint=0;
      if (k>maxk) {
	if ((k>freshmupoint+1)&&(mupolicy==MU_LAZY_RECOMPUTE)){
	  k=freshmupoint+1;
	  for(j=k;j<=maxk;j++) muinvalidfrom[j]=0;
	  continue;
	}
	if (k==dim) break;
	if (k>*discoverymax) {
	  discoverystep=1; 
	  *discoverymax=k-1; if ((*discoverymax)<0) *discoverymax=0;
	}
	maxk=k;
	if (VERBOSE) {
	  if (k==0) 
	    fprintf(stderr,"maxk=%d (mink=%d dim=%d) [%f / %d]\n",
		    maxk,mink,dim,clock()*1.0/CLOCKS_PER_SEC, totiters);
	  else 
	    gmp_fprintf(stderr,"maxk=%d (freshmu=%d) (mink=%d dim=%d) [%f / %d] size=%Zd\n",
			maxk,freshmupoint,mink,dim,clock()*1.0/CLOCKS_PER_SEC, totiters,*ExactScals);
	  fflush(stderr);
	}
	mink=maxk;
	
	/* Initialize exact scalar products at maxk */
	InitExactScals(maxk, maxk, Params);
      }
      
      /* At first vector, copy exact data into Gram, increment and move */
      if (k==0) { 
	LatEntryToGram(*GramR, *ExactScals);
	k++;
	continue;
      }
      
      /* Need to test zero vector to deal with generating families*/
      if (!LatNonZero(*(ExactScals+k*allocdim+k))) {
	if (VERBOSE) {
	  fprintf(stderr,"Zero vector in Lattice : Tweak maxk for simplicity\n");
	}
	for(i=k;i<dim-1;i++) {
	  Lptr=Lattice+i*spacedim;
	  Ljptr=Lattice+(i+1)*spacedim;
	  for(j=0;j<spacedim;j++) {
	    LatSwap(*Lptr,*Ljptr);
	    Lptr++; Ljptr++;
	  }
	}
	dim--;
	*finaldim=dim;
	maxk=k-1;
	continue;
      }
      
      if (mupolicy==MU_MAX_RECOMPUTE) muinvalidfrom[k]=0;
      if ((freshmupoint==k-1)&&(muinvalidfrom[k]==0)) {
	freshmupoint=k;
      }
      
      glob_status=ComputeMuValues(k, Params);
      
      if (glob_status==1) {
	if (freshmupoint==k) return 1;
	for(j=0;j<=maxk;j++) muinvalidfrom[j]=0;
	freshmupoint=0;
	k=1;
	continue;
      }
      
      glob_status=DoSizeReduction(k, maxk, discoverystep, &freshmupoint, mupolicy, Params);
      
      if (glob_status==1) {
	continue;
      }
      else if (glob_status==2) {
	if (freshmupoint>=k) {
	  // Insufficient precision detected here with fresh Mu's
	  // Skip and detect problem in Lovasz condition
	}
	else {
	  k=freshmupoint+1;
	  if (mupolicy==MU_LAZY_RECOMPUTE){
	    for(j=k;j<=maxk;j++) 
	      muinvalidfrom[j]=0;
	  }
	  continue;
	}
      }
      
      LatEntryToGram(*(GramS),*(ExactScals+k*allocdim+k));
      for(j=0;j<k;j++) {
	GramMul(Tmp,*(GramM+k*allocdim+j),*(GramR+k*allocdim+j));
	GramSub(*(GramS+j+1),*(GramS+j),Tmp);
      }
      GramCpy(*(GramR+k*allocdim+k),*(GramS+k));
      
      
#define EARLY_PREC_THRESHOLD 20
      if (EARLY_PREC_DETECT && (discoverystep==0)) {
	// Heuristic to pre detect precision loss
	// (Faster than waiting until precision if definitely insufficient.)
	// Please report if this causes any failure
	// Can be desactivated on the command line by specifying -n
	if (((*(GramM+k*allocdim+k-1))->sign)&&(my_mpn_bitnum((*(GramM+k*allocdim+k-1))->mantissa,flti_glob_nblimbs)<EARLY_PREC_THRESHOLD)) {
	  fprintf(stderr,"Precision seems to get to low ... \n");
	  return 1;
	}
      }
      
      save_k=k;
      if (DEEP_LOVASZ) {
	if (DoDeepLovasz(&k, maxk, freshmupoint, Params, mupolicy)) return 1;
      }
      else {
	if (DoLovaszExchanges(&k, maxk, freshmupoint, Params, mupolicy)) return 1;
      }
      
      if (k<=save_k) {
	if (freshmupoint>=k) freshmupoint=k-1;
	if (freshmupoint<0) freshmupoint=0;
      }
    }

    if (userwantexit>=1) break;
    if ((bkzpos%dim)==0) {
      bkz_round_number++;
      if (bkzactive==0) {
	break;
      }
      else {
	bkzactive=0;
      }
    }
    
    i=(bkzpos%dim);
    j=DoBKZ_Enumerate(i, maxk, freshmupoint, mupolicy, bkzdepth, Params);
    if (j<=i) {
      if (dim!=Params.dim) {
	dim=Params.dim;
	*finaldim=dim;
	fprintf(stderr,"dim changed\n");
      }
      bkzactive=1;
      k=j;
      if (VERBOSE) {
	gmp_fprintf(stderr,"BKZ round %d (Improve @%d) [%f / %d] size=%Zd\n",
		    bkz_round_number,j,clock()*1.0/CLOCKS_PER_SEC, totiters,*ExactScals);
      }
      
    }
  }
  if (VERBOSE) {
    gmp_fprintf(stderr,"Final (freshmu=%d) (dim=%d) [%f / %d] size=%Zd\n",
		freshmupoint,dim,clock()*1.0/CLOCKS_PER_SEC, totiters,*ExactScals);
  }
  
  return 0;
}

int LL_fixedPrec(LatEntry *Lattice, LatEntry *ScalProd, LatEntry *ExactScals,
		 GramEntry *GramR, GramEntry *GramM, GramEntry *GramS,
		 int spacedim, int allocdim, int dim, int *finaldim, double csteLLL,
		 int *discoverymax, int mupolicy)
 {
  int *muinvalidfrom,retcode;

  GramEntry Scal, Scalneg, Scalpos, MinusOne, Tmp, Quo, LLLCste, mu, mubis, muter;
  LatEntry RoundedQuo, LatTmp, exScalar;

  int errcode;
  LatEntry *EnumCoeffs, *EnumCoeffsDump;
  GramEntry enumbound;
  GramEntry *MuOfEnum;
  GramEntry *SavedScals;
  GramEntry *LocalNorms;

  
  LLL_PARAMS Params;
  
  muinvalidfrom=(int *) calloc(allocdim,sizeof(int));
  if (muinvalidfrom==NULL) {
    fprintf(stderr,"malloc failed!\n");
    return 1;
  }

  extern flti flti_allocate(long count);

  /* Initialization part */
  mu=flti_allocate(1);
  Tmp=flti_allocate(1);
  Quo=flti_allocate(1);
  Scal=flti_allocate(1);
  mubis=flti_allocate(1);
  muter=flti_allocate(1);
  LLLCste=flti_allocate(1);
  Scalneg=flti_allocate(1);
  Scalpos=flti_allocate(1);
  MinusOne=flti_allocate(1);
  if ((mu==NULL) || (Tmp==NULL) || (Quo==NULL) || (Scal==NULL) ||
      (mubis==NULL) || (muter==NULL) || (LLLCste==NULL) || (Scalneg==NULL) ||
      (Scalpos==NULL) || (MinusOne==NULL)) {
    fprintf(stderr,"Allocation failed !\n");
  }
  
  InitLatEntry(LatTmp);
  InitLatEntry(exScalar);
  InitLatEntry(RoundedQuo);

  // Set Minus One to Exact constant ! 
  ZeroGramEntry(MinusOne);
  MinusOne->sign=-1;
  (MinusOne->mantissa)[0]=1;
  flti_normalize(MinusOne);

  // Set LLL Cst to interval arithmeric and erase error ! 
  GramSetFromCst(LLLCste,csteLLL);
  LLLCste->errormant=0;
  flti_normalize(LLLCste);


  // BKZ allocations
  errcode=AllocLat(&EnumCoeffs, BKZ_DEPTH+1, 1);
  errcode|=AllocLat(&EnumCoeffsDump, BKZ_DEPTH+1, 1);
  if (errcode) {
    fprintf(stderr,"Error during EnumCoeffs allocation\n");
    return 1;
  }
  errcode=AllocGram(&MuOfEnum, spacedim, 2*(BKZ_DEPTH+1));
  errcode|=AllocGram(&SavedScals, BKZ_DEPTH, 1);
  errcode|=AllocGram(&LocalNorms, BKZ_DEPTH+1, 1);
  if (errcode) {
    fprintf(stderr,"Error during MuOfEnum allocation\n");
    return 1;
  }
  enumbound=flti_allocate(1);

  Params.Lattice=Lattice; Params.ScalProd=ScalProd; Params.ExactScals=ExactScals;
  Params.GramR=GramR; Params.GramM=GramM; Params.GramS=GramS; 
  Params.spacedim=spacedim; Params.allocdim=allocdim; Params.dim=dim; 
  Params.mu=mu; Params.Tmp=Tmp; Params.Quo=Quo; 
  Params.Scal=Scal; Params.mubis=mubis; Params.muter=muter; 
  Params.LLLCste=LLLCste; Params.Scalneg=Scalneg; Params.Scalpos=Scalpos; 
  Params.MinusOne=MinusOne; Params.LatTmp_ptr=&LatTmp; Params.exScalar_ptr=&exScalar;
  Params.RoundedQuo_ptr=&RoundedQuo; Params.muinvalidfrom=muinvalidfrom;


  Params.EnumCoeffs=EnumCoeffs; Params.EnumCoeffsDump=EnumCoeffsDump;
  Params.LocalNorms=LocalNorms; Params.SavedScals=SavedScals;
  Params.MuOfEnum=MuOfEnum; Params.enumbound=enumbound;

  
  retcode=LL_allocDone(Params, finaldim, discoverymax, mupolicy);
  
  /* Cleaning up */

  free(Scal);
  free(Scalneg);
  free(Scalpos);
  free(MinusOne);
  free(Tmp);
  free(Quo);
  free(LLLCste);
  free(mu);
  free(mubis);
  free(muter);

  DelLatEntry(RoundedQuo);
  DelLatEntry(LatTmp);
  DelLatEntry(exScalar);
  free(muinvalidfrom);

  return retcode;
}

void handler(int ignorevar)
{
  if (userwantexit==0) {
    userwantexit=1;
    fprintf(stderr,"Will cleanly quit after next full LLL ...\n");
  }
  else if (userwantexit==1) {
    userwantexit=2;
    fprintf(stderr,"Will cleanly quit after next LLL step ...\n");
  }
  else {
    fprintf(stderr,"Immediately aborting\n");
    exit(1);
  }
}


int LL_Adaptative(LatEntry *Lattice, LatEntry *ScalProd,
		  int spacedim, int dim, int *finaldim, double csteLLL, int mupolicy)
{

  int errcode,prec,precinc, maxk, allocdim;
  LatEntry *ExactScals;
  GramEntry *GramR,*GramM,*GramS;

  struct sigaction action;

  sigemptyset(&action.sa_mask);
  action.sa_flags=0;
  action.sa_handler=&handler;
  sigaction(SIGINT,&action,NULL);
  sigaction(SIGTERM,&action,NULL);

  allocdim=dim+1;
  maxk=0;
  for(prec=128,precinc=64;prec<=512;prec+=precinc) {
    fprintf(stderr,"precision=%d\n",prec);
    GramSetPrec(prec);
    errcode=AllocLat(&ExactScals, allocdim, allocdim);
    if (errcode) {
      fprintf(stderr,"Error during ExactScals allocation\n");
      return 1;
    }
    errcode=AllocGram(&GramR, allocdim, allocdim);
    if (errcode) {
      fprintf(stderr,"Error during GramR allocation\n");
      return 1;
    }
    errcode=AllocGram(&GramM, allocdim, allocdim);
    if (errcode) {
      fprintf(stderr,"Error during GramM allocation\n");
      return 1;
    }

    errcode=AllocGram(&GramS, 2*allocdim, 1);
    if (errcode) {
      fprintf(stderr,"Error during GramS allocation\n");
      return 1;
    }

    errcode=LL_fixedPrec(Lattice, ScalProd, ExactScals, GramR, GramM, GramS, 
			 spacedim, allocdim, dim, finaldim,
			 csteLLL, &maxk, mupolicy);
    
    UnAllocLat(&ExactScals, allocdim, allocdim);
    UnAllocGram(&GramR, allocdim, allocdim);
    UnAllocGram(&GramM, allocdim, allocdim);
    UnAllocGram(&GramS, 2*allocdim, 1);
    if (errcode==0) break;
  }
  return errcode;
}

