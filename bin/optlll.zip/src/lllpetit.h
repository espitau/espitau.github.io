#ifndef LLLPETIT_H

#define LLLPETIT_H

#include "gram.h"


typedef long long Int;
typedef long double Float;
typedef int IntP;
typedef double FloatP;
typedef double Real;

const int BLOC=12;
const int b=1;
const int DIMPETITLLL=72;

class LLLpetit{

	Float gso[DIMPETITLLL][DIMPETITLLL] __attribute__ ((aligned (16))),r[DIMPETITLLL] __attribute__ ((aligned (16)));
	Int matlll[DIMPETITLLL][DIMPETITLLL] __attribute__ ((aligned (16))),changement[DIMPETITLLL][DIMPETITLLL] __attribute__ ((aligned (16)));

	FloatP gsob[b][BLOC][BLOC] __attribute__ ((aligned (16))),rb[b][BLOC] __attribute__ ((aligned (16)));
	FloatP matlllb[b][BLOC][BLOC] __attribute__ ((aligned (16)));
	IntP changementb[b][BLOC][BLOC] __attribute__ ((aligned (16)));
	int n;

	void calcGs(int i);
	void redTaille(int i,int fin,Int &maxi);
	void lllPetit(int debut,double delta=0.99);
	bool lll();

	public:
	void reduit(Gram &g);

};

void statsLLLpetit();

#endif

