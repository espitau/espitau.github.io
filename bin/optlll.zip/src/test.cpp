#include <cstdio>
#include <gmpxx.h>

int main(){
#pragma omp parallel
	{
		mpz_class t;
#pragma omp for
		for(int i=0;i<8;i++){
			printf("%x\n",&t);
		}
	}
	return 0;
}
