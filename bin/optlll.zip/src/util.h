#ifndef UTIL_H

#define UTIL_H

#include <cstdio>
#include <mpfr.h>
#include <gmpxx.h>
#include "../config.h"


void nextNonBlankChar(FILE *f,int& ch);

void printFlt(const mpfr_t v);
double logErr(const mpfr_t v);

void round(mpz_class& res,mpfr_t v);

#ifndef OPENMP
/*double omp_get_wtime();
int omp_get_max_threads();
int omp_get_thread_num();*/
#endif

#endif
