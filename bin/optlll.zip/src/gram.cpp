#include <cassert>
#include <cstddef>
#include "gram.h"
#include <omp.h>

double timeUpd,timeProd,timeOrtho,timeSR;

const int GRAIN=1e5;

void Gram::updateLattice(int k){
	int N=nbLine(),prec=mpfr_get_prec(cholOrig[0][0]);
	mpfr_t t;
	mpfr_init2(t,prec);
	for(int i=0;i<N;i++){
		mpfr_set_z(lattice[k][i],change.v[k][i].get_mpz_t(),MPFR_RNDN);
		for (int j=i+1;j<N;j++){
			mpfr_mul_z(t,cholOrig[j][i],change.v[k][j].get_mpz_t(),MPFR_RNDN);
			mpfr_add(lattice[k][i],lattice[k][i],t,MPFR_RNDN);
		}
	}
	mpfr_clear(t);
}

bool Gram::sizeRed(int begin,int end,bool fullred){
	int N=nbLine(),prec=mpfr_get_prec(cholOrig[0][0]);
	mpfr_t *r=(mpfr_t*)malloc(N*sizeof(mpfr_t));
	for (int i=0;i<N;i++)
		mpfr_init2(r[i],prec);
/*#ifdef OPENMP
	int nbThreads=omp_get_max_threads();
	mpfr_t *t=(mpfr_t*)malloc(nbThreads*sizeof(mpfr_t));
	mpfr_t *tr=(mpfr_t*)malloc(nbThreads*sizeof(mpfr_t));
	for (int i=0;i<nbThreads;i++){
		mpfr_init2(t[i],prec);
		mpfr_init2(tr[i],prec);
	}
#else*/
	mpfr_t t;
	mpfr_init2(t,prec);
//#endif
	mpz_class m;
	bool res=false;
	bool all=true;
#ifdef OPENMP
#pragma omp parallel if(N>100 && !fullred && begin>0) private(t,m,r) //num_threads(1)
#endif
	{
#ifdef OPENMP
	mpfr_init2(t,prec);
	r=(mpfr_t*)malloc(N*sizeof(mpfr_t));
	for (int i=0;i<N;i++)
		mpfr_init2(r[i],prec);
	all=omp_get_num_threads()==1;
#endif
	// size reduce with respect to all previous vectors iff all
#ifdef OPENMP
#pragma omp for
#endif
	for (int col=begin;col<end;col++){
		int ok=0;
		do{
			double start=omp_get_wtime();
			updateLattice(col);
			timeUpd+=omp_get_wtime()-start;
			for (int j=0;j<=(all ? col : begin-1);j++){
				mpfr_set_ui(r[j],0,MPFR_RNDN);
				start=omp_get_wtime();
				for(int k=0;k<N;k++){
					mpfr_mul(t,lattice[j][k],lattice[col][k],MPFR_RNDN);
					mpfr_mul(t,t,cholOrig[k][k],MPFR_RNDN);
					mpfr_add(r[j],r[j],t,MPFR_RNDN);
				}
				timeProd+=omp_get_wtime()-start;
				start=omp_get_wtime();
				for(int k=0;k<j;k++){
					mpfr_mul(t,cholNew[j][k],r[k],MPFR_RNDN);
					mpfr_sub(r[j],r[j],t,MPFR_RNDN);
				}
				if (j<col)
					mpfr_div(cholNew[col][j],r[j],cholNew[j][j],MPFR_RNDN);
				else
					mpfr_set(cholNew[col][col],r[j],MPFR_RNDN);
				timeOrtho+=omp_get_wtime()-start;
//				printf("%d %d:",col,j);	printFlt(cholNew[col][j]);puts("");
			}

			ok++;
			bool again=false;
			start=omp_get_wtime();
			for (int j=(all ? col-1 : begin-1);j>=0;j--){
				round(m,cholNew[col][j]);
				if (m==0)
					continue;
				again=true;
		//		gmp_printf("SR %d %d : %Zd\n",i,j,m.get_mpz_t());
		//		mpfr_sub_z(t,cholNew[col][j],m.get_mpz_t(),MPFR_RNDN);
		//		mpfr_abs(a,a);
		//		gmp_printf("SR %d %d : %Zd\n",i,j,m.get_mpz_t());
				change.transvec(col,j,-m);
				for (int k=0;k<j;k++){
					mpfr_mul_z(t,cholNew[j][k],m.get_mpz_t(),MPFR_RNDN);
					mpfr_sub(cholNew[col][k],cholNew[col][k],t,MPFR_RNDN);
				}
			}
			timeSR+=omp_get_wtime()-start;
			if (!again){
				break;
			}
			if (ok>4)puts("NOUVELLE PASSE");
		}while (ok<5);
/*			for(int i=0;i<=col;i++){
				printf("%lf ",mpfr_get_d(cholNew[col][i],MPFR_RNDN));
			}
			puts("");*/
		res=res || ok==5;
	}
#ifdef OPENMP
	mpfr_clear(t);
	for (int i=0;i<N;i++)
		mpfr_clear(r[i]);
#endif
	}
	if (!all && !res){ // need to (re)compute local Gram-schmidt
		for (int col=begin;col<end && !res;col++){
			for (int j=0;j<begin;j++)
				mpfr_mul(r[j],cholNew[j][j],cholNew[col][j],MPFR_RNDN);
			for (int j=begin;j<=col;j++){
				mpfr_set_ui(r[j],0,MPFR_RNDN);
				for(int k=0;k<N;k++){
					mpfr_mul(t,lattice[j][k],lattice[col][k],MPFR_RNDN);
					mpfr_mul(t,t,cholOrig[k][k],MPFR_RNDN);
					mpfr_add(r[j],r[j],t,MPFR_RNDN);
				}
				for(int k=0;k<j;k++){
					mpfr_mul(t,cholNew[j][k],r[k],MPFR_RNDN);
					mpfr_sub(r[j],r[j],t,MPFR_RNDN);
				}
				if (j<col)
					mpfr_div(cholNew[col][j],r[j],cholNew[j][j],MPFR_RNDN);
				else
					mpfr_set(cholNew[col][col],r[j],MPFR_RNDN);
//				printf("%d %d:",col,j);	printFlt(cholNew[col][j]);puts("");
			}
		}
	}
	for (int i=0;i<N;i++)
		mpfr_clear(r[i]);
/*#ifdef OPENMP
	for (int i=0;i<nbThreads;i++){
		mpfr_clear(t[i]);
		mpfr_clear(tr[i]);
	}
	free(t);
	free(tr);
#else*/
	mpfr_clear(t);
	free(r);
	return res;
}

bool Gram::multiply(const Matrix &mul,int begin){
	change.multiply(mul,begin);
//	puts("nouvelle matrice");
//	lattice.output(stdout);
	return sizeRed(begin,begin+mul.nbColumn());
}

void Gram::extractGram(int begin,int end,int prec,Gram &out) const{
	out.resize(end-begin);
	out.roundPrec(prec);
#ifdef OPENMP
#pragma omp parallel for if(end-begin>100)
#endif
	for(int i=begin;i<end;i++){
		for (int j=begin;j<=i;j++){
			mpfr_set(out.cholOrig[i-begin][j-begin],cholNew[i][j],MPFR_RNDN);
			mpfr_set(out.cholNew[i-begin][j-begin],out.cholOrig[i-begin][j-begin],MPFR_RNDN);
		}
		for (int j=0;j<end-begin;j++)
			out.change.v[i-begin][j]=(i-begin)==j;
	}
}

void Gram::extractGs(vector<double> &gsn) const{
	mpfr_t a;
	mpfr_init2(a,100);
	for (int i=0;i<(int)gsn.size();i++){
		mpfr_set(a,cholNew[i][i],MPFR_RNDD);
		mpfr_log2(a,a,MPFR_RNDD);
		gsn[i]=mpfr_get_d(a,MPFR_RNDD);
	}
	mpfr_clear(a);
}

