#ifndef GRAMFFT_H

#define GRAMFFT_H

#include <mpfr.h>
#include <vector>
#include <complex>
#include <fftw3.h>
#include "gram.h" 
#include "matrix.h"
#include "util.h"
#include "../config.h"

using namespace std;

extern double errMax,maxFourier;

typedef double Real;
typedef complex<Real> Complex;
const int szLimb=16; // number of bits per limb
const int alignment=1<<6;

class GramFFT{
	private :
	fftw_plan forward,backward;
	Real **inFFT;
	Complex **outFFT;
	int T;

	public :
	Complex **cholOrig;
	Complex **cholNew; // Décomposition Cholesky de lattice
	Complex **lattice; // = cholOrig*change
	Complex **change;
	int nbLimb,exponent;
	int sizeFFT;
	int N;
	int maxNz;
	int nbLine() const{
		return N;
	}
	void resize(int nbLines,int prec);
	GramFFT(int nbLines=0,int nbChunks=-1){
		nbLimb=0;
		inFFT=NULL;
		outFFT=NULL;
		forward=backward=NULL;
		cholOrig=cholNew=lattice=change=NULL;
		resize(nbLines,nbChunks);
	}
	~GramFFT(){
		resize(0,-1);
	}
	bool matmpz2complex(Complex **matrix,int index,mpz_class in);
	void matcomplex2mpz(Complex **matrix,int index,mpz_class &out);
	bool mpz2complex(mpz_class in);
	void complex2mpz(mpz_class &out);
	bool sizeRed(int begin,int end);
	void refresh(int n,int m,int begin,Complex **A,bool trig=false);
	void extractGramFFT(int begin,int end,int prec,int div,GramFFT &out);
	void extractGram(int begin,int end,int prec,Gram &out);
	void extractGs(vector<double> &gs);
	Matrix extractChange();
	bool multiply(const Gram &mul,int begin);
	bool multiply(GramFFT &mul,int begin);
	void printMat(int begin,int n,int m,Complex **A);
	void benchmarkFFT();
	void benchmarkMultiplication();
	void destroy(int prec); // can only multiply after this

//	private:
	void triangularSolve(int n,int beginT,Complex **T,int K,int beginA,Complex **A); //A=T^-t*A where A has n lines and k columns
	void triangularTransSolve(int n,int beginT,Complex **T,int K,int beginA,Complex **A); //A=T^-1*A where A has n lines and k columns
	bool sizeRedPart(int begin,int end);
	void updateLattice();
	bool multiplyLat(int begin,int end);

};


#endif
