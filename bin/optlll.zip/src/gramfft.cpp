#include <cassert>
#include <cstddef>
#include <cblas.h>
#include "gramfft.h"
#include <omp.h>

//double timeUpd,timeProd,timeOrtho,timeSR;

double errMax=0.,maxFourier=0.;

const int GRAIN=1e5,GRAINFFT=3e4;
const int BLOCK=16;

void GramFFT::resize(int nbLines,int prec){
	for (int i=0;i<nbLimb;i++){
		free(cholOrig[i]);
		free(cholNew[i]);
		free(lattice[i]);
		free(change[i]);
	}
	T=omp_get_max_threads();
	if (inFFT)
		for (int i=0;i<T;i++){
			free(inFFT[i]);
			free(outFFT[i]);
		}
	if(forward)
		fftw_destroy_plan(forward);
	if(backward)
		fftw_destroy_plan(backward);
	free(inFFT);
	free(outFFT);
	free(cholOrig);
	free(cholNew);
	free(lattice);
	free(change);
	N=nbLines;
	if(prec<0)
		return;
	maxNz=0;
	for(sizeFFT=prec/szLimb+1;;sizeFFT++){
		int t=sizeFFT;
		while(t%2==0)t/=2;
		while(t%3==0)t/=3;
		if(t==1)
			break;
	}
	//	printf("MAX %d %d\n",T,sizeFFT);
	nbLimb=sizeFFT/2+1;
	//	printf("sz %d\n",sizeFFT);
	cholOrig=(Complex**)malloc(nbLimb*sizeof(Complex*));
	cholNew=(Complex**)malloc(nbLimb*sizeof(Complex*));
	lattice=(Complex**)malloc(nbLimb*sizeof(Complex*));
	change=(Complex**)malloc(nbLimb*sizeof(Complex*));
	for (int i=0;i<nbLimb;i++){
		cholOrig[i]=(Complex*)aligned_alloc(alignment,N*N*sizeof(Complex));
		cholNew[i]=(Complex*)aligned_alloc(alignment,N*N*sizeof(Complex));
		lattice[i]=(Complex*)aligned_alloc(alignment,N*N*sizeof(Complex));
		change[i]=(Complex*)aligned_alloc(alignment,N*N*sizeof(Complex));
	}
	inFFT=(Real**)malloc(T*sizeof(Real*));
	outFFT=(Complex**)malloc(T*sizeof(Complex*));
	for (int i=0;i<T;i++){
		inFFT[i]=(Real*)aligned_alloc(alignment,sizeFFT*sizeof(Real));
		outFFT[i]=(Complex*)aligned_alloc(alignment,nbLimb*sizeof(Complex));
	}
#ifdef OPENMP
#pragma omp critical(fftw)
#endif
	{
		forward=fftw_plan_dft_r2c_1d(sizeFFT,inFFT[0],reinterpret_cast<fftw_complex*>(outFFT[0]),FFTW_MEASURE);
		backward=fftw_plan_dft_c2r_1d(sizeFFT,reinterpret_cast<fftw_complex*>(outFFT[0]),inFFT[0],FFTW_MEASURE);
	}
}

bool GramFFT::mpz2complex(mpz_class in){
	//	printf("sz %d\n",sizeFFT);
	size_t length;
	unsigned *tmp=(unsigned*)mpz_export(NULL,&length,-1,sizeof(unsigned),0,sizeof(unsigned)*8-szLimb,in.get_mpz_t());
	const int idT=omp_get_thread_num();
	if((int)length>sizeFFT){
		free(tmp);
		return true;
	}
	Real s=mpz_sgn(in.get_mpz_t());
	int carry=0;
	for(size_t i=0;i<length;i++){
		int cur=tmp[i]+carry;
		carry=(cur>0)&((cur>>(szLimb-1)));
		cur-=carry<<szLimb;
		inFFT[idT][i]=cur*s;
	}
	assert(carry==0 || (int)length<sizeFFT);
	if((int)length<sizeFFT)
		inFFT[idT][length]=carry*s;
	for(size_t i=length+1;i<(size_t)sizeFFT;i++){
		inFFT[idT][i]=0;
	}
	free(tmp);
	fftw_execute_dft_r2c(forward,inFFT[idT],reinterpret_cast<fftw_complex*>(outFFT[idT]));
	return false;
}

bool GramFFT::matmpz2complex(Complex **matrix,int index,mpz_class in){
	if(mpz2complex(in))
		return true;
	const int idT=omp_get_thread_num();
	for(int i=0;i<nbLimb;i++){
		matrix[i][index]=outFFT[idT][i];
		//		printf("%f %f\n",real(outFFT[i]),imag(outFFT[i]));
	}
	return false;
}

void GramFFT::complex2mpz(mpz_class &out){
	unsigned *tmp=(unsigned*)malloc(sizeFFT*sizeof(unsigned));
	long long carry=0;
	const int idT=omp_get_thread_num();
	fftw_execute_dft_c2r(backward,reinterpret_cast<fftw_complex*>(outFFT[idT]),inFFT[idT]);
	Real errM=0;
	for(int i=0;i<sizeFFT;i++){
		inFFT[idT][i]/=sizeFFT;
		long long v=(long long)(round(inFFT[idT][i]))+carry;
		tmp[i]=v&((1ll<<szLimb)-1);
		carry=v>>szLimb;
		errM=max(errM,fabs(round(inFFT[idT][i])-inFFT[idT][i]));
		if(v!=0 && i>maxNz)
			maxNz=i;
		//		printf("%f %lld %u\n",inFFT[idT][i],v,tmp[i]);
	}
	assert(errM<0.35);
	errMax=max(errMax,errM);
	//	assert(maxFourier<1e10);
	mpz_import(out.get_mpz_t(),sizeFFT,-1,sizeof(unsigned),0,sizeof(unsigned)*8-szLimb,tmp);
	//	gmp_printf("%lld %Zd\n",carry,out);
	out+=mpz_class((long int)carry)<<(szLimb*sizeFFT);
	//	gmp_printf("%lld %Zd\n",carry,out);
	//	exit(0);
	free(tmp);
}

void GramFFT::matcomplex2mpz(Complex **matrix,int index,mpz_class &out){
	const int idT=omp_get_thread_num();
	for(int i=0;i<nbLimb;i++){
		outFFT[idT][i]=matrix[i][index];
	}
	complex2mpz(out);
}

void GramFFT::triangularTransSolve(int n,int beginT,Complex **Tr,int K,int beginA,Complex **A){ //A=Tr^-t*A where A has n lines and k columns
	Complex moinsun=-1,un=1;
	if(n<=BLOCK){
		mpz_class inv;
		for(int i=0;i<n;i++){
			matcomplex2mpz(Tr,i*N+i+beginT,inv);
			//			printf("%d\n",i);
			for(int l=0;l<nbLimb;l++)
				cblas_zgemv(CblasColMajor,CblasTrans,i,K,(double*)&moinsun,(double*)(A[l]+beginA),N,(double*)(Tr[l]+beginT+i*N),1,(double*)&un,(double*)(A[l]+i+beginA),N);
			mpz_class t;
#ifdef OPENMP
#pragma omp taskloop grainsize(GRAINFFT/sizeFFT/2+1) private(t)
#endif
			for(int j=0;j<K;j++){
				matcomplex2mpz(A,beginA+i+j*N,t);
				//					gmp_printf("pré %d %d : %Zd\n",(beginA+i+j*N)/N,(beginA+i+j*N)%N,t);
				t/=inv;
				matmpz2complex(A,beginA+i+j*N,t);
				//					gmp_printf("%d %d : %Zd\n",(beginA+i+j*N)/N,(beginA+i+j*N)%N,t);
			}
			//				matcomplex2mpz(A,3*N,t);
			//				gmp_printf("%Zd\n",t);
		}
		return ;
	}
	int M=n/2;
	triangularTransSolve(M,beginT,Tr,K,beginA,A);
#ifdef OPENMP
#pragma omp taskloop grainsize(max(GRAIN/K/M/M+1,nbLimb/T)) untied
#endif
	for(int l=0;l<nbLimb;l++)
		cblas_zgemm3m(CblasColMajor,CblasTrans,CblasNoTrans,n-M,K,M,(double*)&moinsun,(double*)(Tr[l]+beginT+M*N),N,(double*)(A[l]+beginA),N,(double*)&un,(double*)(A[l]+beginA+M),N);
	triangularTransSolve(n-M,beginT+M*(N+1),Tr,K,beginA+M,A);
}

void GramFFT::refresh(int n,int m,int beginA,Complex **A,bool trig){
	mpz_class t;
	if (trig){
#ifdef OPENMP
#pragma omp taskloop private(t) grainsize(max(GRAINFFT/sizeFFT/2+1,m*(m-1)/2/T))
#endif
		for(int k=0;k<m*(m-1)/2;k++){
			int j=(1+sqrt(1+8*k))/2;
			int i=k-j*(j-1)/2;
			matcomplex2mpz(A,beginA+i+j*N,t);
			matmpz2complex(A,beginA+i+j*N,t);
		}
	}
	else{
#ifdef OPENMP
#pragma omp taskloop collapse(2) private(t) grainsize(max(GRAINFFT/sizeFFT/2+1,m*n/T))
#endif
		for(int j=0;j<m;j++)
			for(int i=0;i<n;i++){
				matcomplex2mpz(A,beginA+i+j*N,t);
				matmpz2complex(A,beginA+i+j*N,t);
			}
	}
}

void GramFFT::triangularSolve(int n,int beginT,Complex **Tr,int K,int beginA,Complex **A){ //A=Tr^-1*A where A has n lines and k columns
	Complex moinsun=-1,un=1;
	if(n<=BLOCK){
		mpz_class inv,t;
		for(int i=n-1;i>=0;i--){
			matcomplex2mpz(Tr,i*N+i+beginT,inv);
			mpz_class t;
#ifdef OPENMP
#pragma omp taskloop grainsize(GRAINFFT/sizeFFT/2+1) private(t)
#endif
			for(int j=0;j<K;j++){
				matcomplex2mpz(A,beginA+i+j*N,t);
				t/=inv;
				matmpz2complex(A,beginA+i+j*N,t);
			}
			for(int l=0;l<nbLimb;l++)
				cblas_zgeru(CblasColMajor,i,K,(double*)&moinsun,(double*)(Tr[l]+beginT+i*N),1,(double*)(A[l]+i+beginA),N,(double*)(A[l]+beginA),N);
		}
		return ;
	}
	int M=n/2;
	triangularSolve(n-M,beginT+M*(N+1),Tr,K,beginA+M,A);
#ifdef OPENMP
#pragma omp taskloop grainsize(max(GRAIN/K/M/M+1,nbLimb/T)) untied
#endif
	for(int l=0;l<nbLimb;l++)
		cblas_zgemm3m(CblasColMajor,CblasNoTrans,CblasNoTrans,M,K,n-M,(double*)&moinsun,(double*)(Tr[l]+beginT+M*N),N,(double*)(A[l]+beginA+M),N,(double*)&un,(double*)(A[l]+beginA),N);
	triangularSolve(M,beginT,Tr,K,beginA,A);
}

void GramFFT::printMat(int begin,int n,int m,Complex **A){
	printf("[");
	mpz_class t;
	for(int i=0;i<n;i++)
		for(int col=0;col<m;col++){
			matcomplex2mpz(A,begin+col*N+i,t);
			gmp_printf("%Zd%c",t,col==m-1 ? (i==n-1 ? ']' :';') : ',');
		}
	puts("");
}

bool GramFFT::sizeRedPart(int begin,int end){ // write the SZ matrix in lattice 
	//	printf("[%d;%d[\n",begin,end);
	if (begin+1==end){
		mpz_class t;
		matcomplex2mpz(cholNew,begin*(N+1),t);
		//		gmp_printf("%d %d ^2 : %Zd\n",begin,begin,t);
		if (t<=1){
			gmp_printf("%d %d ^2 : %Zd\n",begin,begin,t);
			//			assert(0);
			return true;
		}
		t=sqrt(t);
		//		gmp_printf("%d %d : %Zd\n",begin,begin,t);
		matmpz2complex(cholNew,begin*(N+1),t);
		return false;
	}
	const int M=(begin+end)/2,L=end-begin;
	const Complex un=1,moinsun=-1;
	if (sizeRedPart(begin,M)) // reduce the first part
		return true;
	// update scalar products
#ifdef OPENMP
#pragma omp taskloop grainsize(max(GRAIN/L/L/L+1,nbLimb/T)) untied
#endif
	for(int l=0;l<nbLimb;l++)
		cblas_ztrmm(CblasColMajor,CblasLeft,CblasUpper,CblasTrans,CblasUnit,M-begin,end-M,(double*)&un,(double*)(lattice[l]+begin*N+begin),N,(double*)(cholNew[l]+M*N+begin),N);
	refresh(M-begin,end-M,M*N+begin,cholNew);
	triangularTransSolve(M-begin,begin*N+begin,cholNew,end-M,M*N+begin,cholNew); // project the second part
#ifdef OPENMP
#pragma omp  taskloop grainsize(max(GRAIN/L/L/L*2+1,nbLimb/T)) untied
#endif
	for(int l=0;l<nbLimb;l++)
		cblas_zsyrk(CblasColMajor,CblasUpper,CblasTrans,end-M,M-begin,(double*)&moinsun,(double*)(cholNew[l]+M*N+begin),N,(double*)&un,(double*)(cholNew[l]+M*N+M),N);
	refresh(end-M,end-M,M*N+M,cholNew,true);
	if (sizeRedPart(M,end)) // reduce the second part
		return true;
	// update Cholesky
#ifdef OPENMP
#pragma omp taskloop grainsize(max(GRAIN/L/L/L*2+1,nbLimb/T)) untied
#endif
	for(int l=0;l<nbLimb;l++)
		cblas_ztrmm(CblasColMajor,CblasRight,CblasUpper,CblasNoTrans,CblasUnit,M-begin,end-M,(double*)&un,(double*)(lattice[l]+M*N+M),N,(double*)(cholNew[l]+M*N+begin),N);
	const unsigned shift=32;
	mpz_class q,r,t;
#ifdef OPENMP
#pragma omp taskloop collapse(2) private(t) grainsize(max(GRAINFFT/sizeFFT/3+1,((end-M)*(M-begin))/T))
#endif
	for(int i=M;i<end;i++)
		for(int j=begin;j<M;j++){
			matcomplex2mpz(cholNew,i*N+j,t);
			matmpz2complex(cholNew,i*N+j,t);
			matmpz2complex(lattice,i*N+j,t<<shift);
		}
	// size-reduce the remaining part by rounding
	triangularSolve(M-begin,begin*N+begin,cholNew,end-M,N*M+begin,lattice);
#ifdef OPENMP
#pragma omp taskloop collapse(2) private(q,r,t) grainsize(max(GRAINFFT/sizeFFT/2+1,((end-M)*(M-begin))/T))
#endif
	for(int i=M;i<end;i++)
		for(int j=begin;j<M;j++){
			matcomplex2mpz(lattice,i*N+j,t);
			mpz_fdiv_q_2exp(q.get_mpz_t(),t.get_mpz_t(),shift);
			mpz_fdiv_r_2exp(r.get_mpz_t(),t.get_mpz_t(),shift);
			if ((r>>(shift-1))==1)
				q++;
			q=-q;
			//				gmp_printf("lat %d %d : %Zd\n",i,j,q);
			matmpz2complex(lattice,i*N+j,q);
		}
	// update Cholesky ; todo : trmm
#ifdef OPENMP
#pragma omp taskloop grainsize(max(GRAIN/L/L/L+1,nbLimb/T)) untied
#endif
	for(int l=0;l<nbLimb;l++)
		cblas_zgemm3m(CblasColMajor,CblasNoTrans,CblasNoTrans,M-begin,end-M,M-begin,(double*)&un,(double*)(cholNew[l]+begin*N+begin),N,(double*)(lattice[l]+M*N+begin),N,(double*)&un,(double*)(cholNew[l]+M*N+begin),N);
#ifdef OPENMP
#pragma omp taskloop grainsize(max(GRAIN/L/L/L*2+1,nbLimb/T)) untied
#endif
	for(int l=0;l<nbLimb;l++)
		cblas_ztrmm(CblasColMajor,CblasLeft,CblasUpper,CblasNoTrans,CblasUnit,M-begin,end-M,(double*)&un,(double*)(lattice[l]+begin*N+begin),N,(double*)(lattice[l]+M*N+begin),N);
	// clean-up
	refresh(M-begin,end-M,M*N+begin,cholNew);
	refresh(M-begin,end-M,M*N+begin,lattice);
	return false;
}

void GramFFT::updateLattice(){
	Complex un=1,zero=0;
#ifdef OPENMP
#pragma omp taskloop grainsize(max(GRAIN/N/N/N+1,nbLimb/T)) untied
#endif
	for(int l=0;l<nbLimb;l++){
		cblas_zgemm3m(CblasColMajor,CblasNoTrans,CblasNoTrans,N,N,N,(double*)&un,(double*)cholOrig[l],N,(double*)change[l],N,(double*)&zero,(double*)lattice[l],N);
	}
	refresh(N,N,0,lattice);
#ifdef OPENMP
#pragma omp taskloop grainsize(max(GRAIN/N/N/N*2+1,nbLimb/T)) untied
#endif
	for(int l=0;l<nbLimb;l++){
		cblas_zsyrk(CblasColMajor,CblasUpper,CblasTrans,N,N,(double*)&un,(double*)lattice[l],N,(double*)&zero,(double*)cholNew[l],N);
	}
	refresh(N,N,0,cholNew,true);
	/*	printf("[");
		for(int col=0;col<N;col++){
		for(int i=0;i<=col;i++){
		matcomplex2mpz(cholNew,col*N+i,t);
		gmp_printf("%Zd%c",t,i==N-1 ? ']' : ',');
		}
		for(int i=col+1;i<N;i++){
		matcomplex2mpz(cholNew,i*N+col,t);
		gmp_printf("%Zd%c",t,i==N-1 ? ';' : ',');
		}
		}*/
	//	exit(0);
	//	printf("change %f\n",errMax);
}

bool GramFFT::sizeRed(int begin,int end){
	//	puts("Sz");
	//	printMat(0,N,N,change);
	updateLattice();
	//	puts("Lat");
	matmpz2complex(lattice,0,1);
	matmpz2complex(lattice,1,0);
#ifdef OPENMP
#pragma omp taskloop collapse(2) grainsize(max(GRAINFFT/sizeFFT*40+1,N*nbLimb/T))
#endif
	for(int l=0;l<nbLimb;l++)
		for (int i=0;i<N;i++){
			lattice[l][i*N+i]=lattice[l][0];
			fill(lattice[l]+i*N+i+1,lattice[l]+(i+1)*N,lattice[l][1]);
			fill(cholNew[l]+i*N+i+1,cholNew[l]+(i+1)*N,lattice[l][1]);
		}
	if (sizeRedPart(0,N))
		return true;
	//	printMat(0,N,N,lattice);
	//	puts("SZ part");
	Complex un=1;
#ifdef OPENMP
#pragma omp taskloop grainsize(max(GRAIN/N/N/N*2+1,nbLimb/T)) untied
#endif
	for(int l=0;l<nbLimb;l++){
		cblas_ztrmm(CblasColMajor,CblasRight,CblasUpper,CblasNoTrans,CblasUnit,N,N,(double*)&un,(double*)lattice[l],N,(double*)change[l],N);
	}
	//	puts("Mulmat");
	refresh(N,N,0,change);
	//	puts("fin");
	//	printMat(0,N,N,change);
	return false;
}

bool GramFFT::multiplyLat(int begin,int end){
	int M=end-begin;
	Complex un=1,zero=0;
#ifdef OPENMP
#pragma omp taskloop grainsize(max(GRAIN/N/M/M+1,nbLimb/T)) untied
#endif
	for(int l=0;l<nbLimb;l++)
		cblas_zgemm3m(CblasColMajor,CblasNoTrans,CblasNoTrans,N,M,M,(double*)&un,(double*)(change[l]+begin*N),N,(double*)(lattice[l]+begin*N),N,(double*)&zero,(double*)(cholNew[l]+begin*N),N);
	mpz_class t;
#ifdef OPENMP
#pragma omp taskloop collapse(2) private(t) grainsize(max(GRAINFFT/sizeFFT/2+1,((end-begin)*N)/T))
#endif
	for(int j=begin;j<end;j++)
		for(int i=0;i<N;i++){
			matcomplex2mpz(cholNew,i+j*N,t);
			matmpz2complex(change,i+j*N,t);
		}
	return false;
}

bool GramFFT::multiply(const Gram &mul,int begin){
	int M=mul.nbLine();
#ifdef OPENMP
#pragma omp taskloop collapse(2) shared(mul) grainsize(max(GRAINFFT/sizeFFT+1,(M*M)/T))
#endif
	for(int i=begin;i<begin+M;i++)
		for(int j=0;j<M;j++){
			matmpz2complex(lattice,i*N+j,mul.change.v[i-begin][j]);
//			gmp_printf("%d %d :%Zd\n",i,j,mul.change.v[i-begin][j]);
		}
	return multiplyLat(begin,begin+M);
}

bool GramFFT::multiply(GramFFT &mul,int begin){
	int M=mul.nbLine();
	mpz_class t;
#ifdef OPENMP
#pragma omp taskloop collapse(2) private(t) shared(mul) grainsize(GRAINFFT/sizeFFT/2+1)
#endif
	for(int i=begin;i<begin+M;i++)
		for(int j=0;j<M;j++){
			mul.matcomplex2mpz(mul.change,(i-begin)*M+j,t);
			matmpz2complex(lattice,i*N+j,t);
		}
	return multiplyLat(begin,begin+M);
}

Matrix GramFFT::extractChange(){
	Matrix output(N,N);
#ifdef OPENMP
#pragma omp taskloop collapse(2) shared(output) grainsize(GRAINFFT/sizeFFT+1)
#endif
	for(int i=0;i<N;i++)
		for(int j=0;j<N;j++)
			matcomplex2mpz(change,i*N+j,output.v[i][j]);
	return output;
}
void GramFFT::extractGramFFT(int begin,int end,int prec,int div,GramFFT &out){
	out.resize(end-begin,prec);
	out.exponent=exponent+div;
	mpz_class t;
//	printf("%d,%d : %d %d\n",begin,end,prec,div);
#ifdef OPENMP
#pragma omp taskloop private(t) shared(out,begin,end) grainsize(GRAINFFT/sizeFFT/(end-begin)+1)
#endif
	for(int i=begin;i<end;i++)
		for (int j=begin;j<=i;j++){
			matcomplex2mpz(cholNew,i*N+j,t);
			if(div<0)
				t<<=-div;
			else
				t>>=div;
			out.matmpz2complex(out.cholOrig,(i-begin)*(end-begin)+j-begin,t);
			out.matcomplex2mpz(out.cholOrig,(i-begin)*(end-begin)+j-begin,t);
//			gmp_printf("%d %d : %Zd\n",i,j,t.get_mpz_t());
		}
#ifdef OPENMP
#pragma omp taskloop private(t) shared(out,begin,end) grainsize(GRAINFFT/out.sizeFFT/(end-begin)+1)
#endif
	for(int i=begin;i<end;i++){
		for (int l=0;l<out.nbLimb;l++){
			for (int j=i-begin+1;j<end-begin;j++)
				out.cholOrig[l][(i-begin)*(end-begin)+j]=0;
		}
		for (int j=0;j<end-begin;j++){
			out.matmpz2complex(out.change,(i-begin)*(end-begin)+j,(i-begin)==j);
		}
	}
#ifdef OPENMP
#pragma omp taskloop private(t) shared(out,begin,end) grainsize(GRAINFFT/out.sizeFFT/10+1)
#endif
	for(int l=0;l<out.nbLimb;l++)
		copy(out.cholOrig[l],out.cholOrig[l]+(end-begin)*(end-begin),out.cholNew[l]);
}

void GramFFT::extractGram(int begin,int end,int prec,Gram &out){
	out.resize(end-begin);
	out.roundPrec(prec);
	mpz_class t;
#ifdef OPENMP
#endif
	for(int i=begin;i<end;i++){
		for (int j=begin;j<=i;j++){
			matcomplex2mpz(cholNew,i*N+j,t);
	//		if(i==j) gmp_printf("%d %d : %Zd\n",i,j,t.get_mpz_t());
			mpfr_set_z_2exp(out.cholOrig[i-begin][j-begin],t.get_mpz_t(),exponent,MPFR_RNDN);
			if(i!=j)
				mpfr_div(out.cholOrig[i-begin][j-begin],out.cholOrig[i-begin][j-begin],out.cholOrig[j-begin][j-begin],MPFR_RNDN);
			mpfr_set(out.cholNew[i-begin][j-begin],out.cholOrig[i-begin][j-begin],MPFR_RNDN);
//			printFlt(out.cholOrig[i-begin][j-begin]);
//			puts("");
		}
		for (int j=0;j<end-begin;j++)
			out.change.v[i-begin][j]=(i-begin)==j;
	}
	for (int i=0;i<end-begin;i++)
		mpfr_sqr(out.cholOrig[i][i],out.cholOrig[i][i],MPFR_RNDN);
}

void GramFFT::destroy(int prec){
	Matrix lat(N,N);
	mpz_class t;
#ifdef OPENMP
#pragma omp taskloop collapse(2) private(t) shared(lat) grainsize(GRAINFFT/sizeFFT+1)
#endif
	for(int i=0;i<N;i++)
		for(int j=0;j<N;j++){
			matcomplex2mpz(change,i*N+j,t);
			lat.v[i][j]=t;
		}
	resize(N,prec);
/*	for(int i=0;i<nbLimb;i++)
		free(cholOrig[i]);*/
#ifdef OPENMP
#pragma omp taskloop collapse(2) private(t) shared(lat) grainsize(GRAINFFT/sizeFFT+1)
#endif
	for(int i=0;i<N;i++)
		for(int j=0;j<N;j++)
			matmpz2complex(change,i*N+j,lat.v[i][j]);
}

void GramFFT::extractGs(vector<double> &gs){
	mpz_class t;
	for(int i=0;i<min(N,(int)gs.size());i++){
		matcomplex2mpz(cholNew,i*N+i,t);
		long int expo;
		gs[i]=log(mpz_get_d_2exp(&expo,t.get_mpz_t()))/log(2);
		gs[i]+=expo+exponent;
	}
}

void GramFFT::benchmarkFFT(){
	mpz_class t;
#ifdef OPENMP
#pragma omp taskloop collapse(2) private(t) grainsize(max(GRAINFFT/sizeFFT/2+1,(N*N)/T))
#endif
	for(int i=0;i<N;i++)
		for(int j=0;j<N;j++){
			matcomplex2mpz(cholNew,i*N+j,t);
			matmpz2complex(cholNew,i*N+j,t);
		}
}

void GramFFT::benchmarkMultiplication(){
	Complex un=1,zero=0;
#ifdef OPENMP
#pragma omp taskloop grainsize(max(GRAIN/N/N/N+1,nbLimb/T))
#endif
	for(int l=0;l<nbLimb;l++)
		cblas_zgemm3m(CblasColMajor,CblasNoTrans,CblasNoTrans,N,N,N,(double*)&un,(double*)(change[l]),N,(double*)(lattice[l]),N,(double*)&zero,(double*)(cholNew[l]),N);
}
