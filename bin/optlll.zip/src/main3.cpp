#include <cassert>
#include <ctime>
#include <csignal>
#include <cblas.h>
#include <omp.h>
#include <unistd.h>
#include "matrix.h"
#include "gram.h"
#include "lllpetit.h"
#include "gramfft.h"

using namespace std;

FILE *logGS;

long long nbSwapLag;
const vector<pair<int,int>> limitFFT={{8,120000},{16,20000},{25,3000},{32,1500},{45,600},{64,200},{72,160}};

Matrix lagrangeSmall(mpfr_t n1,mpfr_t prod,mpfr_t n2,int precision,bool& prec){
	Matrix change(2,2);
	change.identity();
	mpz_class mu;
	mpfr_t a,lim;
	mpfr_init2(a,precision);
	mpfr_init(lim);
	mpfr_div_2si(lim,n1,precision/2,MPFR_RNDN);
//	printFlt(n1);printf(" ");printFlt(n2);prinitf(" ");printFlt(prod);puts("");
	while(1){
		round(mu,prod);
		mpfr_sub_z(prod,prod,mu.get_mpz_t(),MPFR_RNDN);
		mpfr_sqr(a,prod,MPFR_RNDN);
		mpfr_mul(a,n1,a,MPFR_RNDN);
		mpfr_add(a,a,n2,MPFR_RNDN);
		int cmp=mpfr_cmp(n1,a);
		if (mpfr_cmp(n1,lim)<0){
			prec=true;
			mpfr_clear(a);
			return change;
		}
		nbSwapLag++;
//		printFlt(n1);printf(" ");printFlt(n2);printf(" ");printFlt(a);printf(" ");printFlt(prod);puts("");
//		gmp_printf("mu=%Zd\n",mu.get_mpz_t());
		change.transvec(1,0,-mu);
		if (cmp<=0){
			mpfr_clear(a);
			return change;
		}
		mpfr_swap(n1,a);
		mpfr_div(a,a,n1,MPFR_RNDN);
		mpfr_mul(prod,prod,a,MPFR_RNDN);
		mpfr_mul(n2,n2,a,MPFR_RNDN);
		mpz_swap(change.v[0][0].get_mpz_t(),change.v[1][0].get_mpz_t());
		mpz_swap(change.v[0][1].get_mpz_t(),change.v[1][1].get_mpz_t());
	}
}

Matrix lagrange(mpfr_t n1,mpfr_t prod,mpfr_t n2,int precision,bool& prec){
	if (precision<=300)
		return lagrangeSmall(n1,prod,n2,precision,prec);
	int nouvPrec=precision/2+5;
	mpfr_t n1n,prodn,n2n;
	mpfr_init2(n1n,nouvPrec);
	mpfr_init2(n2n,nouvPrec);
	mpfr_init2(prodn,nouvPrec);
	mpfr_set(n1n,n1,MPFR_RNDN);
	mpfr_set(n2n,n2,MPFR_RNDN);
	mpfr_set(prodn,prod,MPFR_RNDN);
	Matrix change=lagrange(n1n,prodn,n2n,nouvPrec,prec);
	if (!prec){
		mpfr_clear(n1n);
		mpfr_clear(n2n);
		mpfr_clear(prodn);
		return change;
	}
	mpfr_clear(n2n);

	prec=false;
	mpfr_t tmp;
	mpfr_init2(tmp,precision);
	mpfr_set_prec(n1n,precision);
	mpfr_set_prec(prodn,precision);

	mpfr_mul_z(tmp,prod,change.v[0][1].get_mpz_t(),MPFR_RNDN);
	mpfr_add_z(tmp,tmp,change.v[0][0].get_mpz_t(),MPFR_RNDN);
	mpfr_sqr(prodn,tmp,MPFR_RNDN);
	mpfr_mul(prodn,prodn,n1,MPFR_RNDN);
	mpfr_set_z(n1n,change.v[0][1].get_mpz_t(),MPFR_RNDN);
	mpfr_sqr(n1n,n1n,MPFR_RNDN);
	mpfr_mul(n1n,n1n,n2,MPFR_RNDN);
	mpfr_add(n1n,n1n,prodn,MPFR_RNDN);

	mpfr_mul(tmp,n1,tmp,MPFR_RNDN);
	mpfr_mul_z(prod,prod,change.v[1][1].get_mpz_t(),MPFR_RNDN);
	mpfr_add_z(prod,prod,change.v[1][0].get_mpz_t(),MPFR_RNDN);
	mpfr_mul(tmp,tmp,prod,MPFR_RNDN);
	mpfr_mul_z(prod,n2,change.v[0][1].get_mpz_t(),MPFR_RNDN);
	mpfr_mul_z(prod,prod,change.v[1][1].get_mpz_t(),MPFR_RNDN);
	mpfr_add(prod,tmp,prod,MPFR_RNDN);
	mpfr_div(prod,prod,n1n,MPFR_RNDN);

	mpfr_mul(n2,n2,n1,MPFR_RNDN);
	mpfr_div(n2,n2,n1n,MPFR_RNDN);

	mpfr_swap(n1n,n1);

	mpfr_clear(tmp);
	mpfr_clear(n1n);
	mpfr_clear(prodn);

	mpfr_prec_round(n1,nouvPrec,MPFR_RNDN);
	mpfr_prec_round(n2,nouvPrec,MPFR_RNDN);
	mpfr_prec_round(prod,nouvPrec,MPFR_RNDN);

	Matrix change2=lagrange(n1,prod,n2,nouvPrec,prec);
	change.multiply(change2);
	return change;
}

double alpha=0.12;

double computeSED(const double *gsn,int N){
	double mini=gsn[N-1]+alpha*(N-1),tot=0;
//	if (N>10)
//	printf("%f %f\n",gsn[N-1],mini);
	for (int i=N-2;i>=0;i--){
		mini=min(mini,gsn[i]+alpha*i);
		tot+=(N-i+1)*max(0.,gsn[i]+alpha*i-mini);
//	if (N>10)
//		printf("%f %f %f\n",gsn[i],mini,tot);
	}
	return tot;
}

double spread(const vector<double> &gsn,int begin,int end,int dist){
	double maxi=0;
	for (int i=begin;i<end;i++){
		for(int j=max(begin,i-dist);j<i;j++)
			maxi=max(maxi,abs(gsn[i]-gsn[j]));
	}
	return maxi;
}

double timeLevel[20],timeSzRed[20],timeMul[20],totalPrec[20],totalPre[20];
vector<pair<double,double>> listeAppels[20];
vector<int> nextBksz;

/* nb de bits; exposant */
pair<int,int> calcPrecisionFFT(const vector<double> &gs,int begin,int end,int bk,int lat){ 
	double szRed=pow(log(end-begin)/log(2),2)/4;
	double maxRed=szRed+spread(gs,begin,end,bk);
	double maxLat=lat+maxRed;
	double minR=spread(gs,begin,end,end)*3+32+szRed+maxRed;
	double maxi=*max_element(gs.begin()+begin,gs.begin()+end);
	int expo=minR-maxi;
	int nbBits=max(maxLat,2*(minR+maxRed+szRed));
/*	for(int i=begin;i<end;i++)
		printf("%lf ",gs[i]);
	printf(": prec=%d, expo=%d\n",nbBits,expo);*/
	return make_pair(nbBits,expo);
}

int calcPrecision(vector<double> gs,int begin,int end){ 
	double szRed=0.15*(end-begin);
	int nbBits=3.5*spread(gs,begin,end,end-begin)+szRed*2+10+60;
/*	for(int i=begin;i<end;i++)
		printf("%lf ",gs[i]);
	printf(": prec=%lf\n",nbBits);*/
	return nbBits;
}

int bitsize(const Matrix &basis,int begin,int end){
	size_t size=0;
	for (int i=begin;i<end;i++){
		for (auto z:basis.v[i]){
//			printf("%d ",mpz_sizeinbase(z.get_mpz_t(),2));
			size=max(size,mpz_sizeinbase(z.get_mpz_t(),2));
		}
//		puts("");
	}
	return size;
}


bool LLLproj(Gram *gram,int begin,int end,vector<double> *curGs,int level,bool *reduced){
	const int N=gram->nbLine();
	assert(N>1);
	if (N==2){
//		printf("debut=%d\n",begin);
		bool prec=false;
		gram->change=lagrange(gram->cholOrig[0][0],gram->cholOrig[1][0],gram->cholOrig[1][1],mpfr_get_prec(gram->cholOrig[0][0]),prec);
		return prec;
	}
	const int origPrec=mpfr_get_prec(gram->cholOrig[0][0]);
	vector<double> gsn(N);
	gram->extractGs(gsn);
	totalPrec[level]+=spread(gsn,0,N,N);
	if(N>=BLOC && origPrec<1200 && N<=DIMPETITLLL){
		LLLpetit LLL;
//		puts("ok");
		LLL.reduit(*gram);
		return false;
	}
	const double initDist=computeSED(&gsn[0],N)+1;
	const int bkSz=nextBksz[N];
	double start=omp_get_wtime();
	double maxGs=0,minGs=0;
	double distGS=N,ancDistGS=0;
//	printf("prec=%d N=%d\n",origPrec,N);
	for(int iter=0;computeSED(&gsn[0],N)>=0.2*(initDist+iter) && distGS+ancDistGS>1e-2;iter++){
//		printf("iter=%d %d,%d\n",iter,begin,end);
		bool fail=false;
#ifdef OPENMP
#pragma omp taskloop
#endif
		for(int nbegin=bkSz/2*(iter%2);nbegin<N;nbegin+=bkSz){
			int nend=min(nbegin+bkSz,N);
			if (nend-nbegin>=2){
//				printf("%d,%d\n",nbegin,nend);
				Gram block;
				int curPrec;
				bool curFailure=false;
				bool curReduced;
				curPrec=calcPrecision(gsn,nbegin,nend);
				gram->extractGram(nbegin,nend,curPrec,block);
				curFailure=LLLproj(&block,nbegin+begin,nend+begin,curGs,level+1,&curReduced);
				if (curFailure){
					puts("fail!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
					fail=true;
				}
				double st=omp_get_wtime();
//				block.change.output(stdout);
				gram->change.multiply(block.change,nbegin);
//				gram->change.output(stdout);
				timeMul[level]+=omp_get_wtime()-st;
			}
		}
		if (fail)
			return true;
		double st=omp_get_wtime();
		if (gram->sizeRed(bkSz/2*(iter%2),N,false))
			return true;
		timeSzRed[level]+=omp_get_wtime()-st;
		vector<double> ancGsn=gsn;
		gram->extractGs(gsn);
		ancDistGS=distGS;
		distGS=0;
		for(int i=0;i<N;i++){
//			printf("%f ",gsn[i]);
			distGS+=fabs(gsn[i]-ancGsn[i]);
		}
//		puts("ok");
		if (iter){
			for(int i=0;i<N;i++)
				if (gsn[i]>maxGs+0.1 || gsn[i]<minGs-0.1)
					return true;
		}
		maxGs=-1;
		minGs=1e100;
		for(int i=0;i<N;i++){
			maxGs=max(maxGs,gsn[i]);
			minGs=min(minGs,gsn[i]);
		}
	}
//	puts("fin mpfr");
	timeLevel[level]+=omp_get_wtime()-start;
	*reduced=distGS+ancDistGS<1e-4;
	return false;
}

bool useFFT(const vector<double> gsn,int begin,int end){
	bool r=false;
	int spr=spread(gsn,begin,end,end-begin);
	for(auto p:limitFFT)
		r=r || (p.first<=end-begin && spr>p.second);
	return r;
}

bool LLLprojFFT(GramFFT *gram,int begin,int end,vector<double> *curGs,int level,bool *reduced){
	const int N=gram->nbLine();
	assert(N>1);
	vector<double> gsn(N);
	gram->extractGs(gsn);
	const double initDist=computeSED(&gsn[0],N);
	const int bkSz=nextBksz[N];
	const int origPrec=calcPrecisionFFT(gsn,0,N,bkSz,0).first;
	int curPrec=origPrec;
	double start=omp_get_wtime();
	double maxGs=0,minGs=0;
	double distGS=N,ancDistGS=0;
	const double origSpr=spread(gsn,0,N,N);
	totalPrec[level]+=origSpr;
	totalPre[level]+=origPrec;
//	printf("FFT prec=%d N=%d\n",origPrec,N);
	vector<GramFFT*> pile;
	for(int iter=0;computeSED(&gsn[0],N)>=min(0.1*initDist,pow(iter/log(max(3.,origSpr/N/alpha)),2)*(alpha*N*N)) && distGS+ancDistGS>1;iter++){
		const double nivDebug=log(N*N*(N*curPrec/1e10))/log(4);
//		printf("%lf %lf %lf\n",computeSED(&gsn[0],N),0.1*initDist,pow(iter/log(10*origSpr/N),2)*(N*N/20.));
//		printf("cholOrig=");gram->printMat(0,N,N,gram->cholOrig);
//		printf("cholNew=");gram->printMat(0,N,N,gram->cholNew);
//		printf("change=");gram->printMat(0,N,N,gram->change);
#ifdef OPENMP
#pragma omp critical(affiche)
#endif
		{
		if (nivDebug>-2){
			for (int i=0;i<N;i++)
				(*curGs)[begin+i]=gsn[i];
			for (auto g:*curGs){
				if(logGS) fprintf(logGS,"%.10f\n",g);
			}
			if(logGS) fprintf(logGS,"\n\n\n");
			if(logGS) fflush(logGS);
		}
		}
		if(calcPrecisionFFT(gsn,0,N,bkSz,0).first<0.7*curPrec){
			GramFFT *nouvGram=new GramFFT;
			pair<int,int> param=calcPrecisionFFT(gsn,0,N,bkSz,0);
			curPrec=param.first;
			gram->extractGramFFT(0,N,param.first,-gram->exponent-param.second,*nouvGram);
			gram->destroy(bitsize(gram->extractChange(),0,N)+spread(gsn,0,N,N)+pow(log(N)/log(2),2)/2);
			pile.push_back(gram);
			gram=nouvGram;
		}
		bool fail=false;
#ifdef OPENMP
		omp_lock_t lock;
		omp_init_lock(&lock);
#pragma omp taskloop untied
#endif
		for(int nbegin=bkSz/2*(1-iter%2);nbegin<N;nbegin+=bkSz){
			int nend=min(nbegin+bkSz,N);
//			printf("[%d;%d[\n",nbegin,nend);
				if (nend-nbegin>=2){
					Gram block;
					GramFFT blockFFT;
					int curPrec;
					double fact=1;
					bool curFailure=false;
					const bool usFFT=useFFT(gsn,nbegin,nend);
					bool curReduced;
					do {
						curPrec=calcPrecision(gsn,nbegin,nend);
						pair<int,int> param=calcPrecisionFFT(gsn,nbegin,nend,nextBksz[bkSz],0);
//						printf("taille : %f; prec=%d\n",mini-gram->exponent,curPrec);
#ifdef OPENMP
						omp_set_lock(&lock);
#endif
						if (usFFT)
							gram->extractGramFFT(nbegin,nend,param.first,-gram->exponent-param.second,blockFFT);
						else
							gram->extractGram(nbegin,nend,curPrec,block);
#ifdef OPENMP
						omp_unset_lock(&lock);
#endif
						if (usFFT)
							curFailure=LLLprojFFT(&blockFFT,nbegin+begin,nend+begin,curGs,level+1,&curReduced);
						else
							curFailure=LLLproj(&block,nbegin+begin,nend+begin,curGs,level+1,&curReduced);

						fact*=1.5;
					}while (curPrec<origPrec && curFailure);
//					if(N>60) printf("red %d-%d %d\n",begin+nbegin,begin+nend,curPrec);
					if (curFailure){
						puts("fail!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
						fail=true;
					}
//						printf("FFT: %d %d\n",useFFT,curPrec);
		//			if (niv) {printf("multiplie…");fflush(stdout);}
					double st=omp_get_wtime();
/*					if (useFFT)
						blockFFT.printMat(0,nend-nbegin,nend-nbegin,blockFFT.change);
					else
						block.change.output(stdout);*/
//					block.change.output(stdout);
#ifdef OPENMP
					omp_set_lock(&lock);
#endif
					if (usFFT)
						gram->multiply(blockFFT,nbegin);
					else
						gram->multiply(block,nbegin);
#ifdef OPENMP
					omp_unset_lock(&lock);
#endif
					timeMul[level]+=omp_get_wtime()-st;
	//				if(N>20)printf("red end %d-%d\n",begin+nbegin,begin+nend);
				}
		}
#ifdef OPENMP
		omp_destroy_lock(&lock);
#endif
		if (fail){
			puts("fail");
			return true;
		}
		double st=omp_get_wtime();
//		printf("SzRed %d\n",N);
		if (gram->sizeRed(0,N)){
			puts("échec");
//			gram->extractChange().output(stdout);
			assert(0);
			return true;
		}
		timeSzRed[level]+=omp_get_wtime()-st;
		vector<double> ancGsn=gsn;
		gram->extractGs(gsn);
		ancDistGS=distGS;
		distGS=0;
		for(int i=0;i<N;i++)
			distGS+=fabs(gsn[i]-ancGsn[i]);
/*					for (int i=0;i<N;i++)
						printf("%f ",gsn[i]);
					puts("");*/
		if (iter){
			for(int i=0;i<N;i++)
				if (gsn[i]>maxGs+2 || gsn[i]<minGs-0.1){
					printf("%f is not in [%f;%f]\n",gsn[i],minGs,maxGs);
					assert(0);
					return true;
				}
		}
		maxGs=-1;
		minGs=1e100;
		for(int i=0;i<N;i++){
			maxGs=max(maxGs,gsn[i]);
			minGs=min(minGs,gsn[i]);
		}
		if (nivDebug>0)
			printf("[%d;%d[ bkSz=%d prec=%d (%d) avancement:%f dist=%f err=%g maxi=%g\n",begin,end,bkSz,origPrec,curPrec,computeSED(&gsn[0],N)/initDist,distGS,errMax,maxFourier);
	}
	if(pile.size()>0){
		double st=omp_get_wtime();
		pile.back()->multiply(*gram,0);
		while(pile.size()>1){
			pile[pile.size()-2]->multiply(*pile.back(),0);
			delete pile.back();
			pile.pop_back();
		}
		timeMul[level]+=omp_get_wtime()-st;
	}
	for (int i=0;i<N;i++)
		(*curGs)[begin+i]=gsn[i];
	double temps=omp_get_wtime()-start;
	timeLevel[level]+=temps;
#ifdef OPENMP
#pragma omp critical(listeAppels)
#endif
	{
		listeAppels[level].push_back(make_pair(origSpr,temps));
	}
	*reduced=distGS+ancDistGS<1e-4;
	return false;
}

GramFFT *curGram=NULL;

void LLL(Matrix &basis, bool weak=false){
	int N=basis.nbColumn(),M=basis.nbLine();
	assert(N==M);
	GramFFT gram(N);
	vector<double> complexity(N+1);
	complexity[1]=1;
	nextBksz.resize(N+1);
	for (int n=2;n<=N;n++){
		complexity[n]=pow(n,5.);
		int bkSz=2;
		for (int k=2;k<n;k++){
//			double c=(complexity[k]*3+pow(n,3))*pow(n/k+1.,2.);
			double c=complexity[k]*pow((n+0.)/k,2)+pow(n,3)/-log(cos(M_PI/2/((1+n/k))));
//			if (n==399) printf("%d %f %f\n",k,c,((1+n/k))+0.);
			if (c<complexity[n]){
				complexity[n]=c;
				bkSz=k;
			}
		}
		nextBksz[n]=min(bkSz,N/2+1);
//		printf("bk %d:%d\n",n,nextBksz[n]);
	}
	vector<double> gs(N);
	gram.exponent=0;
	double precEntries=1;
	printf("Bits:%d\n",bitsize(basis,0,N));
	do{
		gs[0]=precEntries*bitsize(basis,0,N);
		pair<int,int> params=calcPrecisionFFT(gs,0,N,nextBksz[N],0);
		gram.resize(N,params.first);
		gram.exponent=-params.second;
		printf("expo=%d\n",gram.exponent);
		mpz_class t;
		for(int i=0;i<N;i++){
			for(int j=0;j<N;j++)
				gram.matmpz2complex(gram.cholOrig,i*N+j,((mpz_class)(i==j))<<(-gram.exponent));
			for(int j=0;j<N;j++){
				gram.matmpz2complex(gram.change,i*N+j,basis.v[i][j]);
			}
		}
		precEntries*=1.5;
	}while(gram.sizeRed(0,N));
	curGram=&gram;
	bool reduced=false;
	gram.extractGs(gs);
//	basis.output(stdout);
//		gram.roundPrec(curPrec);
	printf("spread=%f => err=%f\n",spread(gs,0,N,N),errMax);
	fflush(stdout);
	bool err;
	err=LLLprojFFT(&gram,0,N,&gs,0,&reduced);
	if (err){
		puts("more precision");
		assert(0);
	}
	for(auto t:gs)
		printf("%f\n",t);
/*	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++)
			gram.matcomplex2mpz(gram.change,i*N+j,basis.v[i][j]);
	}
	basis.output(stdout);*/
	basis=gram.extractChange();
}

void handler(int sig){
#ifdef OPENMP
#pragma omp master
#endif
	{
	if (curGram){
		int N=curGram->nbLine();
		Matrix m(N,N);
		for(int i=0;i<N;i++){
			for(int j=0;j<N;j++)
				curGram->matcomplex2mpz(curGram->change,i*N+j,m.v[i][j]);
		}
		m.output(stderr);
		printf("Interrupted, current matrix saved\n");
		printf("upd:%f prod:%f ortho:%f SR:%f\n",timeUpd,timeProd,timeOrtho,timeSR);
		for(int i=0;i<5;i++)
			printf("%f,%f,%f\n",timeLevel[i],timeSzRed[i],timeMul[i]);
	}
	}
	exit(0);
}

void stat(){
	printf("upd:%f prod:%f ortho:%f SR:%f\n",timeUpd,timeProd,timeOrtho,timeSR);
	timeUpd=timeProd=timeOrtho=timeSR=0;
	for(int i=0;timeLevel[i]>1e-3;i++){
		printf("%f,%f,%f;GS:%f, Prec:%f\n",timeLevel[i],timeSzRed[i],timeMul[i],totalPrec[i]/pow(2,2*i),totalPre[i]/pow(2,2*i));
		timeLevel[i]=timeSzRed[i]=timeMul[i]=totalPrec[i]=totalPre[i]=0;
	}
	statsLLLpetit();
	printf("nbSwapLagrange=%lld\n",nbSwapLag);
	for(int i=0;timeLevel[i]>1e-3;i++){
		sort(listeAppels[i].begin(),listeAppels[i].end(),[](const auto &a,const auto &b){return a.first<b.first;});
		char fich[100];
		sprintf(fich,"appel%d",i);
		FILE *f=fopen(fich,"a");
		for(auto a:listeAppels[i])
			fprintf(f,"%f %f\n",a.first,a.second);
		fprintf(f,"\n");
		listeAppels[i].clear();
	}
	nbSwapLag=0;
}

void structuredLLL(Matrix& base){
	int n=base.v.size();
	int l=0;
	while((n>>l)>=4)l++;
	for(;l>=0;l--){
		int m=(n>>l)+(l>0?1:0);
		Matrix nouv(m,m);
		for(int i=0;i<m;i++)
			for(int j=0;j<m;j++)
				nouv.v[i][j]=base.v[i][j];
		double st=omp_get_wtime();
		LLL(nouv,l>0);
		printf("LLL: %f s\n",omp_get_wtime()-st);;
//		nouv.output(stdout);
		for(int i=0;i<m;i++)
			for(int j=0;j<m;j++)
				base.v[i][j]=nouv.v[i][j];
		st=omp_get_wtime();
#ifdef OPENMP
#pragma omp taskloop shared(base,nouv,m) grainsize(4)
#endif
		for(int deb=m;deb<n;deb+=m){
			printf("str %d\n",deb);
			int N=m+min(n-deb,m);
			vector<double> gsn(N);
			gsn[0]=bitsize(base,deb,deb+N-m);
			Matrix change(N);
			if (useFFT(gsn,0,N) && N>=32){
				puts("FFT!");
				GramFFT gram;
				pair<int,int> params=calcPrecisionFFT(gsn,0,N,N/2,0);
				gram.exponent=-params.second;
				gram.resize(N,params.first);

#ifdef OPENMP
#pragma omp taskloop shared(gram,base,N,m,deb) default(none)
#endif
				for(int i=0;i<N;i++){
					for(int j=0;j<N;j++)
						gram.matmpz2complex(gram.cholOrig,i*N+j,((mpz_class)(i==j))<<(-gram.exponent));
					for(int j=0;j<N;j++){
						mpz_class t=j<m ? base.v[i<m ? i: i-m+deb][j] : int(i==j);
						gram.matmpz2complex(gram.change,i*N+j,t);
	//						gmp_printf("%Zd ",t);
					}
	//					gmp_printf("\n",t);
				}
				gram.sizeRed(0,N);
#ifdef OPENMP
#pragma omp taskloop shared(base,gram,N,m,deb) default(none)
#endif
				for(int i=m;i<N;i++)
					for(int j=0;j<m;j++)
						gram.matcomplex2mpz(gram.change,i*N+j,base.v[i-m+deb][j]);
			}
			else{
				Gram gram(N);
				gram.roundPrec(calcPrecision(gsn,0,N));
				for(int i=0;i<N;i++)
					for(int j=0;j<N;j++){
						if(j<=i) mpfr_set_si(gram.cholOrig[i][j],int(i==j),MPFR_RNDN);
						gram.change.v[i][j]=j<m ? base.v[i<m ? i: i-m+deb][j] : int(i==j);
					}
				gram.sizeRed(0,N);
				for(int i=m;i<N;i++)
					for(int j=0;j<m;j++)
						base.v[i-m+deb][j]=gram.change.v[i][j];

			}
		}
		if(l) printf("Réduction taille: %f s\n",omp_get_wtime()-st);;
		stat();
//		base.output(stdout);
	}

}

void benchmark(int N,int B){
	GramFFT gram(N);
	vector<double> gs(N);
	gs[0]=B;
	pair<int,int> param=calcPrecisionFFT(gs,0,N,N/2,0);
	gram.resize(N,param.first);
	gram.exponent=-param.second;
	printf("expo=%d, prec=%d\n",gram.exponent,param.first);
	mpz_class t;
	gmp_randclass r1 (gmp_randinit_mt);
	for(int i=0;i<N;i++){
		nextBksz.push_back(i/2+1);
		for(int j=0;j<N;j++)
			gram.matmpz2complex(gram.cholOrig,i*N+j,((mpz_class)(i==j))<<(-gram.exponent));
		for(int j=0;j<N;j++){
			t=1+r1.get_z_bits(B);
			gram.matmpz2complex(gram.change,i*N+j,(i==j && i<N/2) || (i>=N/2 && j<N/2) ? t : (i==j && i>=N/2));
		}
	}
	nextBksz.push_back(N/2+1);
	double st=omp_get_wtime();
	for(int i=0;i<10;i++)
		gram.benchmarkFFT();
	printf("MUL FFT: %f s, per bit %g\n",(omp_get_wtime()-st)/10,(omp_get_wtime()-st)/B/10);
	st=omp_get_wtime();
	for(int i=0;i<3;i++)
		gram.benchmarkMultiplication();
	printf("MUL BLAS: %f s, per bit %g\n",(omp_get_wtime()-st)/3,(omp_get_wtime()-st)/B/3);
	st=omp_get_wtime();
	gram.sizeRed(0,N);
	printf("SR FFT: %f s, per bit %g\n",omp_get_wtime()-st,(omp_get_wtime()-st)/B);
//	gram.extractChange().output(stderr);
	Gram G;
	int prec=calcPrecision(gs,0,N);
	printf("prec=%d\n",prec);
	gram.extractGram(0,N,prec,G);
	st=omp_get_wtime();
	if(N<500){
		G.sizeRed(0,N,true);
		printf("SR MPFR: %f s, per bit %g\n",omp_get_wtime()-st,(omp_get_wtime()-st)/B);
	}
	bool red;
	st=omp_get_wtime();
	LLLprojFFT(&gram,0,N,&gs,0,&red);
	printf("LLL FFT %f s, per bit %g\n",omp_get_wtime()-st,(omp_get_wtime()-st)/B);
	if(N<=DIMPETITLLL && B<=300){
		st=omp_get_wtime();
		LLLpetit l;
		l.reduit(G);
		printf("L²: %f s, per bit %g\n",omp_get_wtime()-st,(omp_get_wtime()-st)/B);
		statsLLLpetit();
	}
	else if(N<=300){
		st=omp_get_wtime();
		LLLproj(&G,0,N,&gs,0,&red);
	//	for(auto t:gs) printf("%f\n",t);
		printf("LLL MPFR %f s, per bit %g\n",omp_get_wtime()-st,(omp_get_wtime()-st)/B);
	}

/*	printf("%d %d\n",gram.sizeFFT,gram.maxNz);*/
}

int main(int argc,char **argv){
//	omp_set_thread_limit(omp_get_max_threads());
	int nbThreads=omp_get_max_threads();
	openblas_set_num_threads(1);
	Matrix lat;
//	benchmark(39,500);
//	signal(SIGINT,handler);
	int c;
	bool structure=false,sortie=true;
	int B=-1,N=-1;
	while((c=getopt(argc,argv,"hsn:b:Qp:a:"))!=-1){
		switch(c){
			case 's':
				structure=true;
				break;
			case 'a':
				sscanf(optarg,"%lf",&alpha);
				break;
			case 'b':
				sscanf(optarg,"%d",&B);
				break;
			case 'n':
				sscanf(optarg,"%d",&N);
				break;
			case 'Q':
				sortie=false;
				break;
			case 'p':
				sscanf(optarg,"%d",&nbThreads);
				break;
			case 'h':
			default:
				puts("Reads a lattice in NTL/fplll format, outputs a reduction on stderr");
				puts("-s for a structured lattice; -n N -b B for a benchmark on a NTRU-like basis with dimension 2N and B bits");
				puts("-Q for no lattice on stderr");
				puts("-p x for using x threads");
				puts("-a alpha for trying to reduce with rate 2^alpha");
				return 1;
		}
	}
	if(N>=0 && B==-1)
		B=N/2;
	if(N==-1){
		char filename[30];
		sprintf(filename,"logGS%d",(int)time(NULL)%10000);
		printf("%s\n",filename);
		logGS=fopen(filename,"a");
		lat.read(stdin);
	}
#ifdef OPENMP
	omp_set_num_threads(nbThreads);
	printf("OMP, %d threads\n",nbThreads);
#pragma omp parallel
#pragma omp single nowait
#endif
	{
		if(structure){
			structuredLLL(lat);
		}
		else if(N>=0)
			benchmark(N,B);
		else{
			LLL(lat);
			stat();
		}
	}
	if(N==-1){
		fclose(logGS);
		if(sortie) lat.output(stderr);
	}

	return 0;
}
