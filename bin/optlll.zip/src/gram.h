#ifndef GRAM_H

#define GRAM_H

#include <mpfr.h>
#include <vector>
#include "matrix.h"
#include "util.h"
#include "../config.h"

using namespace std;

extern double timeUpd,timeProd,timeOrtho,timeSR;

class Gram{
	public :
	vector<mpfr_t*> cholOrig;
	vector<mpfr_t*> cholNew; // Décomposition Cholesky de lattice
	vector<mpfr_t*> lattice; // = cholOrig*change
	Matrix change;
	int nbLine() const {
		return cholOrig.size();
	}
	void resize(int nbLines){
		int N=nbLine();
		for (int i=nbLines;i<N;i++){
			for (int j=0;j<=i;j++){
				mpfr_clear(cholNew[i][j]);
				mpfr_clear(cholOrig[i][j]);
			}
			for (int j=0;j<N;j++)
				mpfr_clear(lattice[i][j]);
			free(cholOrig[i]);
			free(cholNew[i]);
			free(lattice[i]);
		}
		cholNew.resize(nbLines);
		cholOrig.resize(nbLines);
		lattice.resize(nbLines);
		change.resize(nbLines,nbLines);
		for (int j=N;j<nbLines;j++){
			cholOrig[j]=(mpfr_t*)malloc((j+1)*sizeof(mpfr_t));
			cholNew[j]=(mpfr_t*)malloc((j+1)*sizeof(mpfr_t));
			for (int i=0;i<=j;i++){
				mpfr_init(cholOrig[j][i]);
				mpfr_init(cholNew[j][i]);
			}
		}
		for (int j=0;j<nbLines;j++){
			lattice[j]=(mpfr_t*)malloc(nbLines*sizeof(mpfr_t));
			for (int i=0;i<nbLines;i++)
				mpfr_init(lattice[j][i]);
		}
	}
	Gram(int nbLines=0){
		resize(nbLines);
	}
	~Gram(){
		resize(0);
	}
	void roundPrec(int prec){
		int N=nbLine();
		for (int i=0;i<N;i++){
			for (int j=0;j<=i;j++){
				mpfr_prec_round(cholOrig[i][j],prec,MPFR_RNDN);
				mpfr_prec_round(cholNew[i][j],prec,MPFR_RNDN);
			}
			for (int j=0;j<N;j++)
				mpfr_prec_round(lattice[i][j],prec,MPFR_RNDN);
		}
	}
	void output(FILE *f) const{
		fprintf(f,"[");
		for (int i=0;i<nbLine();i++){
			fprintf(f,"[");
			for (int j=0;j<=i;j++){
				printFlt(cholNew[i][j]);
				fprintf(f," ");
			}
			fprintf(f,"]%c",i==nbLine()-1 ? ' ':'\n');
		}
		fprintf(f,"]\n");
	}
	void updateLattice(int k);
	bool sizeRed(int begin,int end,bool fullred=true);
	bool multiply(const Matrix &mul,int begin=0);
	void extractGram(int begin,int end,int prec,Gram &out) const;
	void extractGs(vector<double> &gs) const;
};

#endif
