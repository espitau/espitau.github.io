#include <cassert>
#include "matrix.h"
#include "util.h"
#ifdef OPENMP
#include <omp.h>
#endif

bool Matrix::read(FILE *f){
	int ch;
	nextNonBlankChar(f,ch);
	if (ch!='[')
		return false;
	resize(0,0);
	mpz_t val;
	mpz_init(val);
	for (int i=0;;i++){
		nextNonBlankChar(f,ch);
		if (ch != '['){
			mpz_clear(val);
			return ch==']';
		}
		resize(nbLine(),nbColumn()+1);
		for (int j=0;;j++){
			if (gmp_fscanf(f,"%Zd",val)==0)
				break;
			if (j==nbLine())
				resize(nbLine()+1,nbColumn());
			mpz_swap(v[i][j].get_mpz_t(),val);
		}
		nextNonBlankChar(f,ch);
		if (ch != ']'){
			mpz_clear(val);
			return false;
		}
	}
}

void Matrix::multiply(const Matrix& mul,int begin){
	int N=mul.nbLine(),M=nbLine();
//	printf("%d %d %d\n",begin,N,nbColumn());
	assert(begin+N<=nbColumn());
	assert(mul.nbColumn()==N);
	vector<mpz_class> nouv(N);
#ifdef OPENMP
	for(int i=0;i<M;i++){
#pragma omp parallel for if(N>100) //num_threads(1)
		for (int j=0;j<N;j++){
			nouv[j]=0;
			for (int k=0;k<N;k++){
				nouv[j]+=v[begin+k][i]*mul.v[j][k];
			}
		}
		for (int j=0;j<N;j++)
			mpz_swap(v[begin+j][i].get_mpz_t(),nouv[j].get_mpz_t());
	}
#else
	for(int i=0;i<M;i++){
		for (int j=0;j<N;j++){
			nouv[j]=0;
			for (int k=0;k<N;k++){
				nouv[j]+=v[begin+k][i]*mul.v[j][k];
			}
		}
		for (int j=0;j<N;j++)
			mpz_swap(v[begin+j][i].get_mpz_t(),nouv[j].get_mpz_t());
	}
#endif
}

void Matrix::transvec(int dst,int src,mpz_class mul){
	if (mpz_fits_sint_p(mul.get_mpz_t())){
		transvec(dst,src,mpz_get_si(mul.get_mpz_t()));
		return ;
	}
	int N=nbLine();
/*#ifdef OPENMP
#pragma omp parallel for if(N>100)
	for (int i=0;i<N;i++)
		v[dst][i]+=v[src][i]*mul;
#else*/
	for (int i=0;i<N;i++)
		v[dst][i]+=v[src][i]*mul;
//#endif
}

void Matrix::transvec(int dst,int src,int mul){
	int N=nbLine();
/*#ifdef OPENMP
#pragma omp parallel for if(N>100) //num_threads(1)
	for (int i=0;i<N;i++)
		v[dst][i]+=v[src][i]*mul;
#else*/
	for (int i=0;i<N;i++)
		v[dst][i]+=v[src][i]*mul;
//#endif
}

