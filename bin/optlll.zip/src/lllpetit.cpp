#include <cstdio>
#include <cmath>
#include <cassert>
#include <algorithm>
#include <omp.h>
#include <vector>
#include <gmp.h>
#include <gmpxx.h>
#include "lllpetit.h"


const int base=58;
const int LAISSE=22;
const int FACT=10;
const Float FACTD=5e10;
const int ETAPES=4;
const Int MAXI=1ll<<39;
const IntP MAXI2=1<<20;


long long nbSwapPetit;
long long nbLLL,nbLLLP;
double temps,tempsPetit,tempsGS;


void LLLpetit::calcGs(int i){
	for(int j=0;j<=i;j++){
		Float &res=r[j];
		res=0;
		for(int k=0;k<DIMPETITLLL;k++){
			res+=matlll[i][k]*(Float)matlll[j][k];
//			if(i==j && i==14)
//			printf("%d,%d : %Lf %Lf\n",i,j,res,12864850791.L*12864850791.L);
		}
		for(int k=0;k<j;k++){
//			printf("%f ",res);
			res-=r[k]*gso[j][k];
		}
		if(i>j)
			gso[i][j]=res/gso[j][j];
		else
			gso[i][j]=res;
//		printf("%d,%d : %Lf\n",i,j,res/sqrt(gso[j][j]));
	}
	gso[i][i]=max((Float)1,gso[i][i]);
//	printf("%d %Lf\n",i,sqrt(gso[i][i]));
}

void LLLpetit::redTaille(int i,int fin,Int &maxi){
	int iter=0;
	do{
		iter++;
		maxi=0;
		for(int j=fin;j>=0;j--){
			Int mu=round((double)gso[i][j]);
			if(mu==0)
				continue;
			gso[i][j]-=mu;
//			printf("%d : %f\n",j,gso[i][j]);
			for(int k=0;k<j;k++)
				gso[i][k]-=mu*gso[j][k];
			for(int k=0;k<DIMPETITLLL;k++)
				changement[i][k]-=mu*changement[j][k];
			for(int k=0;k<DIMPETITLLL;k++)
				matlll[i][k]-=mu*matlll[j][k];
			maxi=max(maxi,abs(mu));
		}
		if (maxi>1000) // perte de précision
			calcGs(i);
		if (iter>1000){
			printf("%d :",i);
			for(int j=0;j<i;j++)
				printf("%Lg ",gso[j][j]);
			puts("");
			assert(false);
		}
/*		printf("%d %ld\n",i,maxi);*/
	}while(maxi>1000);
}

void LLLpetit::lllPetit(int debut,double delta){
	const int L=BLOC;
//	printf("%d %d\n",debut,L);
	nbLLLP++;
	double tps=omp_get_wtime();
	const int bl=0;
	Float maxGS=gso[debut][debut];
	for(int i=1;i<L;i++)
		maxGS=max(maxGS,gso[debut+i][debut+i]);
	for(int i=0;i<L;i++){
		matlllb[bl][i][i]=sqrt(gso[debut+i][debut+i]/maxGS)*MAXI2+1;
		for(int j=i+1;j<L;j++)
			matlllb[bl][j][i]=gso[debut+j][debut+i]*matlllb[bl][i][i];
		for(int j=i+1;j<L;j++)
			matlllb[bl][i][j]=0;
	}
/*	for(int i=0;i<L;i++)
		printf("%.1f ",2*log(matlllb[bl][i][i])/log(2));
	puts("");*/
	for (int i=0;i<L;i++)
		for (int j=0;j<L;j++)
			changementb[bl][i][j]=i==j;
	int i=0;
	bool recalc=true;
	while(i<min(L,n)){
//		printf("%d\n",i);
//		recalc=true;
		for(int j=recalc ? 0 : max(0,i-1);j<=i;j++){
			FloatP &res=rb[bl][j];
			res=0;
			for(int k=0;k<L;k++)
				res+=matlllb[bl][i][k]*(Float)matlllb[bl][j][k];
			for(int k=0;k<j;k++)
				res-=rb[bl][k]*gsob[bl][j][k];
			if(i>j)
				gsob[bl][i][j]=res/gsob[bl][j][j];
			else
				gsob[bl][i][j]=res;
		}
//		printf("petit :%d %f %d %f\n",i,gsob[bl][i][i],recalc,matlllb[bl][7][7]);
/*			for(int k=0;k<L;k++)
				printf("%f ",matlllb[bl][i][k]);
			puts("");*/
		IntP maxi=0;
		FloatP norme;
		if (i>0){
			IntP mu=round(gsob[bl][i][i-1]);
			norme=gsob[bl][i][i]+(rb[bl][i-1]-mu*gsob[bl][i-1][i-1])*(gsob[bl][i][i-1]-mu);
		}
		for(int j=i-1;j>=0;j--){
			IntP mu=round(gsob[bl][i][j]);
			gsob[bl][i][j]-=mu;
			for(int k=0;k<j;k++)
				gsob[bl][i][k]-=mu*gsob[bl][j][k];
			for(int k=0;k<L;k++)
				changementb[bl][i][k]-=mu*changementb[bl][j][k];
			for(int k=0;k<L;k++)
				matlllb[bl][i][k]-=mu*matlllb[bl][j][k];
			maxi=max(maxi,abs(mu));
		}
		if (maxi>1000) continue;
		if(i>0 && norme<delta*gsob[bl][i-1][i-1]){
			for(int k=0;k<L;k++)
				swap(changementb[bl][i][k],changementb[bl][i-1][k]);
			for(int k=0;k<L;k++)
				swap(matlllb[bl][i][k],matlllb[bl][i-1][k]);
			recalc=maxi>0;
			if (!recalc)
				for(int k=0;k<i;k++)
					gsob[bl][i-1][k]=gsob[bl][i][k];
			i--;
			nbSwapPetit++;
		}
		else{
			i++;
			recalc=true;
		}
	} 
/*	for(int i=0;i<L;i++)
		printf("%.1f ",log(gsob[bl][i][i])/log(2));
	puts("");*/
	tempsPetit+=omp_get_wtime()-tps;
	Float nouv[BLOC];
	Int nouvI[BLOC]; // On applique la matrice
/*			printf("debut=%d %d\n",debut,bl);
	for(int i=0;i<L;i++){
		for(int j=0;j<L;j++)
			printf("%d ",changementb[bl][i][j]);
		puts("");
	}*/
	for(int i=0;i<debut;i++){
		for(int j=0;j<L;j++)
			nouv[j]=0;
		for(int j=0;j<L;j++)
			for(int k=0;k<L;k++)
				nouv[j]+=gso[debut+k][i]*changementb[bl][j][k];
		for(int j=0;j<L;j++){
			gso[debut+j][i]=nouv[j];
		}
	}
	for(int i=0;i<DIMPETITLLL;i++){
		memset(nouvI,0,BLOC*sizeof(Int));
		for(int j=0;j<L;j++)
			for(int k=0;k<L;k++)
				nouvI[j]+=changement[debut+k][i]*changementb[bl][j][k];
		for(int j=0;j<L;j++)
			changement[debut+j][i]=nouvI[j];
		memset(nouvI,0,BLOC*sizeof(Int));
		for(int j=0;j<L;j++)
			for(int k=0;k<L;k++)
				nouvI[j]+=matlll[debut+k][i]*changementb[bl][j][k];
		for(int j=0;j<L;j++)
			matlll[debut+j][i]=nouvI[j];
	}
	Int maxi;
/*	for(int i=0;i<L;i++){
		for(int j=0;j<L;j++)
			printf("%d ",changementb[bl][i][j]);
		puts("");
	}*/
	for(int i=0;i<L;i++){ // on réduit en taille maintenant pour ne pas dépasser 64 bits
		redTaille(debut+i,debut-1,maxi);
	}
}


bool LLLpetit::lll(){
	double tps=omp_get_wtime();
	nbLLL++;
	for (int i=0;i<DIMPETITLLL;i++)
		for (int j=0;j<DIMPETITLLL;j++)
			changement[i][j]=i==j;
	int i=0;
	int maxVect=BLOC,maxRed=0;
	Int maxi;
	Float mini=matlll[0][0]*(0.+matlll[0][0]);
	for(int it=0;it<3;it++){
		mini/=1e8;
//		printf("Mini=%Lg ",mini);
		for(int i=0;i<min(n,BLOC);i++){
			calcGs(i);
			redTaille(i,i-1,maxi);
			gso[i][i]+=mini;
//			printf("%Lg ",gso[i][i]);
		}
//		puts("");
	//	printf("LLL=%d\n",n);
		lllPetit(0,.99);
	}
	while(maxVect<n){
//		printf("maxVect=%d\n",maxVect);
		int fin=min(i+BLOC,maxVect+1);
		int debut=max(0,fin-BLOC);
//		printf("maxRed=%d\n",maxRed);
		for(int k=maxRed;k<fin;k++){
			calcGs(k);
			redTaille(k,k-1,maxi);
		}
/*		if(gso[fin-1][fin-1]>1000*gso[debut][debut]){
			puts("ok");
			return true;
		}*/
/*		for(int k=0;k<fin;k++)
			printf("%.1Lf ",log(gso[k][k])/log(2));
		puts("");*/
//		printf("petit :%d %d %f\n",fin,fin-debut,gso[fin-1][fin-1]);
		if(fin==maxVect+1){
			Float maxi=max(gso[0][0]/FACTD,gso[debut][debut]/1e8);
			if (gso[fin-1][fin-1]<maxi)
				gso[fin-1][fin-1]=maxi;
			else
				maxVect++;
		}
//		printf("petit :%d %d %f\n",debut,fin-debut,gso[fin-1][fin-1]);
		lllPetit(debut,.99);
		calcGs(debut);
		redTaille(debut,debut-1,maxi);
		int debutPrec=max(0,debut-BLOC/2);
		maxRed=debut+1;
		Float saut=1;
		for(int j=debutPrec;j<debut;j++)
			saut=max(saut,saut*gso[j][j]/gso[j+1][j+1]);
		if(debut>0 && saut>FACT && gso[debut-1][debut-1]>1.4*gso[debut][debut]){
			i=debutPrec;
		}
		else
			i=min(i+BLOC/2,maxVect);
	}
	for(int i=0;i<ETAPES;i++){
		for(int j=0;j<n-BLOC/2;j+=BLOC/2){
			int fin=min(j+BLOC,n);
			Int maxi;
			for(int k=max(0,j-BLOC/2);k<fin;k++){
				calcGs(k);
				redTaille(k,k-1,maxi);
			}
			lllPetit(max(0,fin-BLOC),.99);
		}
/*		for(int k=0;k<DIMPETITLLL;k++)
			printf("%.1Lf ",log(gso[k][k])/log(2));
		puts(" hop");*/
	}
/*	for(int i=0;i<DIMPETITLLL;i++){
		for(int j=0;j<DIMPETITLLL;j++)
			printf("%ld ",changement[i][j]);
		puts("");
	}*/
	temps+=omp_get_wtime()-tps;
	return true;
}

void LLLpetit::reduit(Gram &g){
	bool cont=true;
	n=g.nbLine();
	g.sizeRed(0,n);
//	printf("DIMPETITLLL=%d\n",n);
	assert(n<=DIMPETITLLL);
	Matrix change(n,n);
	int it=0;
	Float normes[DIMPETITLLL]={1};
	mpfr_t tmp;
	mpfr_init2(tmp,100);
	while(cont){
		fill(matlll[0],matlll[DIMPETITLLL],0);
		memset(changement,0,DIMPETITLLL*DIMPETITLLL*sizeof(Int));
		long long mini=MAXI;
		Float maxi=1;
		for(int i=1;i<n;i++){
			mpfr_div(tmp,g.cholNew[i][i],g.cholNew[0][0],MPFR_RNDN);
			normes[i]=sqrt(mpfr_get_ld(tmp,MPFR_RNDN));
//			printFlt(g.cholNew[i][i]);printf(" ");
			maxi=max(maxi,normes[i]);
		}
//		puts("");
		maxi/=MAXI;
		for(int i=0;i<n;i++){
			for(int j=0;j<=i;j++){
				Float tmp=mpfr_get_ld(g.cholNew[i][j],MPFR_RNDN);
				if(j<i)
					tmp*=normes[j];
				else
					tmp=normes[i];
				matlll[i][j]=round(tmp/maxi);
//				printf("%lld ",matlll[i][j]);
			}
//			puts("");
			matlll[i][i]+=1;
//			printf("%lld ",matlll[i][i]);
			mini=min(mini,matlll[i][i]);
		}
//		puts("");
		cont=mini<sqrt(MAXI) /*&& normes[n-1]<1*/;
//		puts("ok");
/*		for(int i=0;i<n;i++)
			printf("%03Lg,",matlll[i][i]*maxi);
		puts("");*/
//		for(int i=0;i<n;i++)
//			printf("%lld ",matlll[i][i]);
//		puts("");
//		puts("ok");
/*		printf("[");
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++)
				printf("%lld%c",matlll[i][j],j==n-1 ? (i==n-1? ']' : ';') : ',');
		}
		puts("");*/
		cont=cont & lll();
/*		for(int i=0;i<n;i++)
			calcGs(i);
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++)
				printf("%lld%c",matlll[i][j],j==n-1 ? ';' : ',');
			puts("");
		}*/
//		puts("ok");
/*		for(int i=0;i<n;i++)
			printf("%03Lg,",sqrt(gso[i][i])*maxi);
		puts("");*/
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++)
				change.v[i][j]=(((mpz_class)(long int)(changement[i][j]>>32))<<32)+(unsigned int)(changement[i][j]);
		}
//		change.output(stdout);
		double tps=omp_get_wtime();
		g.multiply(change,0);
		tempsGS+=omp_get_wtime()-tps;
		it++;
	}
//	exit(0);
}

void statsLLLpetit(){
	printf("nbSwapPetit=%lld nbLLLpetit=%lld nbLLL=%lld\n",nbSwapPetit,nbLLLP,nbLLL);
	printf("tempsLLL %lf (%lf), tempsLLLpetit %lf (%lf µs), tempsGS %lf (%lf)\n",temps,temps/nbLLL,tempsPetit,tempsPetit/nbLLLP*1e6,tempsGS,tempsGS/nbLLL);
}
