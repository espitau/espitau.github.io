#include <cstddef>
#include "util.h"

void nextNonBlankChar(FILE *f,int& ch){
	ch=fgetc(f);
	while (ch==' '||ch=='\t'||ch=='\r'||ch=='\n')
		ch=fgetc(f);
}

void printFlt(const mpfr_t v){
	mpfr_t t;
	mpfr_init(t);
	mpfr_set_prec(t,553);
	mpfr_set(t,v,MPFR_RNDN);
	mpfr_out_str(stdout,10,5,t,MPFR_RNDD);
	mpfr_clear(t);
}

/*double logErr(const mpfr_t v){
	mpfr_t t;
	mpfr_init(t);
	mpfr_diam_abs(t,v);
	mpfr_log2(t,t,MPFR_RNDD);
	double res=mpfr_get_d(t,MPFR_RNDD);
	mpfr_clear(t);
	return res;
}*/

void round(mpz_class& res,mpfr_t v){
	mpfr_get_z(res.get_mpz_t(),v,MPFR_RNDN);
}

#ifndef OPENMP
/*double omp_get_wtime(){
	return 0;
}

int omp_get_max_threads(){
	return 1;
}

int omp_get_thread_num(){
	return 0;
}*/
#endif
