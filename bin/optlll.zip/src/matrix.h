#ifndef MATRIX_H

#define MATRIX_H

#include <cstddef>
#include <gmpxx.h>
#include <vector>
#include "../config.h"

using namespace std;

class Matrix{
	public :
	vector<vector<mpz_class> > v;
	int nbColumn() const{
		return v.size();
	}
	int nbLine() const {
		return v.empty() ? 0 : v[0].size();
	}
	void resize(int nbLines,int nbColumns){
		v.resize(nbColumns);
		for (int j=0;j<(int)v.size();j++){
			v[j].resize(nbLines);
		}
	}
	Matrix(int nbLines=0,int nbColumns=0){
		resize(nbLines,nbColumns);
	}
	void identity(){
		for (int i=0;i<nbLine();i++)
			for (int j=0;j<nbColumn();j++)
				v[i][j]=int(i==j);
	}
	bool read(FILE *f);
	void output(FILE *f) const{
		fprintf(f,"[");
		for (int i=0;i<(int)v.size();i++){
			fprintf(f,"[");
			for (auto z:v[i]){
				mpz_out_str(f,10,z.get_mpz_t());
				fprintf(f," ");
			}
			fprintf(f,"]%c",i==(int)v.size()-1 ? ' ' : '\n');
		}
		fprintf(f,"]\n");
	}
	void transvec(int dst,int src,mpz_class mul);
	void transvec(int dst,int src,int mul);
	void multiply(const Matrix& mul,int begin=0);
};

#endif
